ALTER TABLE `tbl_kiosk` ADD INDEX (`DC_KIOSKNAME`);

ALTER TABLE `tbl_product_kiosk` ADD INDEX (`DN_KIOSK_ID`);

ALTER TABLE `tbl_product_kiosk` ADD INDEX (`DN_PRODUCT`);

ALTER TABLE `tbl_kiosk` ADD INDEX (`DN_ID`);

ALTER TABLE `tbl_product` ADD INDEX (`DN_ID`);

ALTER TABLE `tbl_product_type` ADD INDEX (`DN_TYPE_ID`);

ALTER TABLE `tbl_product` ADD INDEX (`DN_PRODUCT_TYPE`);