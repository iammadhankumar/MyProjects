CREATE OR REPLACE VIEW view_kiosk AS 
SELECT k.`DN_ID` AS id,
  k.`DN_KIOSKID` AS kioskId,
  k.`DC_KIOSKNAME` AS kioskName,
  k.`DN_LATITUDE` AS latitude,
  k.`DN_LONGITUDE` AS longitude,
  k.`DN_ADDRESS` AS address,
  k.`DN_ACTIVE` AS active ,
  pk.`DN_PRODUCT` AS pid
  FROM `tbl_kiosk` k RIGHT JOIN `tbl_product_kiosk` pk ON pk.`DN_KIOSK_ID`= k.`DN_ID`;