package pharmabox.email;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import pharmabox.utils.CommonProperties;

public class EmailManager {

	private static final Logger logger = LogManager.getLogger(EmailManager.class);

	protected static EmailConfiguration emailConfig = new EmailConfiguration();

	static Thread emailThread;

	public static boolean forgotPwd(String emailAddress,String firstname, String resetlink) {
		final String emailAddressFinal = emailAddress;
		final String firstnameFinal = firstname;
		final String resetlinkFinal = resetlink;
		emailThread = new Thread(){
			@Override
			public void run() {
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();
					String logoURL 	= null;//CommonProperties.getBaseURL() +"/"+CommonProperties.getlogoURL();
					String message = emailConfig.getForgotPasswordEmailMessage(emailAddressFinal,firstnameFinal,resetlinkFinal,URL,logoURL);
					sender.sendFromCustomerService(emailAddressFinal, emailConfig.getForgotPasswordSubject(), message);
				} catch (Exception e) {
					logger.error("Error While sendding email at forgotPwd"+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}

	public static boolean forgotPwd1(String emailAddress, String resetlink,String filepath,String firstname,String imgaePath) {
		final String emailAddressFinal = emailAddress;		
		final String resetlinkFinal = resetlink;
		final String filepathFinal =filepath;
		final String firstnameFinal =firstname;
		final String imgaePathFinal =imgaePath;
		emailThread = new Thread(){
			@Override
			public void run() {
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();
					String logoURL 	= null;//CommonProperties.getBaseURL() +"/"+CommonProperties.getlogoURL();
					String message = emailConfig.getForgotPasswordEmailMessage1(emailAddressFinal,resetlinkFinal,URL,logoURL,filepathFinal,firstnameFinal,imgaePathFinal);
					sender.sendFromCustomerService(emailAddressFinal, emailConfig.getForgotPasswordSubject(), message);
				} catch (Exception e) {
					logger.error("Error While sendding email at forgotPwd"+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}

	public static boolean forgotUsername(String emailAddress, String firstname,String lastName) {
		final String emailAddressFinal = emailAddress;
		final String firstnameFinal = firstname;
		final String lastNameFinal = lastName;

		emailThread = new Thread(){
			@Override
			public void run() {
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();
					String message = emailConfig.getForgotUsernameEmailMessage(firstnameFinal, lastNameFinal, URL );
					sender.sendFromCustomerService(emailAddressFinal, emailConfig.getForgotUsernameSubject(), message);
				} catch (Exception e) {
					logger.error("Error While sendding email at forgot Username : "+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}

	public static boolean mailToDirectorOfOrganization(String orgName, String directorName, String toEmailAddress, String ccEmailAddress) {
		final String toEmailAddressFinal = toEmailAddress;
		final String ccEmailAddressFinal = ccEmailAddress;
		final String directorNameFinal = directorName;
		final String orgNameFinal = orgName;

		emailThread = new Thread(){
			@Override
			public void run() {
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();
					String message = emailConfig.getOrganizationEmailForDirector(orgNameFinal, directorNameFinal, URL);
					sender.sendMailWithCCOfPerson(toEmailAddressFinal, ccEmailAddressFinal,  emailConfig.getOrganizationCreatedSubject(), message);
				} catch (Exception e) {
					logger.error("Error While sendding email at forgot Username : "+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}

	public static boolean newUser(String emailAddress, String firstname, String userName, String pwd, String user_role,String admin_email ) {
		final String emailAddressFinal = emailAddress;
		final String firstnameFinal = firstname;
		final String userNameFinal = userName;
		final String pwdFinal = pwd;
		final String user_roleFinal = user_role;		
		final String adminEmail = admin_email;
		emailThread = new Thread(){
			@Override
			public void run() {
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();					
					String message = emailConfig.getNewUserMessage(firstnameFinal,userNameFinal,pwdFinal,user_roleFinal,URL);
					sender.sendMailWithCCOfPerson(emailAddressFinal, adminEmail, emailConfig.getNewUserSubject(), message);
				} catch (Exception e) {
					logger.error("Error While sendding email at forgotPwd"+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}

	public static boolean newVariantUser(String emailAddress, String firstname, String userName, String pwd, String user_role, String org,String admin_email ) {
		final String emailAddressFinal = emailAddress;
		final String firstnameFinal = firstname;
		final String userNameFinal = userName;
		final String pwdFinal = pwd;
		final String user_roleFinal = user_role;
		final String orgFinal = org;
		final String adminEmail = admin_email;
		emailThread = new Thread(){
			@Override
			public void run() {
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();				
					String message = emailConfig.getNewUserVariantMessage(firstnameFinal,userNameFinal,pwdFinal,user_roleFinal,orgFinal,URL);
					sender.sendMailWithCCOfPerson(emailAddressFinal, adminEmail, emailConfig.getNewUserSubject(), message);
				} catch (Exception e) {
					logger.error("Error While sendding email at forgotPwd"+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}

	public static boolean sendEmail(String email, String emailContent, String senderName,String Subject) {
		final String emailAddressFinal = email;
		final String emailContentFinal = emailContent;
		final String senderNameFinal = senderName;
		final String senderSubjectFinal = Subject;
		emailThread = new Thread(){
			@Override
			public void run() {
				try {
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL()+ CommonProperties.getContextPath();
					String logoURL 	= null;//CommonProperties.getBaseURL() +"/"+CommonProperties.getlogoURL();
					String message = emailConfig.getGeneralEmailMessage(emailContentFinal,senderNameFinal,URL,logoURL);
					sender.sendFromCustomerService(emailAddressFinal, senderSubjectFinal, message);
				} catch (Exception e) {
					logger.error("Error While sendding email at NotApproved"+e);
				} finally {
					emailThread.interrupt();
				}
			}
		};
		emailThread.start();
		return true;
	}

	public static boolean sendPdfReport(String emailAddress,String receiverName, String attachmentName, String attachmentUrl,String filepath) {
		try {
			EmailSender sender = new EmailSender();                                   
			String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();
			String logoURL 	= null;
			String message = emailConfig.getPdfReportMessage(receiverName,attachmentName,URL,logoURL);
			sender.sendWithAttachement(emailAddress, emailConfig.getPdfReportSubject(), message, attachmentUrl, attachmentName );
			return true;
		} catch (Exception e) {
			logger.error("Error While sendding email at sendPdfForOTA"+e);
			return false;
		}
	}

	public static boolean activateUserViaEmail(String emailAddress, String firstname, String confirmLink ,String basepath,String filepath,String companyname,String imagelogo) {		
		final String emailAddressFinal = emailAddress;
		final String firstnameFinal = firstname;
		final String confirmlinkFinal = confirmLink;	
		final String basepathFinal = basepath;	
		final String filePathFinal =filepath;
		final String companynameFinal =companyname;
		final String imagelogoFinal =imagelogo;
		emailThread = new Thread(){
			@Override
			public void run() {			
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();					
					String message = emailConfig.getNewUserActivate(firstnameFinal, URL, confirmlinkFinal,basepathFinal,filePathFinal,companynameFinal,imagelogoFinal);
					sender.sendFromCustomerService(emailAddressFinal, emailConfig.getActivateUserSubject(), message);
				} catch (Exception e) {
					logger.error("Error While sendding email at activateUserViaEmail"+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}

	public static boolean contactusEmail(String Email, String fname, String Subject,String Content) {
		final String email = Email;
		final String to = new EmailConfiguration().getUserServiceEmailAddress();
		final String name = fname;
		final String subject = Subject;
		final String content = Content;
		emailThread = new Thread(){
			@Override
			public void run() {
				try {
					EmailSender sender = new EmailSender();										
					String message = emailConfig.getContactusMailMessage(email, name, subject, content);
					sender.send(email, to,null, subject, message);
				} catch (Exception e) {
					logger.error("Error While sendding email at NotApproved"+e);
				} finally {
					emailThread.interrupt();
				}
			}
		};
		emailThread.start();
		return true;
	}

	public static boolean confimationUserViaEmail(String email, String firstName,
			String confirmLink, String tempPassword,String filepath,String imagelogo) {		
		final String emailAddressFinal = email;
		final String firstnameFinal = firstName;
		final String confirmlinkFinal = confirmLink;
		final String filePathFinal=filepath;
		final String tempPasswordFinal = tempPassword;
		final String imagelogoFinal = imagelogo;
		emailThread = new Thread(){
			@Override
			public void run() {				
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();					
					String message = emailConfig.getNewUserConfimation(firstnameFinal, URL, confirmlinkFinal, tempPasswordFinal,filePathFinal,imagelogoFinal);
					sender.sendFromCustomerService(emailAddressFinal, emailConfig.getCompanySubject(), message);
				} catch (Exception e) {
					logger.error("Error While sendding email at activateUserViaEmail"+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;

	}

	public static boolean sendGiftCard(String emailAddress,String firstname, String resetlink) {
		final String emailAddressFinal = emailAddress;
		final String firstnameFinal = firstname;
		final String resetlinkFinal = resetlink;
		emailThread = new Thread(){
			@Override
			public void run() {
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();
					String logoURL 	= null;//CommonProperties.getBaseURL() +"/"+CommonProperties.getlogoURL();
					String message = emailConfig.getSendGiftEmailMessage(emailAddressFinal,firstnameFinal,resetlinkFinal,URL,logoURL);
					sender.sendFromCustomerService(emailAddressFinal, emailConfig.getGiftCardSubject(), message);
				} catch (Exception e) {
					logger.error("Error While sendding email at forgotPwd"+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}

	public static boolean registerUser(String emailAddress, String firstname,String filepath,String facebookpath) {		
		System.out.println("email trigger");
		System.out.println(emailAddress);
		System.out.println(firstname);
		final String emailAddressFinal = emailAddress;
		final String firstnameFinal = firstname;
		final String filepathFinal = filepath;
		final String facebookpathFinal = facebookpath;
		emailThread = new Thread(){
			@Override
			public void run() {				
				try {
					
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();					
					String message = emailConfig.getNewUserActivate1(firstnameFinal, filepathFinal,URL,facebookpathFinal);
					sender.sendFromCustomerService(emailAddressFinal, emailConfig.getRegisterUser(), message);
				} catch (Exception e) {
					logger.error("Error While sendding email at activateUserViaEmail"+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}

	public static boolean sendCompanyActivation(String emailAddress,String firstname, String resetlink) {
		final String emailAddressFinal = emailAddress;
		final String firstnameFinal = firstname;
		final String resetlinkFinal = resetlink;
		emailThread = new Thread(){
			@Override
			public void run() {
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();
					String logoURL 	= null;//CommonProperties.getBaseURL() +"/"+CommonProperties.getlogoURL();
					String message = emailConfig.sendCompanyActivationMessage(emailAddressFinal,firstnameFinal,resetlinkFinal,URL,logoURL);
					sender.sendFromCustomerService(emailAddressFinal, emailConfig.getCompanySubject(), message);
				} catch (Exception e) {
					logger.error("Error While sendding email at forgotPwd"+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}

	public static boolean loadcardAmount(String emailAddress, String resetlink,String filepath,String firstname,String amount,String imagelogo) {
		final String emailAddressFinal = emailAddress;		
		final String resetlinkFinal = resetlink;
		final String filePathFinal=filepath;
		final String firstnameFinal=firstname;
		final String amountFinal=amount;
		final String imagelogoFinal=imagelogo;
		emailThread = new Thread(){
			@Override
			public void run() {
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();
					String logoURL 	= null;
					String message = emailConfig.getLoadCardBalanceMessage(emailAddressFinal,resetlinkFinal,URL,logoURL,filePathFinal,firstnameFinal,amountFinal,imagelogoFinal);
					sender.sendFromCustomerService(emailAddressFinal, emailConfig.getLoadCardBalanceSubject(), message);
				} catch (Exception e) {
					logger.error("Error While sendding email at locdcardbalance"+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}

	public static boolean sendFreeGift(String emailAddress,String filepath,String firstname,String imagepath,String amount) {		
		final String emailAddressFinal = emailAddress;	
		final String filePathFinal =filepath;
		final String firstnameFinal =firstname;
		final String imagepathFinal =imagepath;
		final String amountFinal=amount;
		emailThread = new Thread(){
			@Override
			public void run() {
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();
					String logoURL 	= null;
					String message = emailConfig.getFreeGift(emailAddressFinal,URL,logoURL,filePathFinal,firstnameFinal,imagepathFinal,amountFinal);
					sender.sendFromCustomerService(emailAddressFinal, emailConfig.getFreeGiftSubject(), message);
				} catch (Exception e) {
					logger.error("Error While sendding email at locdcardbalance"+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}

	public static boolean sendBirtydayGift(String emailAddress,String filepath,String firstname,String imagepath) {
		final String emailAddressFinal = emailAddress;
		final String filePathFinal = filepath;	
		final String firstnameFinal = firstname;	
		final String imagepathFinal = imagepath;	
		emailThread = new Thread(){
			@Override
			public void run() {
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();
					String logoURL 	= null;
					String message = emailConfig.getBirthdayGift(emailAddressFinal,URL,logoURL,filePathFinal,firstnameFinal,imagepathFinal);
					sender.sendFromCustomerService(emailAddressFinal, emailConfig.getBirthdayGiftSubject(), message);
				} catch (Exception e) {
					logger.error("Error While sendding email "+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}	

	public static boolean sendGiftCardImage(String email, String firstName,
			String confirmLink,String gift_amount,String description, String fileName,String filepath,String filepath1,String imagelogo) {		
		final String emailAddressFinal = email;
		final String firstnameFinal = firstName;
		final String confirmlinkFinal = confirmLink;
		final String gift_amount1 = gift_amount;
		final String descriptionFinal=description;
		final String filename = fileName;
		final String filePath=filepath;
		final String filePath1=filepath1;
		final String imagelogo1=imagelogo;
		emailThread = new Thread(){
			@Override
			public void run() {				
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();					
					String message = emailConfig.getGiftCard(firstnameFinal, URL, confirmlinkFinal,gift_amount1, descriptionFinal,filename,filePath,filePath1,imagelogo1);					
					sender.sendFromCustomerService(emailAddressFinal, emailConfig.getGiftCardSubject(), message);


				} catch (Exception e) {
					logger.error("Error While sendding email at activateUserViaEmail"+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}

	public static boolean autoReloadAmount(String emailAddress, String resetlink,String filepath,String firstname,String amount,String imagelogo) {
		final String emailAddressFinal = emailAddress;		
		final String resetlinkFinal = resetlink;
		final String filePathFinal=filepath;
		final String firstnameFinal=firstname;
		final String amountFinal=amount;
		final String imagelogoFinal=imagelogo;
		emailThread = new Thread(){
			@Override
			public void run() {
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getContextPath();
					String logoURL 	= null;//CommonProperties.getBaseURL() +"/"+CommonProperties.getlogoURL();
					String message = emailConfig.getAutoReloadBalanceMessage(emailAddressFinal,resetlinkFinal,URL,logoURL,filePathFinal,firstnameFinal,amountFinal,imagelogoFinal);
					sender.sendFromCustomerService(emailAddressFinal, emailConfig.getAutoReloadBalance(), message);
				} catch (Exception e) {
					logger.error("Error While sendding email at autoReloadBalance"+e);
				} finally {
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}
	
	
	
	
	
	
	
	
	
	
	public static boolean sentPromotionAndDiscountMail(String emailAddress, String firstname,String admin_email ) {
		emailThread = new Thread(){
			@SuppressWarnings("unused")
			@Override
			public void run() {
				try {
					EmailConfiguration emailConfig = new EmailConfiguration();
					EmailSender sender = new EmailSender();
					String URL 	= CommonProperties.getBaseURL() + CommonProperties.getUiPath();
					String logoURL 	= null;//CommonProperties.getBaseURL() +"/"+CommonProperties.getlogoURL();
					String message = emailConfig.sentPromotionAndDiscountMail(emailAddress,firstname,admin_email,URL);
					sender.sendMailWithPerson(emailAddress, emailConfig.getPromotionAndDiscountSubject(), message);
				} catch (Exception e) {
					logger.error("Error While sending email at forgotPwd"+e);
				}
				finally{
					emailThread.interrupt();
					emailThread = null;
				}
			}
		};
		emailThread.start();
		return true;
	}

	
	
	
	
	
	
	
	
	
	
	

}