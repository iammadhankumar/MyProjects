package pharmabox.email;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import pharmabox.service.IAdminService;
//import frontForty.service.IAdminService;
//import frontForty.service.IMessageService;
import pharmabox.service.IUserService;
import pharmabox.utils.CommonUtils;

@Component
public class ScheduledTask {

	@Autowired
	private IUserService userService;

	@Autowired
	private IAdminService adminService;
//
//	@Autowired
//	private IMessageService messageService;

	CommonUtils commonUtils= CommonUtils.getInstance();

	//@Scheduled(cron="*/5 * * * * MON-FRI")
	public void reportCurrentMonth(String email, String recivername, String fileName, String path,String filepath) {	    	 
		try {     		 
		//	adminService.getAllCompanyReportStatus();	    	
		}catch(Exception e){
		}  	
		EmailManager.sendPdfReport(email, recivername, fileName, path,filepath);	    	
	}
}

