package pharmabox.oauth2;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import pharmabox.dao.IUserDAO;  

@Service  
public class CustomUserDetailsService implements UserDetailsService {  

	@Autowired
	private IUserDAO iuserDAO;

	@Autowired
	public CustomUserDetailsService(IUserDAO iuserDAO) {
		this.iuserDAO = iuserDAO;
	} 

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override  
	public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {  
		pharmabox.domain.User usr = iuserDAO.getUserByEmail(s);
		
		String password =""; 
		if (usr == null) {  
			throw new UsernameNotFoundException("User details not found with this username: " + s);  
		} 
		 
		String username = String.valueOf(usr.getUser_id()); 
		String ufacebook = usr.getFacebook_id();
		String upassword=usr.getPassword();
		String role = usr.getUserType().getUserTypeName();		
		List authList = getAuthorities(role); 	
		if(!upassword.isEmpty()){			
			password =upassword;			
		}
		else{
			password=ufacebook;
		}			
		User user = new User(username, password, authList);    
		return user;  
	}  

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private List getAuthorities(String role) {  
		
		List authList = new ArrayList();  
		authList.add(new SimpleGrantedAuthority("ROLE_USER"));       
		if (role != null && role.trim().length() > 0) {  
			if (role.equals("admin")) {  
				authList.add(new SimpleGrantedAuthority("ROLE_ADMIN"));  
			}  
			if (role.equals("corporateuser")) {  
				authList.add(new SimpleGrantedAuthority("ROLE_ADMIN"));  
			}  
			if (role.equals("company")) {  
				authList.add(new SimpleGrantedAuthority("ROLE_ADMIN"));  
			}  
			if (role.equals("user")) {  				
				authList.add(new SimpleGrantedAuthority("ROLE_ADMIN"));  
			}  
		}    
		return authList; 
	
	}  
}  
