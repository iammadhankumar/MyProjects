package pharmabox.service;

import java.util.List;

import pharmabox.domain.ContentManagement;


public interface IContentManagementService {

	List<ContentManagement> getAllContentManagement();
	
	ContentManagement getContentManagementByContentType(String label);
	
	public ContentManagement getPrivacyPolicyInfo(String label);
}
