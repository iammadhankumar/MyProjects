package pharmabox.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pharmabox.dao.IAdminDAO;
import pharmabox.domain.Kiosk;
import pharmabox.domain.Rewards;
import pharmabox.domain.RewardsMaintain;
import pharmabox.domain.ScrollingContent;




@Service("IAdminService")
public class AdminService implements IAdminService {
	
	@Autowired
	IAdminDAO adminDao; 
	
	@Override
	public long registerRewardInfo(Rewards reward)
	{
		 return adminDao.registerRewardInfo(reward);
	}
	
	@Override
	public void updateRewards(Rewards reward) {
      
		adminDao.updateRewards(reward);
		
	}

	@Override
	public long registerRewardsInfoByUser(RewardsMaintain rewardsMaintain)
	{
		return adminDao.registerRewardsInfoByUser(rewardsMaintain);
	}

	@Override
	public void removeRewards(long rewardId) {
		
		adminDao.removeRewards(rewardId);
	}
	
	@Override
	public void deleteRewards(long userId)
	{
		adminDao.deleteRewards(userId);
	}
	
	@Override
	public RewardsMaintain getRewardsMaintainByUser(long rewardId,long userId)
	{
		return adminDao.getRewardsMaintainByUser(rewardId, userId);
	}
	
	@Override
	public List<Rewards> getRewardsList(long userId,int pagenumber,int pagerecord)
	{
		return adminDao.getRewardsList(userId,pagenumber, pagerecord);
	}
	
	public List<Rewards> getAllRewardsList(long userId)
	{
		return adminDao.getAllRewardsList(userId);
	}

	@Override
	public long registerScrollingContentInfo(ScrollingContent scrollingContent) {
		return adminDao.registerScrollingContentInfo(scrollingContent) ;
	}
	
	@Override
	public List<ScrollingContent> getAllScrollingContentList()
	{
		return adminDao.getAllScrollingContentList();
	}
	
	@Override
	public List<ScrollingContent> getScrollingContentList(int pagenumber,int pagerecord)
	{
		return adminDao.getScrollingContentList(pagenumber,pagerecord);
	}
	
	@Override
	public Rewards getRewardByPromoCode(String code)
	{
		return adminDao.getRewardByPromoCode(code);
	}

	
	@Override
	public Rewards getRewardById(long id)
	{
		return adminDao.getRewardById(id);
	}

	@Override
	public RewardsMaintain getUsedRewardById(long id,long userId) {
		return adminDao.getUsedRewardById(id,userId);
	}

	@Override
	public List<Rewards> getRewardsListByPromocode(String promocode) {
		return adminDao.getRewardsListByPromocode(promocode);
	}

	@Override
	public List<Rewards> getOverAllRewardsList(int pagenumber, int pagerecord) {
		return adminDao.getOverAllRewardsList(pagenumber,pagerecord);
	}

	@Override
	public long getOverAllRewardsListCount() {
		return adminDao.getOverAllRewardsListCount();
	}

	@Override
	public Rewards getRewardByName(String rewardName) {
		return adminDao.getRewardByName(rewardName);
	}

	@Override
	public Rewards getRewardId(long id) {
		return adminDao.getRewardId(id);
	}

	@Override
	public List<Rewards> getAllRewards(int pagenumber, int pagerecord) {
		return adminDao.getAllRewards(pagenumber, pagerecord);
	}

	@Override
	public List<Kiosk> getAllKiosks(int pagenumber, int pagerecord,int sortColumn,int sortType) {
		return adminDao.getAllKiosks(pagenumber, pagerecord,sortColumn,sortType);
	}

	@Override
	public List<Rewards> getAllRewardsListByall(int pagenumber, int pagerecord) {
		return adminDao.getAllRewardsListByall(pagenumber, pagerecord);
	}

	@Override
	public List<Rewards> getExpiredRewardsList() {
		return adminDao.getExpiredRewardsList();
	}

	@Override
	public void updateExpiredRewards() {
		
		 adminDao.updateExpiredRewards();
		
	}

}
