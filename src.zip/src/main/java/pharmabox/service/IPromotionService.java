package pharmabox.service;

import pharmabox.domain.Rewards;

public interface IPromotionService {

	Rewards getByCodeAndActive(String code);
	long registerNewPromotion(Rewards rewardObj);
	 void updateReward(Rewards reward);
}
