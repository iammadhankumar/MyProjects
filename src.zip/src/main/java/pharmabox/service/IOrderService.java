package pharmabox.service;

import java.util.List;

import pharmabox.domain.Order;
import pharmabox.domain.OrderBasket;
import pharmabox.domain.Product;
import pharmabox.domain.RewardsPurchaseInfo;
import pharmabox.domain.User;

public interface IOrderService {
	
	public long registerNewOrder(Order order);
	public long registerRewardsPurchaseInfo(RewardsPurchaseInfo rewardPurchase);
	public List<User> getUserInfo(long userId);
	public List<Product> getProductInfo(long pid);
	public Order getOrderInfo(String orderNo);
	public List<Order> getOrderInfoByUser(long userId,int pagenumber,int pagerecord);
	public List<Order> getOrderInfoList(int pagenumber,int pagerecord);
	public long getOrderInfoListCount();
	public long getorderCount(long userId,boolean purchase);
	public List<OrderBasket> getOrderBasketInfoByUser(long userId,int pagenumber,int pagerecord);
	public List<Order> getOrderDetailsByUser(long userId,int pagenumber,int pagerecord);
	public Order getOrderInfoByBasket(long bid);
	public Order getOrderInfoById(long userId,String orderNumber,long orderId);
	public RewardsPurchaseInfo getRewardPurchaseInfoById(long id);
	public List<Order>  getOrderInfoByUserId(List<User> userId);
	public Order getOrderByOrderNo(String orderNo);
	void updateOrder(Order order);

	
	
}
