package pharmabox.service;

import java.util.List;

import pharmabox.domain.Kiosk;
import pharmabox.domain.ProductKiosk;
import pharmabox.views.KioskView;

public interface IKioskService {

	public long registerKioskDetails(Kiosk kioskObj);	 

	public void updateKiosk(Kiosk kiosk);

	public List<Kiosk> getAllKioskDetails();	 

	public List<Kiosk> getAllSearchKioskDetails(String searchValue);

	public Kiosk getKioskById(long kiosk_id);

	public List<Kiosk> getAllKioskMap( String latitude,	String longitude);

	public List<Kiosk> getAllKioskList(int pagenumber,int pagerecord);

	public List<Kiosk> getKioskLocationDetail(long kiosk_id);

	public void deleteKiosk(long kiosk_id);

	public List<Kiosk> getAllKioskListByActions();

	public Kiosk getKioskByKioskId(long id);

	public Kiosk getKioskByKioskIdAction(long id);

	public Kiosk getKioskByIdWithoutAction(long kiosk_id);
	
	public Kiosk getKioskId(long kioskId);
	
    public Kiosk getKioskName(String kioskName);
    
    public Kiosk getKioskBypId(long product_id);
    
    public ProductKiosk getKioskByProductKioskId(long productkioskid);
    
	public List<Kiosk> getAllKioskListByKioskId(long kid);
	
	 public List<Kiosk> getAllKioskListUsingKioskId (List<Long> pkObj);
	 
		public List<Kiosk> getAllKioskListByProduct(long pid, int pagenumber, int pagerecord);
		
		public List<KioskView> getAllKioskViewListByProducts(long pid, int pagenumber, int pagerecord);
		
		public long getAllKioskListByProductcount(long pid);

		public long getAllKioskViewListByProductscount(long pid);
		
		public Kiosk getKioskByKioskID(long kioskId);

}