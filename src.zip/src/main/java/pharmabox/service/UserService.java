package pharmabox.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pharmabox.dao.IUserDAO;
import pharmabox.domain.DeviceToken;
import pharmabox.domain.User;
import pharmabox.domain.UserType;

@Service("IUserService")
public class UserService implements IUserService{

	@Autowired
	IUserDAO userDAO; 

	@Override
	public long registerNewUser(User userObj) {		
		return userDAO.registerNewUser(userObj);
	}
	@Override
	public User getUserByEmail(String email) {		
		return userDAO.getUserByEmail(email);
	}
	
	@Override
	public UserType getUserTypeById(long userType) {			
		return userDAO.getUserTypeById(userType);
	}
	@Override
	public User getUserById(long user_id) {
		return userDAO.getUserById(user_id);
	}
	
	
	@Override
	public User getUserById(User user) {
		return userDAO.getUserById(user);
	}
	
	
	@Override
	public User getUserPasswordByEmailId(String email) {		
		return userDAO.getUserPasswordByEmailId(email);
	}
	
	
	@Override
	public User getUserByFacebook(String facebook_id) {			
		return userDAO.getUserByFacebook(facebook_id);
	}
	
	
	@Override
	public void updateUser(User user) {		
		userDAO.updateUser(user);
	}
	
	@Override
	public void updateDeviceToken(DeviceToken token) {
		userDAO.updateDeviceToken(token);
		
	}
	
	public DeviceToken getDeviceTokenByUserId(long user_id) {
		return userDAO.getDeviceTokenByUserId(user_id);
	}
	
	
	
		public User getLocation(long userId)
		{
			return userDAO.getLocation(userId);
		}
	
		@Override
		public User getUserByuserIdAndNotification(long userID, boolean b)
		{
			return userDAO.getUserByuserIdAndNotification(userID,b);
		}
		
	
	@Override
	public void saveDeviceToken(DeviceToken token) {
		userDAO.saveDeviceToken(token);
		
	}
	
	@Override
	public List<User> getAllUsers() 
	{
		return userDAO.getAllUsers();
	}
	@Override
	public List<User> getAllUsersByStatus(int stat) {
		return userDAO.getAllUsersByStatus(stat);
	}
	@Override
	public User getUserByEmailAndType(String email, long type) {
		return userDAO.getUserByEmailAndType(email,type);
	}
	
}