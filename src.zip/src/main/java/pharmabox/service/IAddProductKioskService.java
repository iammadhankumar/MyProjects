package pharmabox.service;


import java.util.List;

import pharmabox.domain.ProductKiosk;

public interface IAddProductKioskService {
	
	//public ProductKiosk getProductAndKiosk(long product_id, long kiosk_id);

	public Long registerNewProductKiosk(ProductKiosk productkiosk);
	
	public ProductKiosk getProductkiosk_id(long productkiosk_id );

	public List<ProductKiosk> getAllProductlist(long kiosk_id,long product_type_id,String searchText);
	
	public ProductKiosk getProductKioskByproductId(long productId,long kioskid);
	
	public List<ProductKiosk> getAllProductListByProductTypeandKiosk(long kioskId,List<Long> productObj,long productType,int pagenumber,int pagerecord);

	public ProductKiosk checkQuantity(long productkiosk_id);

	void updateProductKiosk(ProductKiosk ProductKiosk);
	
	public ProductKiosk getKioskBypId(Long product_id);
	
	public ProductKiosk getProductAndKiosk(long product_id);
	
	public ProductKiosk getKioskByProductKioskId(long productkioskid);
	
	public ProductKiosk getProductKioskByProductandKioskId(long kioskId,long productId);

	public List<Long> getKioskByproductId(long pid);

	public long getKioskCount(long pid);

	public List<ProductKiosk> getProductKioskId(long productId);
	
	 public List<Long> getKioskIdByProductKioskId(List<ProductKiosk> productkioskid);
	 
	 public ProductKiosk getProductKioskInfo(long kioskId,long productId,long qt);
	 
	 public ProductKiosk getProductKioskBypId(long id);
	 
	 public ProductKiosk getProductkiosk(long pid);
	 
	 public void updateProductKioskQuantity(long qt,long pid);
	 
	 public List<ProductKiosk> getProductKioskbyKiosk(long kioskId);
	 
	 public List<Long> getProductByKioskId(long kioskId);
	
	
	

	




	
}
