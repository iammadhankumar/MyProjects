package pharmabox.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pharmabox.dao.IOrderDAO;
import pharmabox.domain.Order;
import pharmabox.domain.OrderBasket;
import pharmabox.domain.Product;
import pharmabox.domain.RewardsPurchaseInfo;
import pharmabox.domain.User;



@Service("IOrderService")
public class OrderService implements IOrderService {
	
	@Autowired
	IOrderDAO orderDao;

	

	
	@Override
	public long registerNewOrder(Order order)
	{
		return orderDao.registerNewOrder(order);
	}
	
	@Override
	public long registerRewardsPurchaseInfo(RewardsPurchaseInfo rewardPurchase) {
		return orderDao.registerRewardsPurchaseInfo(rewardPurchase);
	}
	
	
	
	@Override
	public List<User> getUserInfo(long userId)
	{
		return orderDao.getUserInfo(userId);
	}
	
	
	@Override
	public List<Product> getProductInfo(long pid)
	{
		return orderDao.getProductInfo(pid);
	}
	
     
	@Override
	public Order getOrderInfo(String orderNo)
	{
		return orderDao.getOrderInfo(orderNo);
	}
	
	@Override
	public List<Order> getOrderInfoByUser(long userId,int pagenumber,int pagerecord)
	{
		return orderDao.getOrderInfoByUser(userId,pagenumber,pagerecord);
	}
	
	@Override
	public long getorderCount(long userId,boolean purchase)
	{
		return orderDao.getorderCount(userId, purchase);
	}
	
	@Override
	public List<Order> getOrderInfoList(int pagenumber,int pagerecord)
	{
		return orderDao.getOrderInfoList(pagenumber,pagerecord);
	}
	

	@Override
	public Order getOrderInfoById(long userId,String orderNumber,long orderId)
	{
		return orderDao.getOrderInfoById(userId,orderNumber,orderId);
	}
	

	@Override
	public List<OrderBasket> getOrderBasketInfoByUser(long userId, int pagenumber, int pagerecord) {
		return orderDao.getOrderBasketInfoByUser(userId,pagenumber,pagerecord);
	}


	@Override
	public List<Order> getOrderDetailsByUser(long userId, int pagenumber, int pagerecord) {
		return orderDao.getOrderDetailsByUser(userId, pagenumber, pagerecord);
	}
	
	@Override
	public Order getOrderInfoByBasket(long bid)
	{
		return orderDao.getOrderInfoByBasket(bid);
	}

	@Override
	public RewardsPurchaseInfo getRewardPurchaseInfoById(long id) {
		return orderDao.getRewardPurchaseInfoById(id);
	}

	@Override
	public long getOrderInfoListCount() {
		return orderDao.getOrderInfoListCount();
	}

	@Override
	public List<Order>  getOrderInfoByUserId(List<User> userId) {
		return orderDao.getOrderInfoByUserId(userId);
	}

	@Override
	public Order getOrderByOrderNo(String orderNo) {
		return orderDao.getOrderByOrderNo(orderNo);
	}

	@Override
	public void updateOrder(Order order) {
		orderDao.updateOrder(order);
	}




	
}
