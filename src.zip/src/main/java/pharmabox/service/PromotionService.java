package pharmabox.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pharmabox.dao.IPromotionDAO;
import pharmabox.domain.Rewards;

@Service("IPromotionService")
public class PromotionService implements IPromotionService {

	@Autowired
	IPromotionDAO promotionDAO;
	@Override
	public Rewards getByCodeAndActive(String code) {
		return promotionDAO.getByCodeAndActive(code);
	}
	@Override
	public long registerNewPromotion(Rewards rewardObj) {
		return promotionDAO.registerNewPromotion(rewardObj);
	}
	@Override
	public void updateReward(Rewards reward) {
		 promotionDAO.updateReward(reward);

	}

}
