package pharmabox.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pharmabox.dao.IAddProductKioskServiceDao;
import pharmabox.domain.ProductKiosk;


@Service
public class AddProductKioskService implements IAddProductKioskService {

	@Autowired
	IAddProductKioskServiceDao AddProductKioskServiceDao;

	@Override
	public ProductKiosk getProductAndKiosk(long product_id) {
		System.out.println("pk is in");
		return AddProductKioskServiceDao.getProductAndKiosk(product_id);
	}

	@Override
	public ProductKiosk getProductkiosk_id(long KioskId) {
		//System.out.println("entered in to service id");
		return AddProductKioskServiceDao.getProductkiosk_id(KioskId);
	}
	
	@Override
	public void updateProductKiosk(ProductKiosk ProductKiosk) {		
		AddProductKioskServiceDao.updateProductKiosk(ProductKiosk);
	}
	
	
	@Override
	public Long registerNewProductKiosk(ProductKiosk productkiosk) {
		// TODO Auto-generated method stub
		//System.out.println(" entered service.. pk added  entered");
		return AddProductKioskServiceDao.registerNewProductKiosk(productkiosk);
	}


	@Override
	public List<ProductKiosk> getAllProductlist(long kiosk_id,long product_type_id,String searchText) {
		// TODO Auto-generated method stub
		return AddProductKioskServiceDao.getAllProductlist(kiosk_id,product_type_id,searchText);
	}

	@Override
	public ProductKiosk checkQuantity(long productkiosk_id) {
		// TODO Auto-generated method stub
		return AddProductKioskServiceDao.checkQuantity(productkiosk_id);
	}
	
	@Override
	public ProductKiosk getKioskBypId(Long product_id)
	{
		return AddProductKioskServiceDao.getKioskBypId(product_id);
	}

	

	@Override
	public ProductKiosk getKioskByProductKioskId(long productkioskid)
	{
		return AddProductKioskServiceDao.getKioskByProductKioskId(productkioskid);
	}
	
	

	@Override
	public ProductKiosk getProductKioskByProductandKioskId(long kioskId,long productId)
	{
		return AddProductKioskServiceDao.getProductKioskByProductandKioskId(kioskId,productId);
	}

	@Override
	public List<Long> getKioskByproductId(long pid) {
		// TODO Auto-generated method stubpublic List<ProductKiosk> getKioskByproductId(long pid) {
		return AddProductKioskServiceDao.getKioskByproductId(pid);
	}
	
	@Override
	public long getKioskCount(long pid)
	{
		return AddProductKioskServiceDao.getKioskCount(pid);
	}
	
	@Override
	public List<ProductKiosk> getProductKioskId(long productId)
	{
		return AddProductKioskServiceDao.getProductKioskId(productId);
	}


 @Override
 public List<Long> getKioskIdByProductKioskId(List<ProductKiosk> productkioskid)
 {
	 return AddProductKioskServiceDao.getKioskIdByProductKioskId(productkioskid);
 }

	
@Override
public ProductKiosk getProductKioskInfo(long kioskId,long productId,long qt) 
{
	return 	AddProductKioskServiceDao.getProductKioskInfo(kioskId, productId, qt);
}

@Override
public ProductKiosk getProductKioskBypId(long id)
{
	return AddProductKioskServiceDao.getProductKioskBypId(id);
}
@Override
public ProductKiosk getProductkiosk(long pid)
{
	return AddProductKioskServiceDao.getProductkiosk(pid);
}

@Override
public void updateProductKioskQuantity(long qt,long pid)
{
	 AddProductKioskServiceDao.updateProductKioskQuantity(qt, pid);
}

@Override
public List<ProductKiosk> getProductKioskbyKiosk(long kioskId)
{
	return AddProductKioskServiceDao.getProductKioskbyKiosk(kioskId);
}

@Override
public List<Long> getProductByKioskId(long kioskId) 
{
	return AddProductKioskServiceDao.getProductByKioskId(kioskId);
}

@Override
public ProductKiosk getProductKioskByproductId(long productId,long kioskid) {
	// TODO Auto-generated method stub
	return AddProductKioskServiceDao.getProductKioskByproductId(productId,kioskid);
}

@Override
public List<ProductKiosk> getAllProductListByProductTypeandKiosk(long kioskId, List<Long> productObj,
		long productType, int pagenumber, int pagerecord) {
	// TODO Auto-generated method stub
	return AddProductKioskServiceDao.getAllProductListByProductTypeandKiosk(kioskId, productObj, productType, pagenumber, pagerecord);
}


}
