package pharmabox.service;

import java.util.List;

import pharmabox.domain.Basket;
import pharmabox.domain.BasketStatus;
import pharmabox.domain.Kiosk;
import pharmabox.domain.Rewards;


public interface IBasketService {
	
	public Long registerNewToBasket(Basket Basket);

	 //public Long getBucket(Bucket Bucket);

	public List<Basket> getBasket();
	
	public List<Basket> getBasketByIdandPurchase(Long userId, boolean purchase);

	//public Bucket getId(long Bid);

	public void delete(long bid);

	public Basket getBid(Long bid);

	public Basket getProductkioskAndUser(long productkiosk_id, long user_id);

	public void updateBasket(Basket basket);

	public long getBasketByIdandPurchaseCount(long user_id, boolean b);

	public List<Basket> getpaypalid(long paypalId);

	public BasketStatus setBasketStatus(long id);

	public List<Basket> getBasketByIdandPurchaseandstatus(long userId, long basketStatus, boolean purchase);

	public List<Basket> getAllBasketByStatus(long basketstatusId);

	public Basket getBasket(long userId);

	public List<Basket> getBasketlist(long user_id, int pagenumber, int pagerecord);

	public List<Basket> getBasketlistByUserid(long user_id);

	public List<Basket> getBasketBypaypalid(long paypalId);

	public long getcountofBasketlistByUserid(long user_id);
	
	public Basket getBasketByUser(long userId,long bid);

	public long getBasketCount(long user_id);

	public void updateBasketQuantity(long quantity,long pid);

	//public Product getKioskbyProduct(long pid);
	
	public Kiosk getKioskbyProduct(long pid);

	public List<Basket> getbasketforkioskcheck(long userId);

	public Basket getQuantityOfBasketProduct(long userId);
	
	public Basket getKioskByBasketProductKioskId(long productKioskId);
	
	public Basket getProductKioskUser(long productKioskId);
	
	public Basket getProductKioskByUser(long userId);

	public List<Basket> getBasketlistByUseridwithpagination(long user_id, int pagenumber, int pagerecord);

	public Basket getbyproductkioskid(long id);
	
	public List<Basket> getBasketbyList(List<Long> bid);
	
	public List<Basket> getBasketbyRewardPurchase(List<Long> bid);
	
	public Basket getBasketByBid(long bid);
	
	public List<Basket> getBasketByrewardsCheck(long user_id);

	public Basket getbasketbyproductkioskidanduserid(long id, long userId);
	
	public List<Basket> getBasketInfo(long userId);
	
	public Basket getbasketbyCartDetails(long pid,long userId);
	
	public void UpdateBasketActive(long bid);
	
	public List<Basket> getBasketbyListCheck(List<Long> bid,long userId);
	
	public Basket getbasketDetailsbypid(long pid,long userId);
	
	public Basket getBasketId(long bid);
	
	public Basket getBasketByRewardsCheck(long bid);
	
	public List<Basket> getBasketByRewards(List<Long> bid);
	
	public boolean getBasketByProductKioskandUser(long id, long userId);

	public Basket getBasketByProductKioskAndUser(long id, long userId);

	public void updateRewardsInfo(float totalamount, float discountedPrice, float rewardsPrice, Rewards reward,boolean b,long userId);
	



	

	
	
}
