package pharmabox.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pharmabox.dao.IKioskDAO;
import pharmabox.domain.Kiosk;
import pharmabox.domain.ProductKiosk;
import pharmabox.views.KioskView;

@Service("IKioskService")
public class KioskService implements IKioskService {

	@Autowired
	IKioskDAO kioskDAO; 

	@Override
	public long registerKioskDetails(Kiosk kioskObj) {		
		return kioskDAO.registerKioskDetails(kioskObj);
	}

	@Override
	public void updateKiosk(Kiosk kiosk) {		
		kioskDAO.updateKiosk(kiosk);
	}

	@Override
	public List<Kiosk> getAllKioskDetails() {		
		return  kioskDAO.getAllKioskDetails();
	}

	@Override
	public List<Kiosk> getAllSearchKioskDetails(String searchValue) {		
		return kioskDAO.getAllSearchKioskDetails(searchValue);
	}
	@Override
	public Kiosk getKioskById(long kiosk_id) {
		System.out.println("entered kios id");
		return kioskDAO.getKioskById(kiosk_id);
	}

	@Override
	public List<Kiosk> getAllKioskMap(String latitude, String longitude) {
		return kioskDAO.getAllKioskMap(latitude, longitude);
	}

	@Override
	public List<Kiosk> getAllKioskList(int pagenumber, int pagerecord) {		
		return kioskDAO.getAllKioskList(pagenumber,pagenumber);
	}

	@Override
	public List<Kiosk> getKioskLocationDetail(long kiosk_id) {		
		return kioskDAO.getKioskLocationDetail(kiosk_id);
	}

	@Override
	public void deleteKiosk(long kiosk_id) {	
		kioskDAO.deleteKiosk(kiosk_id);
	}

	@Override
	public List<Kiosk> getAllKioskListByActions() {		
		return kioskDAO.getAllKioskListByActions();
	}

	@Override
	public Kiosk getKioskByKioskId(long id) {		
		return kioskDAO.getKioskByKioskId(id);
	}

	@Override
	public Kiosk getKioskByKioskIdAction(long id) {
		return kioskDAO.getKioskByKioskIdAction(id);
	}

	@Override
	public Kiosk getKioskByIdWithoutAction(long kiosk_id) {
		return kioskDAO.getKioskByIdWithoutAction(kiosk_id);
	}
	
	@Override
	public Kiosk getKioskId(long kioskId)
	{
		return kioskDAO.getKioskId(kioskId);
	}
	
	@Override
    public Kiosk getKioskName(String kioskName)
	{
		return kioskDAO.getKioskName(kioskName);
    }

	@Override
	public Kiosk getKioskBypId(long product_id)
	{
		return kioskDAO.getKioskBypId(product_id);
	}


	@Override
	public ProductKiosk getKioskByProductKioskId(long productkioskid) {
		return kioskDAO.getKioskByProductKioskId(productkioskid);
	}

	public List<Kiosk> getKioskListByProductId(long pid) {
		return kioskDAO.getKioskListByProductId(pid);
	}

	public List<Kiosk> getAllKioskListByKioskId(long kid) {
		return kioskDAO.getAllKioskListByKioskId(kid);
	}

	public List<Kiosk> getAllKioskListUsingKioskId (List<Long> pkObj) {
		return kioskDAO.getAllKioskListUsingKioskId(pkObj);
	}

	public List<Kiosk> getAllKioskListByProduct(long pid, int pagenumber, int pagerecord) {
		return kioskDAO.getAllKioskListByProduct(pid,pagenumber,pagerecord);
	}

	@Override
	public long getAllKioskListByProductcount(long pid) {
		return kioskDAO.getAllKioskListByProductcount(pid);
	}
	
	@Override
	public List<KioskView> getAllKioskViewListByProducts(long pid, int pagenumber, int pagerecord) {
		return kioskDAO.getAllKioskViewListByProducts(pid,pagenumber,pagerecord);
	}

	@Override
	public long getAllKioskViewListByProductscount(long pid) {
		return kioskDAO.getAllKioskViewListByProductscount(pid);
	}

	@Override
	public Kiosk getKioskByKioskID(long kioskId) {
		return kioskDAO.getKioskByKioskID(kioskId);
	}

	
	
}