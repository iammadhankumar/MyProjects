package pharmabox.service;

import pharmabox.domain.OrderBasket;

public interface IOrderBasketService {

	public long  registerNewOrder(OrderBasket orderBasketObj);

}
