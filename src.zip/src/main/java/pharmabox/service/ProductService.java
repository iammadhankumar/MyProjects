package pharmabox.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pharmabox.dao.IProductDAO;
import pharmabox.domain.FavProduct;
import pharmabox.domain.Kiosk;
import pharmabox.domain.Product;
import pharmabox.domain.ProductType;
import pharmabox.domain.RecentViewProducts;

@Service("IProductService")
public class ProductService implements IProductService {

	@Autowired
	IProductDAO productDao;

	@Override
	public Product getAllProductList() {		
		return productDao.getAllProductList();
	}

	@Override
	public Product getById(long id) {
		return productDao.getById(id);
	}
	
	@Override
	public Product getpId(long id) {
		return productDao.getpId(id);
	}

	@Override
	public void deleteProduct(String productId) {		
		productDao.deleteProduct(productId);
	}

	@Override
	public Product getProductByProductId(String productId) {		
		return productDao.getProductByProductId(productId);
	}
	@Override
	public List<Product>  getProductByName(String productName) {		
		return productDao.getProductByName(productName);
	}

	@Override
	public Long addNewProduct(Product product) {		
		return productDao.addNewProduct(product);
	}

	@Override
	public Long addNewKiosk(Kiosk kiosk) {		
		return productDao.addNewKiosk(kiosk);
	}

	@Override
	public void updateProduct(Product product) {		
		productDao.updateProduct(product);
	}
	@Override
	public void updateFavProduct(FavProduct fav) {		
		productDao.updateFavProduct(fav);
	}

	@Override
	public void updateProductStatus(String productId) {
		productDao.updateProductStatus(productId);
	}

	@Override
	public List<Product> getProduct() {		
		return productDao.getProduct();
	}
	
	
	@Override
	public List<ProductType> getAllProductType()
	{
		return productDao.getAllProductType();
	}
	
	@Override
	public Product getByProduct() {		
		return productDao.getByProduct();
	}

	@Override
	public ProductType getProductTypeId(long productTypeId) {
		return productDao.getProductTypeId(productTypeId);
	}

	@Override
	public  List<Product> getProductNames(long productTypeId,int pagenumber,int pagerecord) {
		return productDao.getProductNames(productTypeId,pagenumber,pagerecord);
	}

	@Override
	public FavProduct getByProductId(long id, long userId) {
		return productDao.getByProductId(id,userId);
	}

	@Override
	public Long addNewFavProduct(FavProduct fav) {
		return productDao.addNewFavProduct(fav);
	}

	

	@Override
	public List<FavProduct> getFavListsById(long userId,int pagenumber,int pagerecord)
	{
		return productDao.getFavListsById(userId,pagenumber,pagerecord);
	}

	@Override
	public List<Product> getProductlist(int pagenumber, int pagerecord) {
		return productDao.getProductlist(pagenumber,pagerecord);
	}

	
	@Override
	public List<ProductType> getProductTypeList(int pagenumber, int pagerecord) {
		return productDao.getProductTypeList(pagenumber, pagerecord);
	}

	
	@Override
	public long getcountByUserIdAndActive(long user_id) {
		return productDao.getcountByUserIdAndActive(user_id);
	}

	@Override
	public Long addNewProductType(ProductType PTObj)
	{
		return productDao.addNewProductType(PTObj);

	}
	@Override
	public ProductType getProductTypeName(String productTypeName)
	{
		return productDao. getProductTypeName(productTypeName);
	}
	
	@Override
	public Product getProductName(String productName)
	{
		return productDao. getProductName(productName);
	}
	
	
	@Override
	public List<Product> getProductTypeBylist(long productTypeId,int pagenumber, int pagerecord)

	{
		return productDao.getProductTypeBylist(productTypeId,pagenumber,pagerecord);
	}

	@Override
	public List<String> getProductFavouriteByUser(long userId) {
		return productDao.getProductFavouriteByUser(userId);
	}

	@Override
	public long getProductcountbyproductTypeId(long productTypeId) {
		return productDao.getProductcountbyproductTypeId(productTypeId);
	}

	@Override
	 public List<Product> addProduct(List<Product> product)
	 {
		return productDao.addProduct(product);
	 }
       
	@Override
	public Product getKioskbyProductId(long primarypId) {
		return productDao.getKioskbyProductId(primarypId);
	}
	
	@Override
	public Product getQuantityOfBasketProduct(long primarypId)
	{
		return productDao.getQuantityOfBasketProduct(primarypId);
	}

	@Override
	public Product getProductDetails(String pname, long pqt, String pid) {
		return productDao.getProductDetails(pname, pqt, pid);
	}
	
	
	@Override
	public ProductType getProductTypeIdByProductTypeName(String pname)
	{
		return productDao.getProductTypeIdByProductTypeName(pname);
	}
	
	@Override
	public Product getProductId(String pid)
	{
		return productDao.getProductId(pid);
	}
	
	@Override
	public List<Product> getSearchProductDetails(String searchValue)
	{
		return productDao.getSearchProductDetails(searchValue);
	}
	
	@Override
	public List<Product> getAllSearchProductDetails(String searchValue,int pagenumber,int pagerecord) 
	{
		return productDao.getAllSearchProductDetails(searchValue,pagenumber,pagerecord);
	}
	
	
	@Override
	public List<Product> getAllProductListByProductKiosk(List<Long> pkobj)
	{
		return productDao.getAllProductListByProductKiosk(pkobj);
	}
	
	
	@Override
	public List<Product> getAllProductListByProductObj(List<Long> productId,int pagenumber,int pagerecord)
	{
		return productDao.getAllProductListByProductObj(productId,pagenumber,pagerecord);
	}
	
	@Override
	public List<FavProduct> getFavProductListByProductId(List<Product> productObj,long userId)
	{
		return productDao.getFavProductListByProductId(productObj,userId);
	}
	
	@Override
	public List<Product> getAllProductListByPk(long kioskId,int pagenumber,int pagerecord)
	{
		return productDao.getAllProductListByPk(kioskId,pagenumber,pagerecord);
	}
	
	@Override
	public List<Product> getProductListByProductTypeandKiosk(long kioskId,long productType)
	{
		return productDao.getProductListByProductTypeandKiosk(kioskId, productType);
	}

	@Override
	public List<Product> getAllProductListByProductTypeandKiosk(long kioskId,long productType,int pagenumber,int pagerecord)
	{
		return productDao.getAllProductListByProductTypeandKiosk(kioskId,productType,pagenumber,pagerecord);
	}
	
	@Override
	public List<Product> getSearchProductListByKiosk(long kioskId,String searchValue)
	{
		return productDao.getSearchProductListByKiosk(kioskId,searchValue);
	}
	
	@Override
	public List<Product> getProductListByKiosk(long kioskId,String searchValue,int pagenumber,int pagerecord)
	{
		return productDao.getProductListByKiosk(kioskId,searchValue,pagenumber,pagerecord);
	}

	@Override
	public List<RecentViewProducts> getAllRecentViewProductsByUser(long user,Date date,int pagenumber, int pagerecord) {
		return productDao.getAllRecentViewProductsByUser(user,date,pagenumber, pagerecord);
	}

	@Override
	public long getRecentViewCount(long user,Date date) {
		return productDao.getRecentViewCount(user,date);
	}

	@Override
	public List<RecentViewProducts> getAlreadyViewedProduct(long user, long productid) {
		return productDao.getAlreadyViewedProduct(user, productid);
	}

	@Override
	public RecentViewProducts selectLastRowTable(long user) {
		return productDao.selectLastRowTable(user);
	}

	@Override
	public List<Product> getAllProductListByKiosk(long id,long productTypeid,int pagenumber, int pagerecord) {
		return productDao.getAllProductListByKiosk(id,productTypeid,pagenumber,pagerecord);
	}

	@Override
	public long getAllProductListByKioskCount(long id, long productTypeid, int pagenumber, int pagerecord) {
		return productDao.getAllProductListByKioskCount(id, productTypeid, pagenumber, pagerecord);
	}

	@Override
	public long getProductCountByBasket(long kid) {
		return productDao.getProductCountByBasket(kid);
	}

	@Override
	public Date getIntervelDate() {
		return productDao.getIntervelDate();
	}

	@Override
	public void updateProductType(ProductType pTObj) {
		 productDao.updateProductType(pTObj);
		
	}
	
	

}