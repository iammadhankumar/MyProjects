package pharmabox.service;

import java.util.List;

import pharmabox.domain.DeviceToken;
import pharmabox.domain.User;
import pharmabox.domain.UserType;

public interface IUserService {

	public long registerNewUser(User userObj);

	public User getUserByEmail(String email);
	
	
	public UserType getUserTypeById(long userType);
	
	
	public User getUserById(long user_id);
	
	public User getUserById(User user);
	public List<User> getAllUsers();

    
	public User getUserByFacebook(String facebook_id);
	
	public void updateUser(User user);
	public DeviceToken getDeviceTokenByUserId(long user_id);
	public void saveDeviceToken(DeviceToken token);
	public void updateDeviceToken(DeviceToken token);
	public User getUserPasswordByEmailId(String email);
	public User getLocation(long userId);
	public User getUserByuserIdAndNotification(long userID, boolean b);
	List<User> getAllUsersByStatus(int stat);

	public User getUserByEmailAndType(String email, long type);

	
}
