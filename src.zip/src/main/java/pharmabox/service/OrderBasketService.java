package pharmabox.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pharmabox.dao.IOrderBasketDAO;
import pharmabox.domain.OrderBasket;

@Service("IOrderBasketService")

public class OrderBasketService implements IOrderBasketService {

	@Autowired
	IOrderBasketDAO orderBasketDao;

	@Override
	public long registerNewOrder(OrderBasket orderBasketObj) {
		return orderBasketDao.registerNewOrder(orderBasketObj);
	}

	

	
}
