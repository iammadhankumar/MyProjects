package pharmabox.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pharmabox.domain.DeviceToken;
import pharmabox.domain.User;
import pharmabox.service.UserService;


@Service
@Transactional
public class PushNotification implements IPush{

	protected final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private UserService userRepo;

//	@Autowired
//	private DeviceRepository deviceRepo;

	public final static String API_URL_FCM = "https://fcm.googleapis.com/fcm/send";//MessageConstants.FCMURL;	

	@Override
	public void pushMessage(String msg, long userID, long badge) {
		User user=null;		 
		String token = "";
		try {			
			user=userRepo.getUserByuserIdAndNotification(userID, true);
			if (user != null) {
				logger.info("userId  "+userID);
				long userId = userID;
				DeviceToken dvt  =	userRepo.getDeviceTokenByUserId(userId);
				if(dvt!=null){
					token = dvt.getDeviceToken();
					logger.info("token::"+token);
					if(token!=null){							
						sendMsgs(msg,badge,token);
					}else{
						logger.info("cannot find token");
					}
				}
				else{
					logger.info("device token empty");
				}
			}
			if (user == null) {
				token = "";
				msg = "";
				badge = 0;
			}
		} catch (Exception e) {
			logger.error("pushMessage",e);
		}
	}

	@SuppressWarnings("unchecked")
	private void sendMsgs(String msg, long badge, String deviceToken) {
		String token = deviceToken;
		String SERVER_API_KEY= "AAAAF6Lec-s:APA91bHFeTkvGhuLkKK58vmk4PuJVfdbwQuw_etJY46G7xNlES4uHafFiaOPk7Dj6zvztMKcsfycy6QNmbIZtyyRH8JQdIddQWN7Pw8BuNMTPxJp2tY4kRQw6mFhea9qMpEiRgPmX4_p";//MessageConstants.FCMSERVERAPIKEY;
		try{			
			URL url = new URL(API_URL_FCM);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setUseCaches(false);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Authorization","key="+SERVER_API_KEY);
			conn.setRequestProperty("Content-Type","application/json");
			JSONObject json = new JSONObject();
			JSONObject infonotify = new JSONObject();
			json.put("to",token.trim());
			JSONObject info = new JSONObject();
			info.put("title", "Front Forty"); // Notification title
			info.put("body", msg);   // Notification Body
			infonotify.put("message", "message from Front Forty");
			infonotify.put("priority", "high");
			json.put("notification", info);
			json.put("data", infonotify);
			OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
			wr.write(json.toString());
			wr.flush();
			conn.getInputStream();
			logger.info ("val::"+json);
			int responseCode = conn.getResponseCode();
			logger.info("\nSending 'POST' request to URL : " + url);
			logger.info("Post parameters : " + json);
			logger.info("Response Code : " + responseCode);
			if(responseCode==200){
				BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				logger.info("response ok::: "+in.readLine());
			}else if(responseCode==401){
				logger.info("unauthorized failed::: ");
			}else if(responseCode==501){
				logger.info("token failed::: ");
			}else if(responseCode==503){
				logger.info("cannnot send failed::: ");
			}
		} catch (IOException e) {
			logger.error("sendMsgs", e);
		}catch (Exception e) {
			logger.error("sendMsgs", e);
		}
	}
}