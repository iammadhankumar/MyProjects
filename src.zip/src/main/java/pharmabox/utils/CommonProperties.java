package pharmabox.utils;


import java.util.ResourceBundle;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class CommonProperties {

	private static ResourceBundle commonBundle = getResourceBundle();
	private static final Logger logger = LogManager.getLogger(CommonProperties.class);
	// Bundle Names  
	public static final String COMMON = "application";
	
//	private static final String FILENAME = "resources/skyscrapper";
//  PropertyResourceBundle resourceBundle = new PropertyResourceBundle(FILENAME);	
//private static ResourceBundle resourceBundle = ResourceBundle.getBundle(FILENAME);
//private static PropertyResourceBundle 
//	public static String getProperty(final String key) {
//	    String str = null;
//	    if (resourceBundle != null) {
//	        str = resourceBundle.getString(key);
//	        logger.debug("Value found: " + str + " for key: " + key);
//	    } else {
//	    	logger.debug("Properties file was not loaded correctly!!");
//	    }
//	    return str;
//	}
	
	private static ResourceBundle getResourceBundle() {
		return getResourceBundle(COMMON);
	}

	
	private static ResourceBundle getResourceBundle(String bundleName) {
		ResourceBundle bundle = null;
		bundle = ResourceBundle.getBundle(bundleName);
		return ResourceBundle.getBundle(bundleName+"-"+bundle.getString("spring.profiles.active"));
	}

	/** Get Common Properties **/
	private static String getString(String key) {
		return commonBundle.getString(key);
	}

	public static String getBaseURL() {
		System.out.println(getString("baseURL"));
		return getString("baseURL");
	}

	public static String getBasePath() {
		return getString("basePath");
	}

	public static String getContextPath() {
		return getString("contextPath");
	}

	public static String getUiPath() {
		return getString("UiPath");
	}
	public static String getTempFilePath() {
		return getString("tempFile");
	}

	public static String getUserProfileImagePath() {
		return getString("userProfileImagePath");
	}

	public static String getImagePath() {
		return getString("imagePath");
	}
	public static String getCategoryImagePath() {
		return getString("categoryimagepath");
	}
	public static String getBalance() {
		return getString("debitBalance");
	}

	public static String getAutoreloadamount() {		
		return getString("autoreloadamount");
	}

	public static String getBarcode() {		
		return getString("barcode");
	}
	
	public static String getTransactionBarcode(){
		return getString("transactionbarcode");
	}
	
	public static String getCorporateFileName() {
		return getString("cotrporateuser.fileName");
	}
	
	public static String getFrontEndPath() {
		return getString("frontEndPath");
	}
	
	public static String getFrontURL() {
		return getString("frontURL");
	}
	
	public static String getCreditAmount() {		
		return getString("creditAmount");
	}
	
	public static String getBannerImage() {
		return getString("bannerImage");
	}
	
	public static String getUserName() {
		return getString("username");
	}
	
	public static String getPassword() {
		return getString("password");
	}
	
	public static String gettwitterLogo() {
		return getString("twitterLogo");
	}
	
	public static String getFacebookLogo() {
		return getString("facebooklogo");
	}
	
	public static String getinstragramLogo() {
		return getString("instragramLogo");
	}
	
	public static String getpinterestLogo() {
		return getString("pinterestLogo");
	}
	public static String getimageLogo() {
		return getString("imageLogo");
	}
	
	public static String gettemplate() {
		return getString("template");
	}
	
	public static String getProduct() {		
		return getString("product");
	}
	
	public static String getReward() {
		return getString("reward");
	}
	
	public static String getScrollingContent() {		
		return getString("scrollingcontent");
	}
}