package pharmabox.utils;

import java.security.Principal;
import java.util.Date;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pharmabox.domain.User;
import pharmabox.service.IUserService;

@Service
public class UserByToken {
	
	@Autowired
	IUserService userservice;
	
	private Random random = new Random();
	
	public User getUser(final HttpServletRequest request){	
		if(request != null && request.getUserPrincipal()!= null){
		  Principal principal = request.getUserPrincipal();
		  long user_id = Long.parseLong(principal.getName());
		  System.out.println(principal.getName());
		  User usc = userservice.getUserById(user_id);
		  System.out.println(usc);
		  return (usc != null)?usc:null;
		} else {
			return null;
		}
	}

	
	 public String randomReferenceString()
	    {
	        char[] chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();
	        StringBuilder sb = new StringBuilder();
	        for (int i = 0; i < 6; i++)
	        {
	            sb.append(chars[random.nextInt(chars.length)]);
	        }
	        sb.append((100 + random.nextInt(900)));
	        Long.toString(new Date().getTime());
	        return sb.toString()+Long.toString(new Date().getTime());
	    }
}
