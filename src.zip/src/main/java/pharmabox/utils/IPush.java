package pharmabox.utils;

public interface IPush {

	void pushMessage(String msg, long userID, long badge);
}