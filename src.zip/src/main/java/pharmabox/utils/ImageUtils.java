package pharmabox.utils;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;

import javax.imageio.ImageIO;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;


public class ImageUtils implements Serializable {

	private static final long serialVersionUID = 1L;


	private static final Logger logger = LogManager.getLogger(ImageUtils.class);


	private static ImageUtils myImageInstance = null;
	public static ImageUtils getInstance()
	{
		if(myImageInstance == null)
			myImageInstance = new ImageUtils();
		return myImageInstance;
	}

	public String uploadImage(InputStream imageFileStream,
			String imageName,
			String uploadedFileLocation, long  userId) {
		String filePath = null;
		String fileName = imageName;
		try {
			fileCreation(uploadedFileLocation);
			if(fileName.matches(".*\\s+.*")){
				fileName=replaceFileNameSpaces(fileName);
			}
			uploadedFileLocation = uploadedFileLocation + "/" + fileName;
			Boolean status = writeToFile(imageFileStream, uploadedFileLocation);
			if(status == true && fileName != null && !fileName.isEmpty()){
				filePath = fileName;
			}else{
				filePath = "";
			}
		} catch (Exception e) {
     logger.error("uploadImage ", e);		} finally {
		}
		return filePath;
	}
	private String replaceFileNameSpaces(String fileName) {
		String extension ="";
		String[] split = fileName.split("\\.");
		extension = split[split.length - 1];
		String file=split[split.length - 2];
		file=file.replaceAll(" ","_");
		fileName=file+"."+extension;
		return fileName;
	}
	/**
	 * 
	 * @param imageFileStream
	 * @param imageFileDetails
	 * @param uploadedFileLocation
	 * @return
	 *//*
	public String uploadChapterImage(InputStream imageFileStream,
			FormDataContentDisposition imageFileDetails,
			String uploadedFileLocation, int  userId) {
		String filePath = null;
		String fileName = imageFileDetails.getFileName();
		try {
			fileCreation(uploadedFileLocation);
			if(fileName.matches(".*\\s+.*")){
				fileName=replaceFileNameSpaces(fileName);
			}
			uploadedFileLocation = uploadedFileLocation + "/" + fileName;
			Boolean status = writeToFileImage(imageFileStream, uploadedFileLocation);
			if(status == true && fileName != null && !fileName.isEmpty()){
				filePath = fileName;
			}else{
				filePath = "";
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
		return filePath;
	}*/
	/**
	 * 
	 * @param uploadedFileLocation
	 */
	public void fileCreation(String uploadedFileLocation) {
		File file = new File(uploadedFileLocation);
		String[] myFiles;
		if (!file.isDirectory()) {
			new File(uploadedFileLocation).mkdirs();
		} else {
			myFiles = file.list();
			for (int i = 0; i < myFiles.length; i++) {
				File myFile = new File(file, myFiles[i]);
				//myFile.delete();
				//System.out.println("folder is exists");
			}
		}
	}
	// save uploaded file to new location
	/*private Boolean writeToFileImage(InputStream uploadedInputStream,String uploadedFileLocation) {
		//create directory 
		File file = new File(uploadedFileLocation);
		try {
			BufferedImage img = ImageIO.read(uploadedInputStream);
			//scale the image 
			BufferedImage scaledImg = Scalr.resize(img,org.imgscalr.Scalr.Method.QUALITY, 150,150);
			ImageIO.write(scaledImg, "png",file);					
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}*/

	// save uploaded file to new location
	public Boolean writeToFile(InputStream uploadedInputStream,
			String uploadedFileLocation) throws IOException {
		
	
	     File fl = new File(uploadedFileLocation);
	     
	    try( FileOutputStream out = new FileOutputStream(fl))
	    
	    {
			int read = 0;
			byte[] bytes = new byte[20480];
	
			try(FileOutputStream out1 = new FileOutputStream(new File(uploadedFileLocation)))
			{
			
			
			while ((read = uploadedInputStream.read(bytes)) != -1) {
				out1.write(bytes, 0, read);
			}
			out1.flush();
			out1.close();
			
		
	    }
	    }
		 catch (IOException e) {
			 logger.error("writeToFile ", e);			
			 return false;
		}
		
		return true;
	}

	/**
	 * Store the image 
	 * @param tempImageName 
	 * @param request
	 * @return
	 * @throws IOException
	 */
	/*public String saveImage(int userId,String content,String title, String tempImageName) throws IOException{
		String sourcePath = CommonProperties.getBasePath()+CommonProperties.getTempFilePath()+userId;
		String extension ="";
		String filename = "";
		String filePath="";
		if(sourcePath != null){
			File sourceFile = new File(sourcePath);
			if(sourceFile.isDirectory()){
				File [] files = sourceFile.listFiles();
				if(files.length > 0){
					for (int i = 0; i <files.length; i++){
						filename = files[i].getName();
						if(tempImageName.equalsIgnoreCase(filename)){
							String sourcePathImage= "";
							String targetPathImage = CommonProperties.getBasePath()+CommonProperties.getBuildFilePath()+content;
							if(sourcePath != null){
								String[] split = filename.split("\\.");
								extension = split[split.length - 1];
								String file=split[split.length - 2];
								file=file.replaceAll(" ", "_");
								filename=file+"."+extension;
								if(extension.equalsIgnoreCase("jpeg") || extension.equalsIgnoreCase("jpg") || extension.equalsIgnoreCase("png") || extension.equalsIgnoreCase("gif")){  
									sourcePathImage = sourcePath+"/"+filename;
									targetPathImage = targetPathImage+"/";
									new File(targetPathImage).mkdirs();
									copyImages(sourcePathImage,targetPathImage,title+"_"+filename);
									if(filename != null && !filename.isEmpty()){
										filePath =CommonProperties.getBaseURL()+CommonProperties.getBuildFilePath()+content+"/"+title+"_"+filename; 
									}else{
										filePath ="";
									}
									delete(files);	
									return filePath;
								}
							}
							
						}
					}
						

				}

			}
		}
		return null;
	}*/

	//Delete the corresponding user temp directory
	//once the file has been moved to image directory 
	//and stored in database	
	/*private void delete(File[] files) {
		// TODO Auto-generated method stub
		if(files.length >0){
			for (int i = 0; i <files.length; i++){
				files[i].delete();
				File path = null;
				IoUtils.getInstance().deleteDirectory(path);
			}
		}
	}*/
	public static boolean copyImages(String sourcePath,String targetPath,String targetName)
	{
		boolean flag = false;
		BufferedImage image = null;
		try {
			String[] split = sourcePath.split("\\.");
			String ext = split[split.length - 1];
			image = ImageIO.read(new File(sourcePath));
			flag = ImageIO.write(image, ext, new File(targetPath+"/"+targetName));
		} catch (IOException e) {
			logger.error("copyImages :"+e);
		}
		finally
		{
			if(image != null)
			{
				image.flush();
			}
		}
		return flag;
	}
}
