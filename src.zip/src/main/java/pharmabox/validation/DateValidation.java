package pharmabox.validation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;

public class DateValidation {

	
    public static boolean pastDateValidation(Date date)
    {
        if(date != null)
        {
            
        Instant givenInstant = date.toInstant();
        Instant currentdate = Instant.now();
        return currentdate.isBefore(givenInstant)?true:false;
      //  return currentdate.is(givenInstant)?true:false;
        }
        return false;
    }
    
    public static boolean pastDateStringValidation(String dateString) throws ParseException
    {
    	 Date date=new SimpleDateFormat("dd-MM-yyyy").parse(dateString); 
    	  Instant givenInstant =null;
          Instant currentdate=null;
        if(date != null)
        {
            
        givenInstant = date.toInstant();
        currentdate = Instant.now();
      
        return currentdate.isBefore(givenInstant)?true:false;
      //  return currentdate.is(givenInstant)?true:false;
        }
        
        return false;
    }
    
    
    public static boolean intervalDateValidation(Date date)
    {
        if(date != null)
        {
        	//LocalDate date = LocalDate.date.plusDays(2);
        Instant givenInstant = date.toInstant();
        Instant currentdate = Instant.now();
        //LocalDateTime localDate = LocalDateTime.+plusDays(2);
	     
      //  System.out.println(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(localDate));

        return currentdate.isBefore(givenInstant)?true:false;
      //  return currentdate.is(givenInstant)?true:false;
        }
        return false;
    }
    
    
    
}
