package pharmabox.validation;

public class KioskValidation {
	
	public static String checkKioskFieldsEmpty(long kioskId,String kioskName,double latitude,double longitude,String address)
	{
		System.out.println("check validation");
		if(kioskId<=0)
		{
			return "kioskId is required";
		}
		
		if(kioskName==null || kioskName.isEmpty())
		{
			return "kioskName is required";
		}
		
		if(latitude==0)
		{
			return "latitude can be required";
		}
		
		if(longitude==0)
		{
			return "longitude can be required";
		}
		
		
		if(address==null || address.isEmpty())
		{
			return "address can be required";
		}
		
	
		return "okay";
	}

}