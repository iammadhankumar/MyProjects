package pharmabox.validation;
import java.util.regex.Pattern;




public class UserValidation{
	
	public static boolean isAlphaNumeric(String password) {
		
		Pattern pattern = Pattern.compile("((?=.*[0-9])(?=.*[!?@#$%^&*()._-]).{8,})");
		return pattern.matcher(password).matches();
	}
		
	public static boolean isEmailFormat(String email) {
	 
  Pattern pattern = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
	return pattern.matcher(email).matches();
	
}
	
	public static String checkUserFieldsEmpty(String email,String first_name, String last_name, boolean b, boolean c) {
		
		if(email == null || email.isEmpty())
		{
			System.out.println("email null");
			return "Email is required";
		}
					if(first_name == null || first_name.isEmpty())
					 {
						System.out.println("fn null");
						return "FirstName is required";
						
					 }
				
				
				if(last_name == null || last_name.isEmpty())
				{
					System.out.println("ln null");
					return "LastName is required"; 
				}
				
				
		return "Success";
	}
	
	
	
	
	public static String checkUpdateFieldsEmpty(String email,String first_name,String last_name,boolean t,boolean p)
	{
		
		if(email == null || email.isEmpty())
		{
			
			return "Email is required";
		}
		
		if(first_name == null || first_name.isEmpty())
		 {
		
			return "FirstName is required";
			
		 }
		
		if(last_name == null || last_name.isEmpty())
		{
			
			return "LastName is required"; 
		}
		return "Success";
	}
	
	
	




}
