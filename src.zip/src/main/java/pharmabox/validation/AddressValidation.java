package pharmabox.validation;

import java.util.regex.Pattern;

public class AddressValidation {
	
     public static boolean isPhoneNumber(String phoneNumber) {
		
		Pattern pattern = Pattern.compile("^(\\+\\d{1,2}\\s)?\\(?\\d{3}\\)?[\\s.-]\\d{3}[\\s.-]\\d{4}$");
		return pattern.matcher(phoneNumber).matches();
	}
     
     public static boolean isZipcode(String zipcode) {
 		
 		Pattern pattern = Pattern.compile("(?!^[0-9]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9]{6,15})$");
 		return pattern.matcher(zipcode).matches();
 	}
 	
	
	
	
	
	public static String checkAddressFieldsEmpty(String fullName,String street,String city,String state,String zipcode,String phoneNumber,String country)
	{
		System.out.println("check validation");
		if(fullName==null || fullName.isEmpty())
		{
			return "fullName is required";
		}
		
		if(street==null || street.isEmpty())
		{
			return "street can be required";
		}
		
		if(city==null || city.isEmpty())
		{
			return "city can be required";
		}
		
		if(state==null || state.isEmpty())
		{
			return "state can be required";
		}
		
		
		if(zipcode==null || zipcode.isEmpty())
		{
			return "zipcode can be required";
		}
		
		
       if(isPhoneNumber(phoneNumber))
       {
    	   return "Give the phonenumber correctly";
       }
		
       
       if(country==null || country.isEmpty())
       {
    	   return "Country is required";
       }
       
       if(isZipcode(zipcode) || phoneNumber.length()>10 || phoneNumber.length()<10)
       {
    	   return "Give the zipcode correctly";
       }
		
		return "okay";
	}

}
