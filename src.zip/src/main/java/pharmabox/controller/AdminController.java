package pharmabox.controller;

import java.io.IOException;

import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import pharmabox.customdomain.KioskInput;
import pharmabox.customdomain.ProductInput;
import pharmabox.customdomain.RewardsInput;
import pharmabox.customdomain.ScrollingContentInput;
import pharmabox.helper.AdminHelper;
import pharmabox.response.AddProductResponse;
import pharmabox.response.ImageResponse;
import pharmabox.response.KioskMessages;
import pharmabox.response.OrderMessages;
import pharmabox.response.ResponseStatus;
import pharmabox.response.RewardMessage;
import pharmabox.response.RewardMessages;
import pharmabox.response.ScrollingContentMessage;
import pharmabox.response.ScrollingContentMessages;
import pharmabox.response.SelectedKioskMessage;
import pharmabox.response.UserMessages;

@EnableAutoConfiguration
@SpringBootApplication
@RestController
@MultipartConfig(maxFileSize = 1024 * 1024 * 1024, maxRequestSize = 1024 * 1024 * 1024)
public class AdminController {


	@Autowired
	AdminHelper adminhelper;
	


	@RequestMapping(value = "/viewusers", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody UserMessages viewUsers(@RequestParam(value="stat",required=false) int stat,final HttpServletResponse response) 
	{
		return adminhelper.viewUsers(stat, response);
		
	}
	
	@RequestMapping(value = "/addrewards", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody RewardMessage addRewards(@RequestBody RewardsInput RewardsInputObj,final HttpServletRequest request, HttpServletResponse response)
	{
		return adminhelper.addRewards(RewardsInputObj, request, response);
			
	}
	
	@RequestMapping(value = "/getAllRewardList", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody RewardMessages getAllRewardList(
			@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,
			@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,
			@RequestParam(value="all", required=false ,defaultValue = "0") int all,HttpServletRequest request, HttpServletResponse response) 
	{
		return adminhelper.getAllRewardList(pagenumber, pagerecord, all, request, response);
		
	}
	
	
	@RequestMapping(value = "/getRewardList", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody RewardMessages getRewardList(
			@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,
			@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,
			HttpServletRequest request, HttpServletResponse response)
	{
		return adminhelper.getRewardList(pagenumber, pagerecord, request, response);
		
	}


	@RequestMapping(value = "/getrewardsbyid", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody RewardMessage getRewardById(@RequestParam(value = "rewardId") long rewardId,HttpServletRequest request, HttpServletResponse response)
	{
		return adminhelper.getRewardById(rewardId, request, response);
		
	}

	@RequestMapping(value = "/addscrollingcontent", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody ScrollingContentMessage addScrollingcontent(
			@RequestBody ScrollingContentInput scrollingInputObj, final HttpServletRequest request,
			HttpServletResponse response)
	{
		return adminhelper.addScrollingcontent(scrollingInputObj, request, response);
		
	}
	
	@RequestMapping(value = "/editscrollingcontent", method = RequestMethod.PUT, produces = "application/json")
	public @ResponseBody ScrollingContentMessage editScrollingcontent(
			@RequestBody ScrollingContentInput scrollingInputObj, final HttpServletRequest request,
			HttpServletResponse response)
	{
		return	adminhelper.editScrollingcontent(scrollingInputObj, request, response);
	}



	@RequestMapping(value = "/getscrollingcontentlist", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody ScrollingContentMessages getScrollingContentList(
			@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,
			@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,
			HttpServletRequest request, HttpServletResponse response)
	{
		return adminhelper.getScrollingContentList(pagenumber, pagerecord, request, response);
		
	}
	
	@RequestMapping(value = "/getorderlist", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody OrderMessages GetOrderList(
			@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,
			@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,
			final HttpServletRequest request, final HttpServletResponse response) throws Exception 
	{
		return adminhelper.GetOrderList(pagenumber, pagerecord, request, response);
		
	}
	
	@RequestMapping(value = "/uploadimage", method = RequestMethod.POST)
	public ImageResponse postImage(@FormParam("file") MultipartFile file, int type, HttpServletRequest request) throws IOException
	{
		return adminhelper.postImage(file, type, request);
		
	}

	
	@RequestMapping(value = "/updaterewards", method = RequestMethod.PUT, produces = "application/json")
	public @ResponseBody RewardMessage UpdateRewards(@RequestBody RewardsInput RewardsInputObj,
			final HttpServletRequest request, HttpServletResponse response) 
	{
		return adminhelper.UpdateRewards(RewardsInputObj, request, response);
		
	
	}
	
	
	@RequestMapping(value="/updaterewardstatus",method=RequestMethod.PUT,produces="application/json")
	public @ResponseBody ResponseStatus updateRewardsStatus(@RequestBody RewardsInput rewardObj, final HttpServletRequest request,final HttpServletResponse response)

	{
		return adminhelper.updateRewardsStatus(rewardObj, request, response);
	}
	
	@RequestMapping(value = "/editkiosk", method = RequestMethod.PUT, produces = "application/json")
	public @ResponseBody SelectedKioskMessage editKiosk(@RequestBody KioskInput kioskinuputObj,
			final HttpServletResponse response) throws Exception 
	{
		return adminhelper.editKiosk(kioskinuputObj, response);
		
	}
	
	
	
	@RequestMapping(value = "/getAllRewards", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody RewardMessages getAllRewards(
			@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,
			@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,
			HttpServletRequest request, HttpServletResponse response) 
	{
		return adminhelper.getAllRewards(pagenumber, pagerecord, request, response);
	
	}
	
	
	@RequestMapping(value = "/getAllKiosks", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody KioskMessages getAllKiosks(@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,HttpServletRequest request, HttpServletResponse response)
	{
		return adminhelper.getAllKiosks(pagenumber, pagerecord, request, response);
		
	}
	
	@RequestMapping(value = "/editproducts", method = RequestMethod.PUT, produces = "application/json")
	public @ResponseBody AddProductResponse addProducts(@RequestBody ProductInput productInputObj,final HttpServletRequest request, HttpServletResponse response) 
	{
		return adminhelper.addProducts(productInputObj, request, response);
	}
	
	@RequestMapping(value="/updatekioskstatus",method=RequestMethod.PUT,produces="application/json")
	public @ResponseBody ResponseStatus updateKioskStatus(@RequestBody KioskInput kioskObj, final HttpServletRequest request,final HttpServletResponse response)
	{
		return adminhelper.updateKioskStatus(kioskObj, request, response);
		
	}



	
}

	
	
	
	
	
	
////	@RequestMapping(value = "/addKiosk", method = RequestMethod.POST, produces = "application/json")
////	public @ResponseBody SelectedKioskMessage addKiosk(@RequestBody KioskInput kioskinuputObj,
////			final HttpServletResponse response) throws Exception {
////		ResponseStatus status = null;
////		Kiosk kiosk = null;
////		response.setHeader("Cache-Control", "no-cache");
////		String str = null;
////
////		try {
////			String validation = KioskValidation.checkKioskFieldsEmpty(kioskinuputObj.getKioskId(),
////					kioskinuputObj.getKioskName(), kioskinuputObj.getLatitude(), kioskinuputObj.getLongitude(),
////					kioskinuputObj.getAddress());
////
////			if (validation.equalsIgnoreCase("okay")) {
////				kiosk = kioskService.getKioskId(kioskinuputObj.getKioskId());
////				if (kiosk != null) {
////					status = new ResponseStatus(ResponseStatusCode.STATUS_AlREADY_EXISTS, "Kiosk already exist");
////					return new SelectedKioskMessage(status, null);
////				} else {
////					kiosk = new Kiosk();
////					kiosk.setKioskId(kioskinuputObj.getKioskId());
////					kiosk.setKioskName(kioskinuputObj.getKioskName());
////					kiosk.setLatitude(kioskinuputObj.getLatitude());
////					kiosk.setLongitude(kioskinuputObj.getLongitude());
////					kiosk.setAddress(kioskinuputObj.getAddress());
////					kiosk.setCreated_on(new Date());
////					kioskService.registerKioskDetails(kiosk);
//////						if(kioskId>0){
//////							kiosk=kioskService.getKioskById(kioskId);
//////						}	Long kioskId
//////						
////					status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");
////				}
////			} else {
////				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND, validation);
////			}
////		} catch (Exception e) {
////			e.printStackTrace();
////			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
////		}
////		return new SelectedKioskMessage(status, kiosk);
////	}
//
//
//
	

	