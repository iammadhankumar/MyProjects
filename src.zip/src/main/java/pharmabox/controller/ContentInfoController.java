package pharmabox.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import pharmabox.domain.ContentManagement;
import pharmabox.helper.ContentInfoHelper;
import pharmabox.response.ContentInfoMessage;
import pharmabox.response.ResponseListMessage;
import pharmabox.response.ResponseMessages;
@EnableAutoConfiguration
@SpringBootApplication
@RestController
public class ContentInfoController {
	
		
		@Autowired
		private ContentInfoHelper contentInfoHelper;

		@RequestMapping(value="/privacypolicy",method=RequestMethod.GET,produces="application/json")
		public @ResponseBody ContentInfoMessage getprivacyInfo(@RequestParam(value="label")String label,final HttpServletResponse response)
		{
			return contentInfoHelper.getprivacyInfo(label, response);
			
		}

		@RequestMapping(value="/savecms", method=RequestMethod.POST,produces="application/json")
		public ResponseMessages<ContentManagement> saveAndUpdateContentManagement(@RequestBody ContentManagement contentManagement)
		{
			return contentInfoHelper.saveAndUpdateContentManagement(contentManagement);
			
		}
		
		@RequestMapping(value="/allcms", method=RequestMethod.GET,produces="application/json")
		public ResponseListMessage<ContentManagement> getAllContentManagement(HttpServletResponse response)
		{
			return contentInfoHelper.getAllContentManagement(response);
			
		}

		@RequestMapping(value="/termsandconditions", method=RequestMethod.GET,produces="application/json")
		public ResponseMessages<ContentManagement> getContentManagementByType(@RequestParam(value="label")String label,HttpServletResponse response)
		{
			return contentInfoHelper.getContentManagementByType(label, response);
		}
		
		@RequestMapping(value="/faq", method=RequestMethod.GET,produces="application/json")
		public ResponseMessages<ContentManagement> getFaq(@RequestParam(value="label")String label,HttpServletResponse response)
		{
			return contentInfoHelper.getFaq(label, response);
		}
	
	
	
	
}
