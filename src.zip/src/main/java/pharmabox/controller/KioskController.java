package pharmabox.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import pharmabox.customdomain.KioskInput;
import pharmabox.helper.KioskHelper;
import pharmabox.response.KioskMessage;
import pharmabox.response.KioskMessages;
import pharmabox.response.KioskViewMessage;
import pharmabox.response.ResponseStatus;


@Controller
@SpringBootApplication
@RestController
public class KioskController extends AbstractRestHandler {
	
	@Autowired
	KioskHelper kioskHelper;
	
	@RequestMapping(value="/getkiosklocationdetails",method=RequestMethod.GET,produces="application/json")
	public @ResponseBody KioskMessage getKioskLocationDetails(@FormParam("kiosk_id") long kiosk_id, final HttpServletResponse response)
	{
		return kioskHelper.getKioskLocationDetails(kiosk_id, response);
			
	}
	
	@RequestMapping(value="/getKioskMap",method=RequestMethod.GET,produces="application/json")
	public @ResponseBody KioskMessage getAllKioskMap(@FormParam("latitude") String latitude,@FormParam("longitude") String longitude,final HttpServletResponse response)
	{
		return kioskHelper.getAllKioskMap(latitude, longitude, response);
	
	}
    

	@RequestMapping(value="/getAllKioskList",method=RequestMethod.GET,produces="application/json")
	public @ResponseBody KioskMessages getAllKioskList(@RequestParam(value="all" , required = false, defaultValue = "0") int all, @RequestParam(value="pagenumber" , required = false, defaultValue = "0") int pagenumber, @RequestParam(value="pagerecord" , required = false, defaultValue = "0") int pagerecord,@RequestParam(value="sortColumn" , required = false, defaultValue = "0") int sortColumn, @RequestParam(value="sortType" , required = false, defaultValue = "0") int sortType, final HttpServletResponse response)
	{
		return kioskHelper.getAllKioskList(all, pagenumber, pagerecord,sortColumn,sortType, response);
	}


	@RequestMapping(value="/getAllKioskListByProduct",method=RequestMethod.GET,produces="application/json")
	public @ResponseBody KioskViewMessage getAllKioskListByProduct(@RequestParam("pid") long pid,@RequestParam(value="pagenumber" , required = false, defaultValue = "0") int pagenumber, @RequestParam(value="pagerecord" , required = false, defaultValue = "0") int pagerecord,final HttpServletResponse response)
	{
		return kioskHelper.getAllKioskListByProduct(pid, pagenumber, pagerecord, response);
		
	}

	@RequestMapping(value="/kioskstatusupdate",method=RequestMethod.PUT,produces="application/json")
	public @ResponseBody ResponseStatus KioskUpdateStatus(@RequestBody KioskInput kioskInput,final HttpServletRequest request,final HttpServletResponse response)
	{
		return kioskHelper.KioskUpdateStatus(kioskInput, request, response);
	}


	
	
}
	
