package pharmabox.controller;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import pharmabox.customdomain.signupCustomDomain;
import pharmabox.helper.UserHelper;
import pharmabox.response.ResponseStatus;
import pharmabox.response.UpdateUserMessage;
import pharmabox.response.UserMessage;


@EnableAutoConfiguration
@SpringBootApplication
@RestController
public class UserController extends AbstractRestHandler{

	
	@Autowired
	UserHelper userHelper;

	@RequestMapping(value="/register",method=RequestMethod.POST, produces="application/json")
	public @ResponseBody UserMessage createUser(@RequestBody signupCustomDomain signupObj,@FormParam("username") String username,@FormParam("password") String password,@FormParam("deviceToken") String deviceToken,HttpServletRequest request, final HttpServletResponse response) throws Exception
	{
	  return userHelper.createUser(signupObj, username, password, deviceToken, request, response);
	}

	@RequestMapping(value="/userDetails",method=RequestMethod.POST, produces="application/json")
	public @ResponseBody UserMessage viewProfile(@FormParam("email") String email,final HttpServletResponse response)
	{
		return userHelper.viewProfile(email, response);
		
	}

	@RequestMapping(value="/login", method=RequestMethod.POST,produces="application/json")
	public @ResponseBody UserMessage loginUser(@FormParam("email") String email,@FormParam("password") String password,@FormParam("devicetoken") String deviceToken,@FormParam("devicetype") String deviceType,@RequestParam(value="traffic", required = false, defaultValue = "0") int traffic,final HttpServletResponse response)
	{
	
			return userHelper.loginUser(email, password, deviceToken, deviceType,traffic, response);
	}


	@RequestMapping(value="/forgotpassword",method=RequestMethod.POST,produces="application/json")
	public @ResponseBody UserMessage forgetPassword(@FormParam("email") String email,final HttpServletResponse response,final HttpServletRequest request)
	{
		return userHelper.forgetPassword(email, response, request);
	}
	
	@RequestMapping(value="/resetpassword",method=RequestMethod.POST,produces="application/json")
	public @ResponseBody UserMessage resetpassword(@FormParam("new_password") String new_password,@FormParam("confirm_password") String confirm_password,@FormParam("verification_Code") String verification_Code,final HttpServletResponse response)
	{
		return 	userHelper.resetpassword(new_password, confirm_password, verification_Code, response);
	}

	@RequestMapping(value="/changepassword",method=RequestMethod.POST,produces="application/json")
	public @ResponseBody UserMessage changePassword(@RequestParam("currentpassword") String currentpassword, @RequestParam("newpassword") String newpassword,@RequestParam("confirmpassword") String confirmpassword, final HttpServletRequest request, final HttpServletResponse response)
	{
		return userHelper.changePassword(currentpassword, newpassword, confirmpassword, request, response);
	}
	
	@RequestMapping(value="/getprofile",method=RequestMethod.GET, produces="application/json")
	public @ResponseBody UpdateUserMessage viewProfile(@FormParam("userId") long userId ,final HttpServletResponse response)
	{
		return userHelper.viewProfile(userId, response);
	} 

	@RequestMapping(value="/updateprofile",method=RequestMethod.POST,produces="application/json")
	public @ResponseBody UpdateUserMessage updateUser(@RequestBody signupCustomDomain obj,final HttpServletRequest request,final HttpServletResponse response)
	{
		return userHelper.updateUser(obj, request, response);
	}
	
	@RequestMapping(value="/updatelocation",method=RequestMethod.PUT,produces="application/json")
	public @ResponseBody ResponseStatus UpdateLocation(@RequestBody signupCustomDomain userObj ,HttpServletRequest request,final HttpServletResponse response)

	{
		return userHelper.UpdateLocation(userObj, request, response);
	}
	
	@RequestMapping(value="/getlocation",method=RequestMethod.GET,produces="application/json")
	public @ResponseBody UserMessage GetLocation(@RequestBody signupCustomDomain userObj ,HttpServletRequest request,final HttpServletResponse response)
	{
		return userHelper.GetLocation(userObj, request, response);
	   
	}
	
	@RequestMapping(value="/updateuseractivestatus",method=RequestMethod.PUT,produces="application/json")
	public @ResponseBody ResponseStatus updateUserStatus(@RequestBody signupCustomDomain userObj, final HttpServletRequest request,final HttpServletResponse response)
	{
		return userHelper.updateUserStatus(userObj, request, response);
	}	
	}
	
	
	
	
	
	
	


