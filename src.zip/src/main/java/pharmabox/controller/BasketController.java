package pharmabox.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import pharmabox.customdomain.AddBasketInput;
import pharmabox.customdomain.RewardsInput;
import pharmabox.helper.BasketHelper;
import pharmabox.response.BasketCountByUserMessage;
import pharmabox.response.BasketCountMessage;
import pharmabox.response.BasketMessages;
import pharmabox.response.CountMessage;
import pharmabox.response.ResponseStatus;
import pharmabox.response.RewardCalculation;

@Controller
@EnableAutoConfiguration
@SpringBootApplication
@RestController
public class BasketController extends AbstractRestHandler 
{

	
	@Autowired
	private BasketHelper basketHelper;
	
	
	
	@RequestMapping(value="/addtobasket",method=RequestMethod.POST,produces="application/json")
	public @ResponseBody BasketMessages addtobasket(@RequestBody AddBasketInput AddBasketInputObj,final HttpServletRequest request, HttpServletResponse response)
	{
		return basketHelper.addtobasket(AddBasketInputObj, request, response);
		
	}
	
	@RequestMapping(value="/addquantity",method=RequestMethod.POST,produces="application/json")
	public @ResponseBody CountMessage addquantity(@RequestBody AddBasketInput AddBasketInputObj,final HttpServletRequest request, HttpServletResponse response)
	{
		return basketHelper.addquantity(AddBasketInputObj, request, response);
		
	}
	
	@RequestMapping(value="/getcartlist", method=RequestMethod.GET,produces="application/json")
	public @ResponseBody BasketCountMessage getcartlist(@RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletResponse response,HttpServletRequest request)
	{
		return basketHelper.getcartlist(pagenumber, pagerecord, response, request);
		
	}

	
	@RequestMapping(value="/deleteFromBasket", method=RequestMethod.DELETE,produces="application/json")	
	public @ResponseBody BasketCountMessage deleteFromBasket(@FormParam("bid") Long bid,final HttpServletResponse response,final HttpServletRequest request)
	{
		return basketHelper.deleteFromBasket(bid, response, request);
	
	}
	
	@RequestMapping(value="/getbasketcountbyuserid", method=RequestMethod.GET,produces="application/json")
	public @ResponseBody BasketCountByUserMessage getbasketcountbyuserid(final HttpServletResponse response,HttpServletRequest request)
	{
		return basketHelper.getbasketcountbyuserid(response, request);
		
	}
	
	@RequestMapping(value="/applyrewards",method=RequestMethod.POST,produces="application/json")
	public @ResponseBody RewardCalculation applyrewards(@RequestBody RewardsInput rewardsInputObj,final HttpServletRequest request, HttpServletResponse response)
	{
		return basketHelper.applyrewards(rewardsInputObj, request, response);
		
	}
	
	@RequestMapping(value="/removerewards",method=RequestMethod.DELETE,produces="application/json")
	public @ResponseBody ResponseStatus removerewards(@RequestParam(value="rewardId") long rewardId,@RequestParam(value="bid") List<Long> bid,final HttpServletRequest request, HttpServletResponse response)
	{
		return basketHelper.removerewards(rewardId, bid, request, response);
		
	}

}
