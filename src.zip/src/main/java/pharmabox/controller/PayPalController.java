package pharmabox.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.braintreegateway.TransactionRequest;

import pharmabox.helper.PayPalHelper;
import pharmabox.response.ClientTokenMessages;


@Controller
@EnableAutoConfiguration
@SpringBootApplication
@RestController
public class PayPalController 
{
	
	@Autowired
	PayPalHelper paypalHelper;
	
	@RequestMapping(value="/generateclienttoken",method=RequestMethod.POST, produces="application/json")
	public @ResponseBody ClientTokenMessages getClientToken(final HttpServletResponse response,final HttpServletRequest request,final TransactionRequest requ) throws Exception
	{
		return paypalHelper.getClientToken(response,request,requ);
		
	}

}
