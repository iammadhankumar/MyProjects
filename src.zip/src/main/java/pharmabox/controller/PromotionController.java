package pharmabox.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import pharmabox.domain.Promotion;
import pharmabox.repository.PromotionRepository;
import pharmabox.response.ProductMessage;
import pharmabox.utils.CommonProperties;
import pharmabox.utils.CommonUtils;

@Controller
@SpringBootApplication
@RestController
public class PromotionController {
	
	private static final Logger logger = LogManager.getLogger(PromotionController.class);

	
	@Autowired
	PromotionRepository promotionRepo;
	
	CommonUtils commonUtils= CommonUtils.getInstance();
	
	@SuppressWarnings("unused")
	@RequestMapping(value="/getPromotion", method=RequestMethod.GET,produces="application/json")
	public @ResponseBody ProductMessage getPromotion(final HttpServletResponse response,HttpServletRequest request)
	{


		JSONObject  jsonObject=new JSONObject();
		String value=CommonProperties.getUserName()+CommonProperties.getPassword();

		String user="944191bfbc1d87ee4117b800c06fd967";
		try {   
			URL url = new URL("https://data.point24h.com/mobile_webservice/getAvailablePromo.php?user="+user);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "+ conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			String output;
			while ((output = br.readLine()) != null) {
				value= output;
			}
			conn.disconnect();
			jsonObject =getPromo(value);
		} catch (MalformedURLException e) {
			logger.error("getPromotion ",e);
		} catch (IOException e) {
			logger.error("getPromotion ",e);
		}
		return null;

	}

	private JSONObject getPromo(String value) 
	{
		Promotion promotion=null;
		try
		{
			System.out.println("JSON "+value);
			JSONArray obj=(JSONArray) new JSONParser().parse(value);
			JSONArray jo = (JSONArray) obj; 

			System.out.println("JSON ONJ LEN "+jo.size());
			for(int i=0;i<jo.size();i++)
			{
				JSONObject jsonObject = (JSONObject) obj.get(i);
				String code=(String) jsonObject.get("code");
				String name=(String) jsonObject.get("name");
				String startDate=(String) jsonObject.get("start_date");
				String endDate=(String) jsonObject.get("end_date");
				String productCode=(String) jsonObject.get("product_code");
				String productName=(String) jsonObject.get("product_name");
				String machine=(String) jsonObject.get("machine");

				promotion=promotionRepo.getByCodeAndActive(code);
				if(promotion==null)
				{
					promotion=new Promotion();
					promotion.setCode(code);
					promotion.setActive(true);
					promotion.setName(name);
					promotion.setStartDate(startDate);
					promotion.setEndDate(endDate);
					promotion.setProductName(productName);
					promotion.setProductCode(productCode);
					promotion.setMachine(machine);
					promotionRepo.save(promotion);
				}





			}
		}
		catch(Exception e)
		{
			logger.error("getPromo ",e);
		}
		return null;
	}




}
