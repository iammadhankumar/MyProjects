package pharmabox.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import pharmabox.customdomain.ProductKioskCount;
import pharmabox.domain.Basket;
import pharmabox.domain.ProductKiosk;
import pharmabox.domain.User;
import pharmabox.response.ProductKioskCountMessage;
import pharmabox.response.ResponseStatus;
import pharmabox.response.ResponseStatusCode;
import pharmabox.service.IAddProductKioskService;
import pharmabox.service.IBasketService;
import pharmabox.utils.UserByToken;

@Controller
@RestController
public class ProductKioskController {
	
	
	private static final Logger logger = LogManager.getLogger(ProductKioskController.class);

	


	@Autowired
	private IAddProductKioskService AddProductKioskService;

	@Autowired
	private IBasketService BasketService;

	@Autowired
	private UserByToken tokenUser;


	@SuppressWarnings("unused")
	@RequestMapping(value="getallproductlistviakiosk",method=RequestMethod.GET,produces="application/json")
	public @ResponseBody ProductKioskCountMessage getallproductlistviakiosk(@RequestParam("kiosk_id") long kiosk_id,@RequestParam(value="product_type_id",required=false,defaultValue="0") Long product_type_id,@RequestParam(value="searchText",required=false) String searchText,
			final HttpServletRequest request,final HttpServletResponse response) {
		ResponseStatus status=null;
		List<ProductKiosk> productkiosk=null;
		ProductKioskCount count=new ProductKioskCount();
		 Basket basket=null;
		 User user=null;
		long Basketcount=0;
		response.setHeader("Cache-Control", "no-cache");
		user = tokenUser.getUser(request);
		try {

			
			long userId = user.getUser_id();
			
			System.out.println(userId);
			basket= BasketService.getBasket(userId);

			if(userId > 0) {

				productkiosk=AddProductKioskService.getAllProductlist(kiosk_id,product_type_id,searchText);
				if(productkiosk != null && productkiosk.size() > 0) {
					count.setProductKioskList(productkiosk);
					count.setCount(productkiosk.size());
					 Basketcount= BasketService.getBasketByIdandPurchaseCount(userId,false);
						status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");	

					
				}
			

       else {
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"NO RECORD FOUND");
					return new ProductKioskCountMessage(status, null);
				}
			}



		}

		catch(Exception e){
			logger.error("getallproductlistviakiosk ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return new ProductKioskCountMessage(status, count);
	}


}
