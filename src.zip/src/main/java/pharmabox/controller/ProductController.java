package pharmabox.controller;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import pharmabox.helper.ProductHelper;
import pharmabox.response.FavouriteMessage;
import pharmabox.response.FavouriteMessages;
import pharmabox.response.ProductCountMessage;
import pharmabox.response.ProductMessage;
import pharmabox.response.ProductMessages;
import pharmabox.response.ProductTypeMessage;
import pharmabox.response.RecentViewMessage;
import pharmabox.response.SearchProductCount;

@Controller
@SpringBootApplication
@RestController
public class ProductController extends AbstractRestHandler  {

	@Autowired
	private ProductHelper productHelper;


	
	@RequestMapping(value="/filterByProductType", method=RequestMethod.GET,produces="application/json")
	public @ResponseBody ProductMessage filterByProductType(@RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,@RequestParam("productTypeId") long productTypeId,final HttpServletResponse response,HttpServletRequest request)
	{
		return productHelper.filterByProductType(pagenumber, pagerecord, productTypeId, response, request);
		
	}
   
	@RequestMapping(value="/getAllProductList", method=RequestMethod.GET,produces="application/json")
	public @ResponseBody ProductCountMessage getAllProductList( @RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletResponse response,HttpServletRequest request)
	{
		return productHelper.getAllProductList(pagenumber, pagerecord, response, request);
		
	}


	@RequestMapping(value="/addtofavourite", method=RequestMethod.POST,produces="application/json")
	public @ResponseBody FavouriteMessages getFavouriteProductId(@RequestParam("id") long id,@RequestParam("userId") long userId,final HttpServletResponse response,HttpServletRequest request)
	{
		return productHelper.getFavouriteProductId(id, userId, response, request);
		
	}


	@RequestMapping(value="/getfavlists", method=RequestMethod.GET,produces="application/json")
	public @ResponseBody FavouriteMessage getFavouriteListsByUserId(@RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletResponse response,HttpServletRequest request)
	{
		return productHelper.getFavouriteListsByUserId(pagenumber, pagerecord, response, request);
		
	}


	@RequestMapping(value="/getproductbyproductid", method=RequestMethod.GET,produces="application/json")
	public @ResponseBody ProductMessages getproductbyproductid(@RequestParam("id") long id,final HttpServletResponse response,HttpServletRequest request)
	{
		return productHelper.getproductbyproductid(id, response, request);
		
	}

	
	@RequestMapping(value="/getAllProductTypeList", method=RequestMethod.GET,produces="application/json")
	public @ResponseBody ProductTypeMessage getAllProductTypeList( @RequestParam("pagenumber") int pagenumber,@RequestParam("pagerecord") int pagerecord, final HttpServletResponse response,HttpServletRequest request)
	{
		return productHelper.getAllProductTypeList(pagenumber, pagerecord, response, request);
		
	}

	


	@RequestMapping(value="/searchproduct", method=RequestMethod.POST,produces="application/json")
	public @ResponseBody SearchProductCount searchProduct(@FormParam("search_value") String search_value,@FormParam("pagenumber") int pagenumber,@FormParam("pagerecord") int pagerecord,final HttpServletRequest request,final HttpServletResponse response)
	{
		return productHelper.searchProduct(search_value, pagenumber, pagerecord, request, response);
		
	}

	
	@RequestMapping(value="/recentviewedproduct", method=RequestMethod.GET,produces="application/json")
	public @ResponseBody RecentViewMessage recentViewedProduct(@RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletRequest request,final HttpServletResponse response)
	{
		return productHelper.recentViewedProduct(pagenumber, pagerecord, request, response);
		
	}
	
	
}



























