package pharmabox.dao;

import pharmabox.domain.OrderBasket;

public interface IOrderBasketDAO {

	long registerNewOrder(OrderBasket orderBasketObj);

}
