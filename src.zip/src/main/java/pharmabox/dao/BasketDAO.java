package pharmabox.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pharmabox.domain.Basket;
import pharmabox.domain.BasketStatus;
import pharmabox.domain.Kiosk;
import pharmabox.domain.Rewards;


@Repository("IBasketDAO")
@Transactional
public class BasketDAO  implements IBasketDAO{
	
	private static final Logger logger = LogManager.getLogger(BasketDAO.class);

	@Autowired
	private SessionFactory sessionFactory;
	



	private Session getSession(){
		return sessionFactory.getCurrentSession();
	}

	@Override
	public long registerNewToBasket(Basket basket) {
		Long id = -1L;
		try {
			id=(Long) getSession().save(basket);
		} catch(Exception e) {		
			logger.error("registerNewToBasket ",e);
		}
		return id;
	}
	
	
	
	@Override
	public void delete(long bid) {
		try {			
			sessionFactory.getCurrentSession().createQuery("Update Basket SET active=0 where bid= ?").setParameter(0,bid).executeUpdate();
		} catch(Exception e) {
			logger.error("delete ",e);
		}
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Basket> getBasket() {
		List<Basket> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from Basket where active=1").list();
		} catch(Exception e) {
			logger.error("getBasket ",e);
		}
		return (list!=null && list.size()>0)?list:null;
		
				}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Basket> getBasketbyList(List<Long> bid) {
		List<Basket> list = null;
		try {

			Criteria c=getSession().createCriteria(Basket.class);
			c.add(Restrictions.eq("active",true)).
			add(Restrictions.in("bid", bid));
			list = c.list();
		} catch(Exception e) {
			logger.error("getBasketbyList ",e);
		}
		return (list!=null && list.size()>0)?list:null;
		
				}
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Basket> getBasketbyListCheck(List<Long> bid,long userId)
	{
		List<Basket> list = null;
		try {

			Criteria c=getSession().createCriteria(Basket.class);
			c.add(Restrictions.eq("active",true)).
		   add(Restrictions.eq("user.id", userId)).   
			add(Restrictions.in("bid", bid));
			list = c.list();
		} catch(Exception e) {
			logger.error("getBasketbyListCheck ",e);
		}
		return (list!=null && list.size()>0)?list:null;
		
	}
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Basket> getBasketbyRewardPurchase(List<Long> bid) {
		List<Basket> list = null;
		try {

			Criteria c=getSession().createCriteria(Basket.class);
			c.add(Restrictions.eq("active",true)).
		    add(Restrictions.eq("rewardsUsed",true)).
			add(Restrictions.in("bid", bid));
			list = c.list();
		} catch(Exception e) {
			logger.error("getBasketbyRewardPurchase ",e);
		}
		return (list!=null && list.size()>0)?list:null;
		
				}
	

	@SuppressWarnings("unchecked")
	@Override
	public List<Basket> getBasketByIdandPurchase(Long userId,boolean purchase){
		List<Basket> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from Basket where active=1 and purchase = :purchase")
					.setParameter("purchase", purchase).list();
		} catch(Exception e) {
			logger.error("getBasketByIdandPurchase ",e);
		}
		return list;
		
	}

		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getBid(Long bid) {
			List<Basket> list = null;
			try {
				list=sessionFactory.getCurrentSession().createQuery("from Basket where bid=:bid and active=1").setParameter("bid", bid).list();
			
			} catch(Exception e) {
				logger.error("getBid ",e);
			}
			return (list!=null && list.size()>0)?list.get(0):null;
	}

		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getBasketByBid(long bid) {
			List<Basket> list = null;
			try {
				list=sessionFactory.getCurrentSession().createQuery("from Basket where bid=:bid").setParameter("bid", bid).list();
			
			} catch(Exception e) {
				logger.error("getBasketByBid ",e);
			}
			return (list!=null && list.size()>0)?list.get(0):null;
	}
		
		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getBasketId(long bid) {
			List<Basket> list = null;
			try {
				list=sessionFactory.getCurrentSession().createQuery("from Basket where bid=:bid and active=1 ").setParameter("bid", bid).list();
			
			} catch(Exception e) {
				logger.error("getBasketByRewards ",e);
			}
			return (list!=null && list.size()>0)?list.get(0):null;
	}
		
		@SuppressWarnings("unchecked")
		public List<Basket> getBasketByRewards(List<Long> bid)
		{
		List<Basket> list = null;
		try {			
			Criteria c=getSession().createCriteria(Basket.class);
			c.add(Restrictions.eq("active",true)).
			//add(Restrictions.eq("rewardsUsed",false)).
			add(Restrictions.in("bid", bid));
			list = c.list();
		
		} catch(Exception e) {
			logger.error("getBasketByRewards ",e);
		}
		return (list!=null && list.size()>0)?list:null;
}
		
		
		@SuppressWarnings("unchecked")
		public Basket getBasketByRewardsCheck(long bid)
		{
		List<Basket> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from Basket where bid IN(select bid from Basket) and active=1 and rewardsUsed=0;").setParameter("bid", bid).list();
		
		} catch(Exception e) {
			logger.error("getBasketByRewardsCheck ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
}

		@SuppressWarnings("unchecked")
		@Override
		public Basket getProductkioskAndUser(long productkiosk_id, long user_id) {
			List<Basket> list = null;
			try { 
				
				
				list=sessionFactory.getCurrentSession().createQuery("from Basket where ProductKiosk.productkiosk_id=? and user.user_id=? and active=1")
						.setParameter(0, productkiosk_id)
						.setParameter(1, user_id).list();
			} catch(Exception e) {
				logger.error("getProductkioskAndUser ",e);
			}
			return (list!=null && list.size()>0)?list.get(0):null;
		}

		@Override
		public void updateBasket(Basket basket) {
			try {
				getSession().update(basket);
			} catch(Exception e) {
				logger.error("updateBasket ",e);
			}
		}

		@Override
		public long getBasketByIdandPurchaseCount(long userId, boolean purchase) {
			long basketcount = 0;
			try {
				basketcount = sessionFactory.getCurrentSession().createQuery("from Basket where active=1 and user.user_id = :userId and purchase = :purchase").setParameter("userId", userId)
				.setParameter("purchase", purchase).list().size();
			} catch(Exception e) {
				logger.error("getBasketByIdandPurchaseCount ",e);
			}
			return basketcount;
			
		}

		@Override
		public void updateBasketQuantity(long qt,long pid)
		{
			try
			{
		     sessionFactory.getCurrentSession().createQuery("Update Basket SET quantity=:qt where ProductKiosk.id=:pid").setParameter("qt",qt).setParameter("pid",pid).executeUpdate();
			}
			
			catch(Exception e) {
				logger.error("updateBasketQuantity ",e);
			}
		}
		
		@SuppressWarnings("unchecked")
		@Override
		public List<Basket> getpaypalid(long paypalId) {
			List<Basket> list = null;
			try {
				list=sessionFactory.getCurrentSession().createQuery("from Basket where basketStatus=2 and payPalTransaction.PaypalId=?").setParameter(0, paypalId).list();
			
			} catch(Exception e) {
				logger.error(" ",e);
			}
			System.out.println("outbbb::"+list);
			return (list!=null && list.size()>0)?list:null;
			
	}

		@SuppressWarnings("unchecked")
		@Override
		public BasketStatus setBasketStatus(long id) {
			List<BasketStatus> list = null;
			try {
				list=sessionFactory.getCurrentSession().createQuery("from BasketStatus where basketStatusId=:id").setParameter("id", id).list();
			
			} catch(Exception e) {
				logger.error("setBasketStatus ",e);
			}
			return (list!=null && list.size()>0)?list.get(0):null;
			
	}
		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getBasketByProductKioskAndUser(long id, long userId) {
			List<Basket> list=null;
			try
			{
				list=getSession().createQuery("from Basket where productKiosk.id=:id and  user.user_id=:userId and active=1 and purchase=0").setParameter("id",id).setParameter("userId", userId).list();
			}
			catch(Exception e) {
				logger.error("getBasketByProductKioskAndUser ",e);
			}
			return (list!=null && list.size()>0)?list.get(0):null;
		}
		
		

		@SuppressWarnings("unchecked")
		@Override
		public Kiosk getKioskbyProduct(long pid)
		{
		List<Kiosk> list=null;

			try
			{
				list=sessionFactory.getCurrentSession().createQuery("Select kiosk.id from Product where id=:pid").setParameter("pid",pid).list();

			}
			
		
			catch(Exception e) {
				logger.error("getKioskbyProduct ",e);
			}
			 	return (list!=null && list.size()>0)?list.get(0):null;
		}


		@SuppressWarnings("unchecked")
		@Override
		public List<Basket> getBasketByIdandPurchaseandstatus(long userId, long basketStatusId, boolean purchase) {
			
				List<Basket> list = null;
				try {   
					list=sessionFactory.getCurrentSession().createQuery("from Basket where active=1 and purchase=:purchase  and user.user_id=:userId and basketStatus.basketStatusId=:basketStatusId").setParameter("purchase", purchase).setParameter("userId", userId).setParameter("basketStatusId", basketStatusId).list();
				} catch(Exception e) {
					logger.error("getBasketByIdandPurchaseandstatus ",e);
				}
				return  list!=null && !list.isEmpty()?list:null;
				
			}

	
		
		
		@SuppressWarnings("unchecked")
		@Override
		public List<Basket> getAllBasketByStatus(long basketstatusId) {
			List<Basket> list = null;
			try {
				Query sub3Week = sessionFactory.getCurrentSession().createSQLQuery("select DATE_SUB( NOW() , INTERVAL 1 HOUR ) ");
				List<Date> sub3WeekList = sub3Week.list();
				System.out.println(sub3WeekList.get(0).toString());
				DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				list=sessionFactory.getCurrentSession().createQuery("from Basket where active=1 and basketStatus.basketStatusId = :basketstatusId and payPalTransaction.created_on <= :createdDate").setParameter("basketstatusId", basketstatusId).setParameter("createdDate", sdf.parse(sub3WeekList.get(0).toString())).list();
			
			} catch(Exception e) {
				logger.error("getAllBasketByStatus ",e);
			}
			return (list!=null && !list.isEmpty()?list:null);
}

		
		

		@SuppressWarnings("unchecked")
		@Override
		public Basket getBasket(long userId) {
			List<Basket> list = null;
			try {
				System.out.println("in dao");
				list= sessionFactory.getCurrentSession().createQuery(" from Basket where active=1 and basketStatus.basketStatusId =1 and purchase=0 and user.user_id = :userId ").setParameter("userId", userId).list();
			
			System.out.println(list);
			}catch(Exception e) {
				logger.error(" ",e);
			}
			return (list!=null && list.size()>0)?list.get(0):null;
					
		}
		
		
		

		@SuppressWarnings("unchecked")
		@Override
		public Basket getBasketByUser(long userId,long bid) {
			List<Basket> list = null;
			try {
				System.out.println("in dao");
				list= sessionFactory.getCurrentSession().createQuery(" from Basket where active=1 and basketStatus.basketStatusId =1 and bid=:bid and user.user_id = :userId ").setParameter("bid", bid).setParameter("userId", userId).list();
			
			System.out.println(list);
			}catch(Exception e) {
				logger.error(" ",e);
			}
			return (list!=null && list.size()>0)?list.get(0):null;
					
		}
	
		@SuppressWarnings("unchecked")
		@Override
		public List<Basket> getBasketInfo(long userId) {
			List<Basket> list = null;
			try {
				System.out.println("in dao");
				list= sessionFactory.getCurrentSession().createQuery(" from Basket where active=1 and basketStatus.basketStatusId =1 and user.user_id = :userId ").setParameter("userId", userId).list();
			
			}catch(Exception e) {
				logger.error("getBasketInfo ",e);
			}
			return (list!=null && list.size()>0)?list:null;
					
		}		
		
        @SuppressWarnings("unchecked")
		@Override
       public List<Basket> getBasketlist(long user_id,int pagenumber, int pagerecord) {
			List<Basket> list = null;
			Query q=null;
			try {
				q= sessionFactory.getCurrentSession().createQuery(" from Basket where active=1 and basketStatus.basketStatusId =1  ");
				 if(pagenumber > 0 && pagerecord > 0)
	    		 {
	    		q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
	    		 }
	    	
	    		list=q.list() ;
						
			} catch(Exception e) {
				logger.error("getBasketlist ",e);
			}
			return list!=null && !list.isEmpty()?list:null;
			
	}

        
     
		@SuppressWarnings("unchecked")
		@Override
		public List<Basket> getBasketlistByUserid(long user_id) {			
			List<Basket> list = null;
			try {
				list= sessionFactory.getCurrentSession().createQuery(" from Basket where active=1 and purchase=0 and user.user_id = :user_id ").setParameter("user_id", user_id).list();
			
			} catch(Exception e) {
				logger.error("getBasketlistByUserid ",e);
			}
			return (list!=null && list.size()>0)?list:null;
			
	}

		
		@SuppressWarnings("unchecked")
		@Override
		public List<Basket> getBasketByrewardsCheck(long user_id) {			
			List<Basket> list = null;
			try {
				list= sessionFactory.getCurrentSession().createQuery(" from Basket where active=1 and rewardsUsed=1 and user.user_id = :user_id ").setParameter("user_id", user_id).list();
			
			} catch(Exception e) {
				logger.error("getBasketByrewardsCheck ",e);
			}
			return (list!=null && list.size()>0)?list:null;
			
	}

		
		
		
		
		@SuppressWarnings("unchecked")
		@Override
		public List<Basket> getBasketBypaypalid(long paypalId) {
			List<Basket> list = null;
			try {
				list=sessionFactory.getCurrentSession().createQuery("from Basket where payPalTransaction.PaypalId=?").setParameter(0, paypalId).list();
			
			} catch(Exception e) {
				logger.error("getBasketBypaypalid ",e);
			}
			return list!=null && !list.isEmpty()?list:null;
			
	}

		@Override
		public long getBasketCount(long user_id) {
			long basketcount = 0;
			try {
				basketcount = sessionFactory.getCurrentSession().createQuery("from Basket where active=1 and user.user_id = :userId").setParameter("userId", user_id)
				.list().size();
			} catch(Exception e) {
				logger.error("getBasketCount ",e);
			}
			return basketcount;
			
		}

		@SuppressWarnings("unchecked")
		@Override
		public List<Basket> getbasketforkioskcheck(long user_id) {			
			List<Basket> list = null;
			try {
				list= sessionFactory.getCurrentSession().createQuery("from Basket where active=1 and purchase=0 and user.user_id = :user_id ").setParameter("user_id", user_id).list();
			
			} catch(Exception e) {
				logger.error("getbasketforkioskcheck ",e);
			}
			
			return (list!=null && list.size()>0)?list:null;
			
		}
		
		@Override
		public boolean getBasketByProductKioskandUser(long id, long userId) {
			long count=0;
			try
			{
				count=getSession().createQuery("from Basket where productKiosk.id IN (select productKiosk.id from Basket where productKiosk.id=:id and user.user_id=:userId) and active=1").setParameter("id",id).setParameter("userId", userId).list().size();
			}
			catch(Exception e) {
				logger.error("getBasketByProductKioskandUser ",e);
			}
			return count>0?true:false;
		}

		
		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getQuantityOfBasketProduct(long user_id) {			
			List<Basket> list = null;
			try {
				list= sessionFactory.getCurrentSession().createQuery("select quantity from Basket where user.user_id = :user_id ").setParameter("user_id", user_id).list();
			
			} catch(Exception e) {
				logger.error("getQuantityOfBasketProduct ",e);
			}
			return (list!=null && list.size()>0)?list.get(0):null;
			
		}
		
		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getKioskByBasketProductKioskId(long productKioskId)
		{
			List<Basket> list = null;
			try
			{
				list= sessionFactory.getCurrentSession().createQuery(" from Basket where productKiosk.id = :productKioskId ").setParameter("productKioskId", productKioskId).list();
			}
			catch(Exception e) {
				logger.error("getKioskByBasketProductKioskId ",e);
			}
			
			return (list!=null && list.size()>0)?list.get(0):null;
			
		}
		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getProductKioskUser(long productKioskId)
		{
			List<Basket> list=null;
			try
			{
				list= sessionFactory.getCurrentSession().createQuery(" from Basket where productKiosk.id = :productKioskId ").setParameter("productKioskId", productKioskId).list();
			      
			}
			
			catch(Exception e) {
				logger.error("getProductKioskUser ",e);
			}
			return (list!=null && list.size()>0)?list.get(0):null;
		}
		
		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getProductKioskByUser(long userId)
		{
			List<Basket> list=null;
			try
			{
				list= sessionFactory.getCurrentSession().createQuery(" from Basket where user.user_id = :userId ").setParameter("userId", userId).list();
			}
			
			catch(Exception e) {
				logger.error("getProductKioskByUser ",e);
			}
			return (list!=null && list.size()>0)?list.get(0):null;
		}

		@SuppressWarnings("unchecked")
		@Override
		public List<Basket> getBasketlistByUseridwithpagination(long userId, int pagenumber, int pagerecord) {			
			List<Basket> list = null;
			Query q=null;
			try {
				q= sessionFactory.getCurrentSession().createQuery(" from Basket where active=1 and user.user_id = :userId ");
				 q.setParameter("userId", userId);
				
				if(pagenumber > 0 && pagerecord > 0)
	    		 {
	    		q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
	    		 }
	    	
	    		list=q.list() ;
						
			} catch(Exception e) {
				logger.error("getBasketlistByUseridwithpagination ",e);
			}
			return list;
			
		}

		@SuppressWarnings("unchecked")
		@Override
		public Basket getbyproductkioskid(long id) {
			List<Basket> list = null;
			try {
				list=sessionFactory.getCurrentSession().createQuery("from Basket where ProductKiosk.id=:id").setParameter("id", id).list();
			
			} catch(Exception e) {
				logger.error("getbyproductkioskid ",e);
			}
			return (list!=null && list.size()>0)?list.get(0):null;
			
	}

		@SuppressWarnings("unchecked")
		@Override
		public Basket getbasketbyproductkioskidanduserid(long id, long userId) {
			List<Basket> list = null;
			try {
				list=sessionFactory.getCurrentSession().createQuery("from Basket where productKiosk.id=:id and user.user_id = :userId and active=1").setParameter("id", id)
						.setParameter("userId", userId)
						.list();
			
			} catch(Exception e) {
				
				logger.error("getbasketbyproductkioskidanduserid ",e);
			}
			return (list!=null && list.size()>0)?list.get(0):null;
			
		
}
	
		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getbasketbyCartDetails(long pid,long userId) {
			List<Basket> list = null;
			try {
				list=sessionFactory.getCurrentSession().createQuery("from Basket where ProductKiosk.product.id=:pid and user.user_id = :userId and active=1")
						.setParameter("pid", pid)
						.setParameter("userId", userId)
						.list();
			} catch(Exception e) {
				
				logger.error("getbasketbyCartDetails ",e);
			}
			return (list!=null && list.size()>0)?list.get(0):null;
			

}
		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getbasketDetailsbypid(long pid,long userId) {
			List<Basket> list = null;
			try {
				list=sessionFactory.getCurrentSession().createQuery("from Basket where productKiosk.id=:pid and user.user_id = :userId and active=1")
						.setParameter("pid", pid)
						.setParameter("userId", userId)
						.list();
			} catch(Exception e) {
				
				logger.error("getbasketDetailsbypid ",e);
			}
			return (list!=null && list.size()>0)?list.get(0):null;
			

}
		
		

		@Override
		public void UpdateBasketActive(long bid) {
			try {			
				sessionFactory.getCurrentSession().createQuery("Update Basket SET active=0,purchase=1 where id=:bid").setParameter("bid",bid).executeUpdate();
			} catch(Exception e) {
				logger.error("UpdateBasketActive ",e);
			}
		}

		@Override
		public void updateRewardsInfo(float totalamount, float discountedPrice, float rewardsPrice, Rewards reward,boolean b,long userId) {
			try {			
				sessionFactory.getCurrentSession().createQuery("Update Basket SET rewardsUsed=:b,actualPrice=:totalamount,discountedPrice=:discountedPrice,reward=:reward,rewardsPrice=:rewardsPrice where purchase=0 and active=1  ")
				.setParameter("totalamount", totalamount)
				.setParameter("discountedPrice", discountedPrice)
				.setParameter("rewardsPrice", rewardsPrice)
				.setParameter("b",b)
				.setParameter("reward", reward)
				.executeUpdate();
			} catch(Exception e) {
				logger.error("updateRewardsInfo ",e);
			}
			
		}

		
		
		
		}



