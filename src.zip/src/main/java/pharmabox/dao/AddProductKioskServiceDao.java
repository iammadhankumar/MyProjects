package pharmabox.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pharmabox.domain.ProductKiosk;

@Repository("IAddProductKioskServiceDao")
@Transactional
public class AddProductKioskServiceDao implements IAddProductKioskServiceDao {
	
	private static final Logger logger = LogManager.getLogger(AddProductKioskServiceDao.class);

	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * return hibernate session
	 * @return
	 */
	private Session getSession(){
		return sessionFactory.getCurrentSession();
	}

	
	@SuppressWarnings("unchecked")
	public ProductKiosk getKioskBypId(long product_id) {
		List<ProductKiosk> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from ProductKiosk where product.id=:product_id").setParameter("product_id", product_id).list();
			System.out.println("KIOSK"+list);
		} catch(Exception e) {
			logger.error("getKioskBypId ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
	}
	
	@SuppressWarnings("unchecked")
	public ProductKiosk getProductKioskBypId(long id) {
		List<ProductKiosk> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from ProductKiosk where id=:pk").setParameter("pk", id).list();
			System.out.println("KIOSK"+list);
		} catch(Exception e) {
			logger.error("getProductKioskBypId ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
	}
	
	
	
	@SuppressWarnings("unchecked")
	public ProductKiosk getProductKioskByproductId(long productId,long kioskid) {
		List<ProductKiosk> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from ProductKiosk where product.id=:productId and kiosk.id=:kioskid").setParameter("productId", productId).setParameter("kioskid", kioskid).list();
			System.out.println("KIOSK"+list);
		} catch(Exception e) {
			logger.error("getProductKioskBypId ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
	}
	
	
	@SuppressWarnings("unchecked")
	public ProductKiosk getProductkiosk_id(long kioskId) {
		List<ProductKiosk> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("select id from ProductKiosk where kiosk.id=:kioskId").setParameter("kioskId", kioskId).list();
			System.out.println("PK:::::"+list);
		} catch(Exception e) {
			logger.error("getProductkiosk_id ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<ProductKiosk> getAllProductListByProductTypeandKiosk(long kioskId,List<Long> productObj,long productType,int pagenumber,int pagerecord)
	{
		List<ProductKiosk> list=null;
		Query q=null;
		try
		{   
			
			
			q=sessionFactory.getCurrentSession().createQuery("from ProductKiosk where kiosk.id=:kioskId and product IN (select productObj from Product where productType.id=:productType)").setParameter("kioskId", kioskId);
	

			 if(pagenumber > 0 && pagerecord > 0)
			 {
				 System.out.println("IN PAGINATION");
			q.setFirstResult(((pagenumber-1) * pagerecord));
		      q.setMaxResults(pagerecord);
			 }
			
			list = q.list();

		}
		catch(Exception e) {
			logger.error("getAllProductListByProductTypeandKiosk ",e);
		}
	return (list!=null && list.size()>0)?list:null;
	}
	
	@SuppressWarnings("unchecked")
	public ProductKiosk getProductkiosk(long pid) {
		List<ProductKiosk> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from ProductKiosk where product.id=:pid").setParameter("pid", pid).list();
			System.out.println("PK:::::"+list);
		} catch(Exception e) {
			logger.error("getProductkiosk ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
	}
	
	@SuppressWarnings("unchecked")
	public ProductKiosk getProductAndKiosk(long productId) {
		List<ProductKiosk> list = null;
		try { 
			list=sessionFactory.getCurrentSession().createQuery("from ProductKiosk where product.id=:productId")
					.setParameter("productId", productId).list();
			System.out.println("PK:::::"+list);
		} catch(Exception e) {
			logger.error("getProductAndKiosk ",e);
		}
		return (list!=null && list.size()>0)?(ProductKiosk)list.get(0):null;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<ProductKiosk> getProductKioskId(long productId) {
		List<ProductKiosk> list = null;
		try { 			
			list=sessionFactory.getCurrentSession().createQuery("from ProductKiosk where product.id=:productId")
					.setParameter("productId", productId).list();
			System.out.println("PK:::::"+list);
		} catch(Exception e) {
			logger.error("getProductKioskId ",e);
		}
		return (list!=null && list.size()>0)?list:null;
	}
	
	

	public long registerNewProductKiosk(ProductKiosk productkiosk) {
		Long id = -1L;
		try {
			System.out.println("pk savedd succ");
			id=(Long) getSession().save(productkiosk);
		} catch(Exception e) {		
			logger.error("registerNewProductKiosk ",e);
		}
		return id;
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<ProductKiosk> getAllProductlist(long kiosk_id ,long product_type_id,String searchText) {
		List<ProductKiosk> list = null;
		try {
			
			if(product_type_id <= 0) {
				list=sessionFactory.getCurrentSession().createQuery("from ProductKiosk where kiosk.kioskId =:kiosk_id").setParameter("kiosk_id", kiosk_id).list();
			}
			else if(product_type_id > 0) {
				System.out.println("INNN "+product_type_id);
				list=sessionFactory.getCurrentSession().createQuery("from ProductKiosk where kiosk.kioskId =:kiosk_id and product.id IN (select id from Product where productType.id = :product_type_id and productName like '%"+searchText+"%')").setParameter("kiosk_id", kiosk_id).setParameter("product_type_id", product_type_id).list();
			}
			
		} catch(Exception e) {
			logger.error("getAllProductlist ",e);


		}
		return list;
		
				}
	

	@SuppressWarnings("unchecked")
	@Override
	public ProductKiosk checkQuantity(long productkiosk_id) {
		List<ProductKiosk> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from ProductKiosk where productkiosk_id=?").setParameter(0, productkiosk_id).list();
		} catch(Exception e) {
			logger.error("checkQuantity ",e);
		}
		return (list!=null && list.size()>0)?(ProductKiosk)list.get(0):null;
	}

	@Override
	public void updateProductKiosk(ProductKiosk productKiosk) {
		// TODO Auto-generated method stub
		try {
			getSession().update(productKiosk);
		} catch(Exception e) {
			logger.error("updateProductKiosk ",e);
		}	
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public ProductKiosk getKioskByProductKioskId(long productkioskid) {
		System.out.println("ingy");
		List<ProductKiosk> list = null;
		try {
			System.out.println("kiosk id dao");
			list = getSession().createQuery("from ProductKiosk where id=:productkioskid ").setParameter("productkioskid",productkioskid).list();
			System.out.println("doubt"+list);
		} catch(Exception e) {
			logger.error("getKioskByProductKioskId ",e);
}
		return (list!=null && list.size()>0)?(ProductKiosk)list.get(0):null;
		
}
	
	

	@Override
	public List<Long> getKioskIdByProductKioskId(List<ProductKiosk> productkioskid) {
		List<Long> list = null;
		try {
			list = getSession().createQuery("select kiosk.id from ProductKiosk where id=:productkioskid ").setParameter("productkioskid",productkioskid).list();
		} catch(Exception e) {
			logger.error("getKioskIdByProductKioskId ",e);
}
		return (list!=null && list.size()>0)?list:null;
		
}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ProductKiosk> getProductKioskbyKiosk(long kioskId)
	{
		List<ProductKiosk> list=null;
		try
		{
           list=getSession().createQuery("from ProductKiosk where kiosk.id=:kioskId").setParameter("kioskId", kioskId).list();
		}

		catch(Exception e) 
		{
			logger.error("getProductKioskbyKiosk ",e);
		}
		return (list!=null && list.size()>0)?list:null;
	}	

	
	
	@SuppressWarnings("unchecked")
	@Override
	public ProductKiosk getProductKioskByProductandKioskId(long kioskId,long productId) 
	{
		List<ProductKiosk> list = null;
		try {
			list = getSession().createQuery("from ProductKiosk where kiosk.id=:kioskId and product.id=:productId ").setParameter("kioskId",kioskId).setParameter("productId",productId).list();
			System.out.println("doubt"+list);
		} catch(Exception e) {
			logger.error("getProductKioskByProductandKioskId ",e);
}
		return (list!=null && list.size()>0)?(ProductKiosk)list.get(0):null;
		
}
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public ProductKiosk getProductKioskInfo(long kioskId,long productId,long qt) 
	{
		List<ProductKiosk> list = null;
		try {
			list = getSession().createQuery("from ProductKiosk where kiosk.id=:kioskId and product.id=:productId and quantity=:qt").setParameter("kioskId",kioskId).setParameter("productId",productId).setParameter("qt",qt).list();
			System.out.println("doubt"+list);
		} catch(Exception e) {
			logger.error("getProductKioskInfo ",e);
}
		return (list!=null && list.size()>0)?(ProductKiosk)list.get(0):null;
		
}


	@SuppressWarnings("unchecked")
	@Override
	public List<Long> getKioskByproductId(long pid) {
		List<Long> list = null;
		try
		{
			list = getSession().createQuery("select kiosk.id from ProductKiosk where product.id=:pid and quantity>0 ").setParameter("pid",pid).list();

		}
		catch(Exception e) {
			logger.error("getKioskByproductId ",e);
}
		return (list!=null && list.size()>0)?list:null;
	}


	@Override
	public long getKioskCount(long pid) {
		long count = 0;
		try
		{
			count = getSession().createQuery("from ProductKiosk where product.id=:pid ").setParameter("pid",pid).list().size();
		}
		catch(Exception e) {
			logger.error("getKioskCount ",e);
}
		return count;
	}


	

	@Override
	public void updateProductKioskQuantity(long qt,long pid)
	{
		
		try
		{
	long k=sessionFactory.getCurrentSession().createQuery("Update ProductKiosk SET quantity=:qt where id=:pid").setParameter("qt",qt).setParameter("pid",pid).executeUpdate();
         System.out.println("q"+k);
		}
		
		catch(Exception e) {
			logger.error("updateProductKioskQuantity ",e);
		}
	
		
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Long> getProductByKioskId(long kioskId) 
	{
		List<Long> list = null;
		try {
			list = getSession().createQuery("select product.id from ProductKiosk where kiosk.id=:kioskId").setParameter("kioskId",kioskId).list();
			System.out.println("doubt"+list);
		} catch(Exception e) {
			logger.error("getProductByKioskId ",e);
}
		return (list!=null && list.size()>0)?list:null;
		
	}
	}

	

	
	

	
	
	
	
	
	
	
	
	
	
	

