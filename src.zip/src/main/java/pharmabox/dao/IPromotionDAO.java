package pharmabox.dao;

import pharmabox.domain.Rewards;

public interface IPromotionDAO {
	Rewards getByCodeAndActive(String code);

	long registerNewPromotion(Rewards rewardObj);

	void updateReward(Rewards reward);

	

	
}
