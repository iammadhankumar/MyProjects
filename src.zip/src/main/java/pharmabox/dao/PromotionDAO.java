package pharmabox.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pharmabox.domain.Rewards;

@Repository
@Transactional
public class PromotionDAO implements IPromotionDAO  {
	
	private static final Logger logger = LoggerFactory.getLogger(PromotionDAO.class);

	
	@Autowired
	private SessionFactory sessionFactory;

	
	private Session getSession(){
		return sessionFactory.getCurrentSession();
	}

	
	@Override
	public long registerNewPromotion(Rewards rewardObj) {
		Long id = -1L;
		try {
			id=(Long) getSession().save(rewardObj);
		} catch(Exception e) {			
			logger.error("registerNewPromotion ",e);
		}
		return id;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Rewards getByCodeAndActive(String code) {
		List<Rewards> list=null;
		try
		{
			list = sessionFactory.getCurrentSession().createQuery("from Rewards where promoCode=:code").setParameter("code",code).list();
		}
		 catch (Exception e) {
				logger.error("getByCodeAndActive ",e);
			}
		return (list!=null && list.size()>0)?(Rewards)list.get(0):null;
	}


	@Override
	public void updateReward(Rewards reward) {
		try {
			getSession().update(reward);
		} catch(Exception e) {
			logger.error("updateKiosk ",e);
		}		
	}



}
