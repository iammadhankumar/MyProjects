package pharmabox.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pharmabox.domain.VerificationCode;

@SuppressWarnings("unchecked")
@Repository
@Transactional
public class VerificationDAO implements IVerificationDAO {
	private static final Logger logger = LoggerFactory.getLogger(VerificationDAO.class);

	@Autowired
	private SessionFactory sessionFactory;

	private Session getSession(){
		return sessionFactory.getCurrentSession();
	}

	@Override
	public long save(VerificationCode verificationcode) {
		long code = 0;
		try {
			code = (long) getSession().save(verificationcode);
		} catch(Exception e) {
        logger.error("save ",e);
   }
		return code;
	}
	
	@Override
	public void update(VerificationCode verificationcode) {
		try {
			getSession().update(verificationcode);
		} catch(Exception e) {
	        logger.error("update ",e);
		}
	}

	@Override
	public VerificationCode getVerificationByverificationId(long id) {
		List<VerificationCode> list = null;
		try {
			list = getSession().createQuery("from VerificationCode where id = ?").setParameter(0, id).list();
		}
		catch(Exception e) {
	        logger.error("getVerificationByverificationId ",e);
		
			}
		 return (list!=null && list.size()>0)?list.get(0):null;	}
	

	@Override
	public VerificationCode getVerificationByverificationCode(String code) {
	List<VerificationCode> list = null;
	try {
		list = getSession().createQuery("from VerificationCode where verificationCode = ? and active = true").setParameter(0, code).list();
	}
	catch(Exception e) {
        logger.error("getVerificationByverificationCode ",e);
	}
	 return (list!=null && list.size()>0)?list.get(0):null;	}
	
	@Override
	public List<VerificationCode> getVerificationListByUserId(long userId) {
	List<VerificationCode> list = null;
	try {
		list = getSession().createQuery("from VerificationCode where user_id.user_id = ? and active = true").setParameter(0, userId).list();
	}
	catch(Exception e) {
        logger.error("getVerificationListByUserId ",e);
	}
	 return (list!=null && list.size()>0)?list:null;	}
}
		

	
	

