package pharmabox.dao;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pharmabox.domain.OrderBasket;


@Repository
@Transactional
public class OrderBasketDAO implements IOrderBasketDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(OrderBasketDAO.class);


	
	@Autowired
	private SessionFactory sessionFactory;

	private Session getSession(){
		return sessionFactory.getCurrentSession();
	}

	@Override
	public long registerNewOrder(OrderBasket orderBasketObj) {
		Long id = -1L;
		try {
			id=(Long) getSession().save(orderBasketObj);
		} catch(Exception e) {			
			logger.error("registerNewOrder ",e);
		}
		return id;
	}

	}
	

	

