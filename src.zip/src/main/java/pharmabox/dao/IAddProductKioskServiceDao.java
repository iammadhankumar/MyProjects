package pharmabox.dao;

import java.util.List;

import pharmabox.domain.ProductKiosk;

public interface IAddProductKioskServiceDao {


	public long registerNewProductKiosk(ProductKiosk productkiosk);

	public ProductKiosk getProductkiosk_id(long productkiosk_id);

	public List<ProductKiosk> getAllProductlist(long kiosk_id,long product_type_id,String searchText);

	public ProductKiosk checkQuantity(long productkiosk_id);
	
	public ProductKiosk getProductKioskByproductId(long productId,long kioskid);

	public void updateProductKiosk(ProductKiosk productKiosk);
	
	public ProductKiosk getKioskBypId(long product_id);
	
	public ProductKiosk getProductAndKiosk(long product_id);
	
	public ProductKiosk getKioskByProductKioskId(long productkioskid);
	
	public List<ProductKiosk> getAllProductListByProductTypeandKiosk(long kioskId,List<Long> productObj,long productType,int pagenumber,int pagerecord);
	
	public ProductKiosk getProductKioskByProductandKioskId(long kioskId,long productId);
	
	public List<Long> getKioskByproductId(long pid);
	
	public long getKioskCount(long pid);
	
	public List<ProductKiosk> getProductKioskId(long productId);
	
	public List<Long> getProductByKioskId(long kioskId);
	
	 public List<Long> getKioskIdByProductKioskId(List<ProductKiosk> productkioskid);
	 
		public ProductKiosk getProductKioskInfo(long kioskId,long productId,long qt);
		
		public ProductKiosk getProductKioskBypId(long id);
		public ProductKiosk getProductkiosk(long pid);
	
		public void updateProductKioskQuantity(long qt,long pid);
		
		public List<ProductKiosk> getProductKioskbyKiosk(long kioskId);
	
	

//	public ProductKiosk getKioskByProductKioskId(long productkiosk_id);

	







	
	
	
}
