package pharmabox.dao;

import java.util.List;

import pharmabox.domain.Order;
import pharmabox.domain.OrderBasket;
import pharmabox.domain.Product;
import pharmabox.domain.RewardsPurchaseInfo;
import pharmabox.domain.User;

public interface IOrderDAO {
	
	public long registerNewOrder(Order order);
	public List<User> getUserInfo(long userId);
	public List<Product> getProductInfo(long pid);
	public Order getOrderInfo(String orderNo);
	public List<Order> getOrderInfoByUser(long userId,int pagenumber,int pagerecord);
	public long getorderCount(long userId,boolean purchase);
	public Order getOrderInfoById(long userId,String orderNumber,long orderId);
	public List<OrderBasket> getOrderBasketInfoByUser(long userId,int pagenumber,int pagerecord);
	public List<Order> getOrderInfoList(int pagenumber,int pagerecord);
	public List<Order> getOrderDetailsByUser(long userId,int pagenumber,int pagerecord);
	public long registerRewardsPurchaseInfo(RewardsPurchaseInfo rewardPurchase);
	public RewardsPurchaseInfo getRewardPurchaseInfoById(long id);
	public long getOrderInfoListCount();
	public Order getOrderInfoByBasket(long bid);
	public List<Order>  getOrderInfoByUserId(List<User> userId);
	public Order getOrderByOrderNo(String orderNo);
	void updateOrder(Order order);

}
