package pharmabox.dao;

import java.util.List;

import pharmabox.domain.VerificationCode;

public interface IVerificationDAO {

	 public long save(VerificationCode verificationcode);
	 
	 public void update(VerificationCode verificationcode);

	public VerificationCode getVerificationByverificationId(long id);
	
	public VerificationCode getVerificationByverificationCode(String code);

	public List<VerificationCode> getVerificationListByUserId(long userId);

}
