package pharmabox.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pharmabox.domain.DeviceToken;
import pharmabox.domain.User;
import pharmabox.domain.UserType;






@SuppressWarnings("unchecked")
@Repository
@Transactional



public class UserDAO implements IUserDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(UserDAO.class);
	
	@Autowired
	private SessionFactory sessionFactory;

	
	private Session getSession(){
		return sessionFactory.getCurrentSession();
	}
	

	@Override
	public long registerNewUser(User userObj) {
		Long id = -1L;
		try {
			id=(Long) getSession().save(userObj);
		} catch(Exception e) {			
			logger.error("registerNewUser ",e);
		}
		return id;
	}
	
	@Override
	public List<User> getAllUsers() {
		String hql = "from User ORDER BY created_on DESC ";
		List<User> list = null;
		try {
			list = getSession().createQuery(hql).list();			
			for(int i=0;i<list.size();i++);			
		} catch(Exception e) {
			logger.error("getAllUsers ",e);
		}
		return list!=null &&!list.isEmpty()?list:null;
	}
	
	
	
	
	
	@Override
	public List<User> getAllUsersByStatus(int stat) {
		String hql ="";
		
		switch(stat)
		{
		case 1:
			hql = "from User where active=1 ORDER BY created_on DESC ";
			break;

		case 2:
			hql = "from User where active=0 ORDER BY created_on DESC ";
			break;

		default:
			hql = "from User ORDER BY created_on DESC ";
			break;	
		}
		List<User> list = null;
		try {
			list = getSession().createQuery(hql).list();			
			for(int i=0;i<list.size();i++);			
		} catch(Exception e) {
			logger.error("getAllUsersByStatus ",e);
		}
		return list!=null &&!list.isEmpty()?list:null;
	}

	@Override
	public User getUserByEmail(String email) {
		List<User> userList = null;
		try {
			userList = getSession().createQuery("from User where email=? ").setParameter(0, email).list();
		} catch(Exception e) {
			logger.error("getUserByEmail ",e);
		}

		return userList!=null && !userList.isEmpty()?userList.get(0):null;
	}
	
	
	@Override
	public User getUserByVerificationCode(String verification_Code) {
		List<User> userList = null;
		try {
			userList = getSession().createQuery("from User where VerificationCode.verificationCode=? and active=1 ").setParameter(0, verification_Code).list();
		} catch(Exception e) {
			logger.error("getUserByVerificationCode ",e);
		}
		
		return userList!=null && !userList.isEmpty()?userList.get(0):null;
	}


	@Override
	public User getCurrentLocation(String lat,String lang)
	{
		List<UserType> list = null;
		try
		{
			list =getSession().createQuery("from User where user_id=?").setParameter(0, lat).setParameter(1,lang).list();
		}
		
		catch(Exception e)
		{
			logger.error("getCurrentLocation ",e);
		}
		 return (User) ((list!=null && !list.isEmpty())?list:null);
		
	}


	@Override
	public UserType getUserTypeById(long userType) {
		List<UserType> list = null;
		try {
			list = getSession().createQuery("from UserType where userTypeId=?").setParameter(0,userType).list();
		} catch(Exception e) {
			logger.error("getUserTypeById ",e);
		}
		return (list!=null && list.size()>0)?(UserType)list.get(0):null;
	}

	@Override
	public User getUserById(long user_id) {
		List<User> list = null;
		try {
			list = getSession().createQuery("from User where user_id=? ").setParameter(0,user_id).list();
		} catch(Exception e) {
			logger.error("getUserById ",e);
		}
		return (list!=null && list.size()>0)?(User)list.get(0):null;
	}
	
	
	@Override
	public User getUserById(User user) {
		List<User> list = null;
		try {
			list = getSession().createQuery("from User where user=? and active=1").setParameter(0,user).list();
		} catch(Exception e) {
			logger.error("getUserById ",e);
		}
		return (list!=null && list.size()>0)?(User)list.get(0):null;
	}

	
	
	@Override
	public User getLocation(long userId)
	{List<User> list = null;
	try
	{
		list=getSession().createQuery("from User u where u.userId=?").setParameter(0,userId).list();
	}
	catch(Exception e)
	{
		logger.error("getLocation ",e);
	}
	return (list!=null && list.size()>0)?(User)list.get(0):null;
	}

	@Override
	public User getUserByFacebook(String facebook_id) {
		List<User> userList = null;
		try {
			userList = getSession().createQuery("from User where facebook_id=? and active=1 ").setParameter(0, facebook_id).list();
		} catch(Exception e) {
			logger.error("getUserByFacebook ",e);
		}
	
		return userList!=null && !userList.isEmpty()?userList.get(0):null;
	}

	
	
	@Override
	public void updateUser(User user) {
		try {
			getSession().update(user);
		} catch(Exception e) {
			logger.error("updateUser ",e);
		}
	}
	
	
	


	public DeviceToken getDeviceTokenByUserId(long user_id) {
		List<DeviceToken> list = null;
		try{
			list = getSession().createQuery("from DeviceToken where user_id.user_id=? and active=1").setParameter(0, user_id).list();
		}catch(Exception e){
			logger.error("getDeviceTokenByUserId ",e);
		}
		return ((list !=null && list.size()>0) ?list.get(0):null);	
	}
	
	@Override
	public void saveDeviceToken(DeviceToken token) {

		try {
			getSession().save(token);
		} catch(Exception e) {			
			logger.error("saveDeviceToken ",e);
		}
	}
	
	@Override
	public void updateDeviceToken(DeviceToken token) {
		try {
			getSession().update(token);
		} catch(Exception e) {
			logger.error("updateDeviceToken ",e);
		}
	}
	
	@Override
	public User getUserPasswordByEmailId(String email) {
		List<User> userList = null;
		try {
			userList = getSession().createQuery("from User where email=:email and active=1").setParameter("email", email).list();
		} catch(Exception e) {
			logger.error("getUserPasswordByEmailId ",e);
		}

		return userList!=null && !userList.isEmpty()?userList.get(0):null;
	}
	





	@Override
	public User getUserByuserIdAndNotification(long userID, boolean b) {
		List<User> list = null;
		try {
			list = getSession().createQuery("from User where user_id=? and active=1 and notification=?")
					.setParameter(0,userID).setParameter(1, b).list();
		} catch(Exception e) {
			logger.error("getUserByuserIdAndNotification ",e);
		}
		return (list!=null && list.size()>0)?(User)list.get(0):null;
	}


	@Override
	public User getUserByEmailAndType(String email, long type) {
		List<User> list = null;

		try
		{
	   System.out.println("TYPE "+type);
	   if(type==0)
	   {
		   
		   System.out.println("INNN TYPE 0");
			list= getSession().createQuery("from User where email=:email and userType.userTypeId <> 1").setParameter("email", email).list();
             System.out.println("LIST "+list);
	   }
	   else
	   {
		list= getSession().createQuery("from User where email=:email and userType.userTypeId=:type").setParameter("email", email).setParameter("type",type).list();
		 System.out.println("LIST "+list);
	   }
		}
		catch(Exception e) {
			logger.error("getUserByEmailAndType ",e);
		}
		 
			return list!=null && !list.isEmpty()?list.get(0):null;
	}







}

	
