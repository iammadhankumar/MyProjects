package pharmabox.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pharmabox.domain.Kiosk;
import pharmabox.domain.Rewards;
import pharmabox.domain.RewardsMaintain;
import pharmabox.domain.ScrollingContent;



@SuppressWarnings("unchecked")
@Repository
@Transactional
public class AdminDAO implements IAdminDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(AdminDAO.class);
	
	@Autowired
	private SessionFactory sessionFactory;

	private Session getSession(){
		return sessionFactory.getCurrentSession();
	}
	
	@Override
	public long registerRewardInfo(Rewards reward) {
		Long id = -1L;
		try {
			id=(Long) getSession().save(reward);
		} catch(Exception e) {			
			logger.error(" ",e);
		}
		return id;
	}

	
	@Override
	public long registerScrollingContentInfo(ScrollingContent scrollingContent) {
		Long id = -1L;
		try {
			id=(Long) getSession().save(scrollingContent);
		} catch(Exception e) {			
			logger.error(" ",e);
		}
		return id;
	}
	
	@Override
	public RewardsMaintain getRewardsMaintainByUser(long rewardId,long userId)
	{
	List<RewardsMaintain> list=null;
	try
	{
		
		list=getSession().createQuery("from RewardsMaintain where reward.id=:rewardId and active=1 and user.user_id=:userId and purchase=0").setParameter("rewardId",rewardId).setParameter("userId", userId).list();
	}
	 catch(Exception e) {			
			logger.error(" ",e);
		}
	 return list!=null && !list.isEmpty()?list.get(0):null; 
	}
	@Override
	public long registerRewardsInfoByUser(RewardsMaintain rewardsMaintain) {
		Long id = -1L;
		try {
			id=(Long) getSession().save(rewardsMaintain);
		} catch(Exception e) {			
			logger.error("registerRewardsInfoByUser ",e);
		}
		return id;
	}
	
	
	@Override
	public void removeRewards(long rewardId) {
		try {			
			sessionFactory.getCurrentSession().createQuery("Update RewardsMaintain SET active=0 where reward.id=:rewardId").setParameter("rewardId",rewardId).executeUpdate();
		} catch(Exception e) {
			logger.error("removeRewards ",e);
		}
	}
	
	
	
	@Override
	public void deleteRewards(long userId) {
		try {			
			sessionFactory.getCurrentSession().createQuery("Update RewardsMaintain SET active=0 where user.id=:userId").setParameter("userId",userId).executeUpdate();
		} catch(Exception e) {
			logger.error("deleteRewards ",e);
		}
	}
	
	@Override
	public void updateRewards(Rewards reward) {
		try {
			getSession().update(reward);
		} catch(Exception e) {
			logger.error("updateRewards ",e);
		}
	}
	
	@Override
	public List<Rewards> getRewardsList(long userId,int pagenumber,int pagerecord)
	{
		List<Rewards> list=null;
		Query q=null;
		try
		{
			q=getSession().createQuery("from Rewards where id not in (select reward.id from RewardsMaintain where user.user_id=:userId and active=1) and expiryOn>now() and active=1").setParameter("userId",userId);
			 if(pagenumber > 0 && pagerecord > 0)
    		 {
    		q.setFirstResult(((pagenumber-1) * pagerecord));
              q.setMaxResults(pagerecord);
    		 }
				list=	q.list() ;
		}
		catch(Exception e)
		{
			logger.error("getRewardsList ",e);
		}
		   return list!=null && !list.isEmpty()?list:null; 
	}
	
	@Override
	public List<Rewards> getRewardsListByPromocode(String promocode)
	{
		List<Rewards> list=null;

		try
		{
			list=getSession().createQuery("from Rewards where promoCode=:promocode and active=1 ").setParameter("promocode",promocode).list();
			
		}
		catch(Exception e)
		{
			logger.error("getRewardsListByPromocode ",e);
		}
		   return list!=null && !list.isEmpty()?list:null; 
	}
	
	
	
	
	
	
	
	
	@Override
	public Rewards getRewardById(long id)
	{
		List<Rewards> list=null;
		try
		{
			list=getSession().createQuery("from Rewards where id=:id and active=1 ").setParameter("id",id).list();
			
		 System.out.println("FAV LISTS :"+list);
		}
		catch(Exception e)
		{
			logger.error("getRewardById ",e);
		}
		   return list!=null && !list.isEmpty()?list.get(0):null; 
	}
	
	
	@Override
	public Rewards getRewardId(long id)
	{
		List<Rewards> list=null;
		try
		{
			list=getSession().createQuery("from Rewards where id=:id").setParameter("id",id).list();
					}
		catch(Exception e)
		{
			logger.error("getRewardId ",e);
		}
		   return list!=null && !list.isEmpty()?list.get(0):null; 
	}
	
	
	
	@Override
	public RewardsMaintain getUsedRewardById(long id,long userId)
	{
		List<RewardsMaintain> list=null;
		try
		{
			list=getSession().createQuery("from RewardsMaintain where reward.id=:id and active=1 and user.id=:userId").setParameter("id",id).setParameter("userId",userId).list();
			}
		catch(Exception e)
		{
			logger.error("getUsedRewardById ",e);
		}
		   return list!=null && !list.isEmpty()?list.get(0):null; 
	}



	
	
	@Override
	public Rewards getRewardByPromoCode(String code)
	{
		List<Rewards> list=null;
		try
		{
			list=getSession().createQuery("from Rewards where promoCode=:code ").setParameter("code",code).list();
		}
		catch(Exception e)
		{
			logger.error("getRewardByPromoCode ",e);
		}
		   return list!=null && !list.isEmpty()?list.get(0):null; 
	}
	
	
	@Override
	public Rewards getRewardByName(String rewardName)
	{
		List<Rewards> list=null;
		try
		{
			list=getSession().createQuery("from Rewards where name=:rewardName and active=1 ").setParameter("rewardName",rewardName).list();
		}
		catch(Exception e)
		{
			logger.error("getRewardByName ",e);
		}
		   return list!=null && !list.isEmpty()?list.get(0):null; 
	}
	
	@Override
	public List<Rewards> getAllRewardsList(long userId)
	{
		List<Rewards> list=null;
		Query q=null;
		try
		{

        q=getSession().createQuery("from Rewards where id not in (select reward.id from RewardsMaintain where user.user_id=:userId and active=1) and expiryOn>now() and active=1").setParameter("userId", userId);
			
				list=	q.list() ;
		 System.out.println("FAV LISTS :"+list);
		}
		catch(Exception e)
		{
			logger.error("getAllRewardsList ",e);
		}
		   return list!=null && !list.isEmpty()?list:null; 
	}
	
	@Override
	public List<Rewards> getOverAllRewardsList(int pagenumber,int pagerecord)
	{
		List<Rewards> list=null;
		Query q=null;
		try
		{


			q=getSession().createQuery("from Rewards where active=1");

			if(pagenumber > 0 && pagerecord > 0)
			{
				q.setFirstResult(((pagenumber-1) * pagerecord));
				q.setMaxResults(pagerecord);
			}

			list=	q.list() ;
		}
		catch(Exception e)
		{
			logger.error("getOverAllRewardsList ",e);
		}
		return list!=null && !list.isEmpty()?list:null; 
	}
	
	
	@Override
	public List<Rewards> getAllRewards(int pagenumber,int pagerecord)
	{
		List<Rewards> list=null;
		Query q=null;
		try
		{


			q=getSession().createQuery("from Rewards");

			if(pagenumber > 0 && pagerecord > 0)
			{
				q.setFirstResult(((pagenumber-1) * pagerecord));
				q.setMaxResults(pagerecord);
			}

			list=	q.list() ;
			System.out.println("FAV LISTS :"+list);
		}
		catch(Exception e)
		{
			logger.error("getAllRewards ",e);
		}
		return list!=null && !list.isEmpty()?list:null; 
	}
	
	
	@Override
	public List<Kiosk> getAllKiosks(int pagenumber,int pagerecord,int sortColumn,int SortType)
	{
		List<Kiosk> list=null;
		Query q=null;
		String qString="";
		try
		{

			switch(sortColumn)
			{
			case 1:
				qString=SortType==0?"from Kiosk order by id asc":"from Kiosk order by id desc";
				break;
			
			case 2:
				qString=SortType==0?"from Kiosk order by kioskId asc":"from Kiosk order by kioskId desc";
				break;
			
			case 3:
				qString=SortType==0?"from Kiosk order by kioskName asc":"from Kiosk order by kioskName desc";
				break;
				
			default:
			qString = "from Kiosk order by id asc ";
			break;	
		}

            q=getSession().createQuery(qString);
			if(pagenumber > 0 && pagerecord > 0)
			{
				q.setFirstResult(((pagenumber-1) * pagerecord));
				q.setMaxResults(pagerecord);
			}

			list=	q.list() ;
		}
		catch(Exception e)
		{
			logger.error("getAllKiosks ",e);
		}
		return list!=null && !list.isEmpty()?list:null; 
	}
	
	
	@Override
	public List<Rewards> getAllRewardsListByall(int pagenumber,int pagerecord)
	{
		List<Rewards> list=null;
		Query q=null;
		try
		{

			q=getSession().createQuery("from Rewards ");

			if(pagenumber > 0 && pagerecord > 0)
			{
				q.setFirstResult(((pagenumber-1) * pagerecord));
				q.setMaxResults(pagerecord);
			}

			list=	q.list() ;
		}
		catch(Exception e)
		{
			logger.error("getAllRewardsListByall ",e);
		}
		return list!=null && !list.isEmpty()?list:null; 
	}
	

	@Override
	public long getOverAllRewardsListCount()
	{
		long count=0;
		try
		{
			count=getSession().createQuery("from Rewards where active=1").list().size();

		}
		catch(Exception e)
		{
			logger.error("getOverAllRewardsListCount ",e);
		}
		return count; 
	}


	
	
	
	@Override
	public List<ScrollingContent> getAllScrollingContentList()
	{
		List<ScrollingContent> list=null;
		Query q=null;
		try
		{
			q=getSession().createQuery("from ScrollingContent");
			list=	q.list() ;
		}
		catch(Exception e)
		{
			logger.error("getAllScrollingContentList ",e);
		}
		   return list!=null && !list.isEmpty()?list:null; 
	
	}
	
	@Override
	public List<ScrollingContent> getScrollingContentList(int pagenumber,int pagerecord)
	{
		List<ScrollingContent> list=null;
		Query q=null;
		try
		{
			q=getSession().createQuery("from ScrollingContent where active=1");
			 if(pagenumber > 0 && pagerecord > 0)
    		 {
    		q.setFirstResult(((pagenumber-1) * pagerecord));
              q.setMaxResults(pagerecord);
    		 }
				list=	q.list() ;
		}
		catch(Exception e)
		{
			logger.error("getScrollingContentList ",e);
		}
		   return list!=null && !list.isEmpty()?list:null; 
	}

	@Override
	public List<Rewards> getExpiredRewardsList() {
		List<Rewards> list=null;
		try
		{
			list=getSession().createQuery("from Rewards where expiry<=now()").list();
		}
		catch(Exception e)
		{
			logger.error("getExpiredRewardsList ",e);
		}
		return list;
	}

	@Override
	public void updateExpiredRewards() {
	
		try
		{
			getSession().createQuery("update Rewards set active=0 where expiryOn<=now() and active=1").executeUpdate();
		}
		catch(Exception e)
		{
			logger.error("updateExpiredRewards ",e);
		}
	}

}
