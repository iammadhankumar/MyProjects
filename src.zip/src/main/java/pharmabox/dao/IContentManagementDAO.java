package pharmabox.dao;

import java.util.List;

import pharmabox.domain.ContentManagement;


public interface IContentManagementDAO {

	List<ContentManagement> getAllContentManagement();

	ContentManagement getContentManagementByContentType(String label);
	
	public ContentManagement getPrivacyPolicyInfo(String label);



}
