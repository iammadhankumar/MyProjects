package pharmabox.dao;

import java.util.Date;
import java.util.List;

import pharmabox.domain.FavProduct;
import pharmabox.domain.Kiosk;
import pharmabox.domain.Product;
import pharmabox.domain.ProductType;
import pharmabox.domain.RecentViewProducts;

public interface IProductDAO {
	
	public Product getAllProductList();
	
	public List<ProductType> getAllProductType();
	public Product getById(long productId);
	public void deleteProduct(String  productId);

	public Product getProductByProductId(String productId);

	public Long addNewProduct(Product product);

	public void updateProduct(Product product);

	 public void updateFavProduct(FavProduct fav);

	 public List<FavProduct> getFavListsById(long userId,int pagenumber,int pagerecord);
	 
	
	 public void updateProductStatus(String productId);
 
	 public List<Product> getProduct();

	 public Product getByProduct();
	 
	 public List<Product> addProduct(List<Product> product);
	
     public Long addNewFavProduct(FavProduct fav);
     
	 public ProductType getProductTypeId(long productTypeId);
	
	 public  List<Product> getProductNames(long productTypeId, int pagenumber, int pagerecord);

	 public List<Product> getProductByName(String productName);
	 
	// public List<ProductType> getProductType(long productType, long userId);

	public FavProduct getByProductId(long productId,long userId);

	public List<Product> getProductlist(int pagenumber, int pagerecord);

	List<ProductType> getProductTypeList(int pagenumber, int pagerecord);

	public long getcountByUserIdAndActive(long user_id);
	
	public Long addNewProductType(ProductType producttype);
	
	public Long addNewKiosk(Kiosk kiosk);
	
	public ProductType getProductTypeName(String productTypeName);
	
	public Product getProductName(String productName);
	
	public List<Product> getProductTypeBylist(long productTypeId,int pagenumber, int pagerecord);

	List<String> getProductFavouriteByUser(long userId);

	public long getProductcountbyproductTypeId(long productTypeId);
	
	//public Product getKioskbyProduct(long pid);
	public Product getKioskbyProductId(long primarypId);
	
	public Product getpId(long id);
	
	public Product getQuantityOfBasketProduct(long primarypId);
	
	//public Basket getQuantityOfBasketProduct(long user_id);
	
	public Product getProductDetails(String pname,long pqt,String pid);
	
	public ProductType getProductTypeIdByProductTypeName(String pname);
	
	public Product getProductId(String pid);
	
	public List<Product> getSearchProductDetails(String searchValue);

	public List<Product> getAllSearchProductDetails(String searchValue,int pagenumber,int pagerecord);
	
	public List<Product> getAllProductListByProductKiosk(List<Long> pkobj);
	
	public List<Product> getAllProductListByProductObj(List<Long> productId,int pagenumber,int pagerecord);
	
	public List<FavProduct> getFavProductListByProductId(List<Product> productObj,long userId);
	
	public List<Product> getAllProductListByPk(long kioskId,int pagenumber,int pagerecord);
	
	public List<Product> getSearchProductListByKiosk(long kioskId,String searchValue);
	
	public List<Product> getProductLisByKiosk(long kioskId,String searchvalue,int pagenumber,int pagerecord);
	
	public List<Product> getProductListByProductTypeandKiosk(long kioskId,long productType);
	
	public List<Product> getAllProductListByProductTypeandKiosk(long kioskId,long productType,int pagenumber,int pagerecord);
	
	public List<RecentViewProducts> getAllRecentViewProductsByUser(long user,Date date, int pagenumber,int pagerecord);
	
	public long getRecentViewCount(long user,Date date);
	
	public List<RecentViewProducts> getAlreadyViewedProduct(long user,long productid);
	
	public RecentViewProducts selectLastRowTable(long user);

	public List<Product> getAllProductListByKiosk(long id, long productTypeid, int pagenumber, int pagerecord);
	public long getAllProductListByKioskCount(long id, long productTypeid,int pagenumber, int pagerecord);

	public List<Product> getProductListByKiosk(long kioskId, String searchValue, int pagenumber, int pagerecord);

	public long getProductCountByBasket(long kid);

	public Date getIntervelDate();

	public void updateProductType(ProductType pTObj);
	




	

}
