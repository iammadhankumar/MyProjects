package pharmabox.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pharmabox.domain.FavProduct;
import pharmabox.domain.Kiosk;
import pharmabox.domain.Product;
import pharmabox.domain.ProductKiosk;
import pharmabox.domain.ProductType;
import pharmabox.domain.RecentViewProducts;

@Repository
@Transactional
public class ProductDAO implements IProductDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(ProductDAO.class);


	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private EntityManager em;


	private Session getSession(){
		return sessionFactory.getCurrentSession();
	}

	@SuppressWarnings("unchecked")
	@Override
	public Product getAllProductList() {
		List<Product> list = null;
		try {
			list = sessionFactory
					.getCurrentSession()
					.createQuery(
							"from Product ").list();
		} catch (Exception e) {
			logger.error("getAllProductList ",e);
		}
		return (list!=null && list.size()>0)?(Product)list.get(0):null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Product getById(long id) {
		List<Product> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from Product where id =:id").setParameter("id", id).list();
		} catch(Exception e) {
			logger.error("getById ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
		
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public Product getpId(long id) {
		List<Product> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from Product where id =:id").setParameter("id", id).list();
		} catch(Exception e) {
			logger.error("getpId ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;		
	}
	

	@Override
	public void deleteProduct(String productId) {
		try {			
			sessionFactory.getCurrentSession().createQuery("Update Product SET IsDeleted=1 where id= ?").setParameter(0,productId).executeUpdate();
		} catch(Exception e) {
			logger.error("deleteProduct ",e);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Product getProductByProductId(String productId) {		
		List<Product> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from Product where productId=?").setParameter(0, productId).list();
		} catch(Exception e) {
			logger.error("getProductByProductId ",e);
		}
		return (list!=null && list.size()>0)?(Product)list.get(0):null;
	}

	

	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getProductByName(String productName) {		
		List<Product> list = null;
		try {
            list=sessionFactory.getCurrentSession().createQuery("from Product where productName like '%"+productName+"%'").list();

		} catch(Exception e) {
			logger.error("getProductByName ",e);
		}
		return list!=null && !list.isEmpty()?list:null;
	}	
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public  List<Product> getProductNames(long productTypeId,int pagenumber,int pagerecord) {		
		List<Product> list = null;
		Query q=null;
		try {
			q=sessionFactory.getCurrentSession().createQuery("from Product where productType.id=?")
					.setParameter(0, productTypeId);
				
			 if(pagenumber > 0 && pagerecord > 0)
    		 {
    		q.setFirstResult(((pagenumber-1) * pagerecord));
              q.setMaxResults(pagerecord);
    		 }
    	
    		
    		list=q.list() ;
    		   
		} catch(Exception e) {
			logger.error("getProductNames ",e);
		}
		return (list!=null && list.size() > 0)?list:null;

	}	
	
	
	
	
	@Override
	public Long addNewProduct(Product product) {
		Long id = -1L;
		try{
			id=(Long) getSession().save(product);
		} catch(Exception e) {
			logger.error("addNewProduct ",e);
		}
		return id;
	}
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Product> addProduct(List<Product> product) {
		List<Product> list = null;
		try{
			list=(List<Product>) getSession().save(product);
		} catch(Exception e) {
			logger.error("addProduct ",e);
		}
		return list!=null && !list.isEmpty()?list:null;
	}
	

	
	@Override
	public Long addNewKiosk(Kiosk kiosk) {
		Long id = -1L;
		try{
			id=(Long) getSession().save(kiosk);
		} catch(Exception e) {
			logger.error("addNewKiosk ",e);
		}
		return id;
	}
	
	@Override
	public Long addNewProductType(ProductType producttype) {
		Long id = -1L;
		try{
			id=(Long) getSession().save(producttype);
		} catch(Exception e) {
			logger.error("addNewProductType ",e);
		}
		return id;
	}


	@Override
	public Long addNewFavProduct(FavProduct fav) {
		Long id = -1L;
		try{
			id=(Long) getSession().save(fav);
		} catch(Exception e) {
			logger.error("addNewFavProduct ",e);
		}
		return id;
	}
	
	
	@Override
	public void updateProduct(Product product) {		
		try {
			getSession().update(product);
		} catch(Exception e) {
			logger.error("updateProduct ",e);
		}
	}
	@Override
	public void updateProductType(ProductType pTObj) {
		try {
			getSession().update(pTObj);
		} catch(Exception e) {
			logger.error("updateProductType ",e);
		}
	}

	
	@Override
	public void updateFavProduct(FavProduct fav) {		
		try {
			getSession().update(fav);
		} catch(Exception e) {
			logger.error("updateFavProduct ",e);
		}
	}

	
	

	@Override
	public void updateProductStatus(String productId) {
		try {			
			sessionFactory.getCurrentSession().createQuery("Update Product SET isSelected=0 where id!= ?").setParameter(0,productId).executeUpdate();
		} catch(Exception e) {
			logger.error("updateProductStatus ",e);
		}	
	}

	@SuppressWarnings("unchecked")
	@Override
	public Product getByProduct() {
		List<Product> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from Product ").list();
		} catch(Exception e) {
			logger.error("getByProduct ",e);
		}
		return (list!=null && list.size()>0)?(Product)list.get(0):null;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getProduct() {
		List<Product> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from Product ").list();
		} catch(Exception e) {
			logger.error("getProduct ",e);
		}
		return (list!=null && list.size() > 0)?list:null;

		
				}
	
	
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getProductFavouriteByUser(long userId) {
		List<String> list = null;
		try {
		list=sessionFactory.getCurrentSession().createSQLQuery("select CONVERT(DC_PRODUCTID,CHAR) from tbl_favourite where DC_ACTIVE =1 and DN_USERID ="+userId).list();
		} catch(Exception e) {
			logger.error("getProductFavouriteByUser ",e);
		}
		return (list!=null && list.size() > 0)?list:null;

		
				}
	
	@SuppressWarnings("unchecked")
	@Override
	public ProductType getProductTypeName(String productTypeName) {
		List<ProductType> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from ProductType where productTypeName=:productName")
					.setParameter("productName", productTypeName).list();
		} catch(Exception e) {
			logger.error("getProductTypeName ",e);
		}
		return (list!=null && list.size() > 0)?list.get(0):null;

		
				}
	
	@SuppressWarnings("unchecked")
	@Override
	public Product getProductName(String productName) {
		List<Product> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from Product where productName=:productName")
					.setParameter("productName", productName).list();
		} catch(Exception e) {
			logger.error("getProductName ",e);
		}
		return (list!=null && list.size() > 0)?list.get(0):null;

		
				}
	
	

	@SuppressWarnings("unchecked")
	@Override
	public ProductType getProductTypeId(long productTypeId) {
		List<ProductType> list = null;
		try {
			
			list=sessionFactory.getCurrentSession().createQuery("from ProductType where id=:productTypeId").setParameter("productTypeId", productTypeId).list();
		} catch(Exception e) {
			logger.error("getProductTypeId ",e);
		}
		return (list!=null && list.size()>0)?(ProductType)list.get(0):null;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public ProductType getProductTypeIdByProductTypeName(String pname) {
		List<ProductType> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from ProductType where productTypeName=:pname").setParameter("pname", pname).list();
		} catch(Exception e) {
			logger.error("getProductTypeIdByProductTypeName ",e);
		}
		return (list!=null && list.size()>0)?(ProductType)list.get(0):null;
	}
	

	@SuppressWarnings("unchecked")
	@Override
	public List<ProductType> getAllProductType() {
		List<ProductType> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from ProductType").list();
		} catch(Exception e) {
			logger.error("getAllProductType ",e);
		}
		 return ((list!=null && list.size()>0)?list:null);
	}

	@SuppressWarnings("unchecked")
	@Override
	public FavProduct getByProductId(long id, long userId) {
                List<FavProduct> list = null;
		
		try {
			
			
			list=sessionFactory.getCurrentSession().createQuery("from FavProduct where product.id=? and user.user_id=?")
					.setParameter(0, id)
					.setParameter(1, userId)
					.list();
		} catch(Exception e) {
			logger.error("getByProductId ",e);
		}
		  return list !=null && !list.isEmpty()?list.get(0):null; 	
	}

	
	

	@SuppressWarnings("unchecked")
	public List<FavProduct> getFavListsById(long userId,int pagenumber,int pagerecord)
	{
		List<FavProduct> list=null;
		Query q=null;
		try
		{
			q=sessionFactory.getCurrentSession().createQuery("from FavProduct where active=1 and user.user_id=:userId order by createdOn desc ").setParameter("userId",userId);
			 if(pagenumber > 0 && pagerecord > 0)
    		 {
    		q.setFirstResult(((pagenumber-1) * pagerecord));
              q.setMaxResults(pagerecord);
    		 }
				list=	q.list() ;
		}
		catch(Exception e)
		{
			logger.error("getFavListsById ",e);
		}
		   return list!=null && !list.isEmpty()?list:null; 
	
	}

	
	@SuppressWarnings("unchecked")
	public List<Product> getAllProductListByProductTypeandKiosk(long kioskId,long productType,int pagenumber,int pagerecord)
	{
		List<Product> list=null;
		Query q=null;
		try
		{   			
			q=sessionFactory.getCurrentSession().createQuery("from Product where productType.id=:productType and id IN(select product.id from ProductKiosk where kiosk.id=:kioskId)").setParameter("productType",productType).setParameter("kioskId", kioskId);
			
			 if(pagenumber > 0 && pagerecord > 0)
			 {
			q.setFirstResult(((pagenumber-1) * pagerecord));
		      q.setMaxResults(pagerecord);
			 }
			
			list = q.list();

		}
		catch(Exception e) {
			logger.error("getAllProductListByProductTypeandKiosk ",e);
		}
	return (list!=null && list.size()>0)?list:null;
	}
	
	
	
	@SuppressWarnings("unchecked")
	public List<Product> getProductListByProductTypeandKiosk(long kioskId,long productType)
	{
		List<Product> list=null;
		try
		{   
			
			list=sessionFactory.getCurrentSession().createQuery("from Product where productType.id=:productType and id IN(select product.id from ProductKiosk where kiosk.id=:kioskId)").setParameter("productType",productType).setParameter("kioskId", kioskId).list();
	        
			
		}
		catch(Exception e) {
			logger.error("getProductListByProductTypeandKiosk ",e);
		}
	return (list!=null && list.size()>0)?list:null;
	}
	

	
	
	@SuppressWarnings("unchecked")
	public List<Product> getProductListByKiosk(long kioskId,String searchValue,int pagenumber,int pagerecord)
	{
		List<Product> list=null;
		Query q=null;
		try
		{   
			q=sessionFactory.getCurrentSession().createQuery("from Product where id IN(select product.id from ProductKiosk where kiosk.id=:kioskId) and productName like '%"+searchValue+"%' ").setParameter("kioskId", kioskId);
			if(pagenumber > 0 && pagerecord > 0)
			 {
			q.setFirstResult(((pagenumber-1) * pagerecord));
		      q.setMaxResults(pagerecord);
			 }
			
			list = q.list();

			
		}
		catch(Exception e) {
			logger.error("getProductListByKiosk ",e);
		}
	return (list!=null && list.size()>0)?list:null;
	}
	
	
	
	
	@SuppressWarnings("unchecked")
	public List<Product> getSearchProductListByKiosk(long kioskId,String searchValue)
	{
		List<Product> list=null;
		try
		{   
			list=sessionFactory.getCurrentSession().createQuery("from Product where id IN(select product.id from ProductKiosk where kiosk.id=:kioskId) and productName like '%"+searchValue+"%' ").setParameter("kioskId", kioskId).list();

		}
		catch(Exception e) {
			logger.error("getSearchProductListByKiosk ",e);
		}
	return (list!=null && list.size()>0)?list:null;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getProductlist(int pagenumber, int pagerecord) {
		   List<Product> list= null;
		   Query q=null;
	        try {
	       
	               q = getSession().createQuery("from Product");
	                		 if(pagenumber > 0 && pagerecord > 0)
	                		 {
	                		q.setFirstResult(((pagenumber-1) * pagerecord));
		                      q.setMaxResults(pagerecord);
	                		 }
	                	
	                
	                		list=	q.list() ;
	                
	           System.out.println(list);
	             }
	            
	        catch(Exception e) {
	            logger.error("getProductlist ",e);
	        }       
	        return list !=null && !list.isEmpty()?list:null;
	    }

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getProductTypeBylist(long productTypeId,int pagenumber, int pagerecord) {
		   List<Product> list= null;
		   Query q=null;
	        try {
	            System.out.println(pagenumber);
	            System.out.println(pagerecord);
	               q = getSession().createQuery("from Product");
	                		 if(pagenumber > 0 && pagerecord > 0)
	                		 {
	                		q.setFirstResult(((pagenumber-1) * pagerecord));
		                      q.setMaxResults(pagerecord);
	                		 }
	                	
	                
	                		list=	q.list() ;
	         	             }
	            
	        catch(Exception e) {
	            logger.error("getProductTypeBylist ",e);
	        }       
	        return list !=null && !list.isEmpty()?list:null;
	    }

	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ProductType> getProductTypeList(int pagenumber, int pagerecord) {
		   List<ProductType> list= null;
		   Query q=null;
	        try {
	
	               q = getSession().createQuery("from ProductType");
	                		 if(pagenumber > 0 && pagerecord > 0)
	                		 {
	                		q.setFirstResult(((pagenumber-1) * pagerecord));
		                      q.setMaxResults(pagerecord);
	                		 }
	                	
	                		
	                		list=q.list() ;
	                		   
	        
	             }
	            
	        catch(Exception e) {
	            logger.error("getProductTypeList ",e);
	        }       
	        return (list!=null && !list.isEmpty())?list:null;
	    }

	


	@Override
	public long getcountByUserIdAndActive(long user_id) {
		long favcount = 0;
		try {
			favcount = sessionFactory.getCurrentSession().createQuery("from FavProduct where active=1 and user.user_id = :user_id").setParameter("user_id", user_id)
			.list().size();
		} catch(Exception e) {
			logger.error("getcountByUserIdAndActive ",e);
		}
		return favcount;
		
	}

	@Override
	public long getProductcountbyproductTypeId(long productTypeId) {
		long productTypeCount = 0;
		try {
			
			productTypeCount = sessionFactory.getCurrentSession().createQuery("from Product where productType.id=?").setParameter(0, productTypeId)
					.list().size();	
		} 
		catch(Exception e) {
			
			logger.error("getProductcountbyproductTypeId ",e);
		}
		return productTypeCount;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Product getKioskbyProductId(long primarypId) {		
		List<Product> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("from Product where id=:primarypId").setParameter("primarypId",primarypId).list();
		} catch(Exception e) {
			logger.error("getKioskbyProductId ",e);
		}
		return (list!=null && list.size()>0)?(Product)list.get(0):null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Product getQuantityOfBasketProduct(long primarypId) {
		List<Product> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery(" from Product where id=:primarypId").setParameter("primarypId",primarypId).list();
		} catch(Exception e) {
			logger.error("getQuantityOfBasketProduct ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
	}
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public Product getProductDetails(String pname,long pqt,String pid)
	{
		List<Product> list=null;
		try
		{
			list=sessionFactory.getCurrentSession().createQuery("from Product where productName=:pname and quantity=:pqt and productId=:pid ")
		    .setParameter("pname",pname)
		    .setParameter("pqt", pqt)
		    .setParameter("pid", pid).list();
		}
		 catch(Exception e) {
				logger.error("getProductDetails ",e);
			}
		return (list!=null && list.size()>0)?list.get(0):null;
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getAllProductListByProductKiosk(List<Long> pkobj)
	{
		List<Product> list=null;
		try
		{   
			
			Criteria c=getSession().createCriteria(ProductKiosk.class);
			c.add(Restrictions.in("id", pkobj));
			
			list = c.list();

		}
		catch(Exception e) {
			logger.error("getAllProductListByProductKiosk ",e);
		}
	return (list!=null && list.size()>0)?list:null;
	}
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getAllProductListByProductObj(List<Long> productId,int pagenumber,int pagerecord)
	{
		List<Product> list=null;
		Query q=null;
		try
		{   
			
			q=sessionFactory.getCurrentSession().createQuery("from Product where id IN productId");			    
			
			 if(pagenumber > 0 && pagerecord > 0)
			 {
			q.setFirstResult(((pagenumber-1) * pagerecord));
		      q.setMaxResults(pagerecord);
			 }
			
			list = q.list();

		}
		catch(Exception e) {
			logger.error("getAllProductListByProductObj ",e);
		}
	return (list!=null && list.size()>0)?list:null;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Product> getAllProductListByPk(long kioskId,int pagenumber,int pagerecord)
	{
		List<Product> list=null;
		Query q=null;
		try
		{   
			q=sessionFactory.getCurrentSession().createQuery("from Product where id IN (select product.id from ProductKiosk where kiosk.id=:kioskId )").setParameter("kioskId", kioskId);
			
	

			 if(pagenumber > 0 && pagerecord > 0)
			 {
			q.setFirstResult(((pagenumber-1) * pagerecord));
		      q.setMaxResults(pagerecord);
			 }
			
			list = q.list();

		}
		catch(Exception e) {
			logger.error("getAllProductListByPk ",e);
		}
	return (list!=null && list.size()>0)?list:null;
	}
	
	
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public Product getProductId(String pid)
	{
		List<Product> list=null;
		try
		{
			list=sessionFactory.getCurrentSession().createQuery("from Product where productId=:pid ")
			.setParameter("pid",pid)
		    .list();
		}
		 catch(Exception e) {
				logger.error("getProductId ",e);
			}
		return (list!=null && list.size()>0)?list.get(0):null;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<FavProduct> getFavProductListByProductId(List<Product> productObj,long userId)
	{
		List<FavProduct> list=null;
		try
		{

			list=sessionFactory.getCurrentSession().createQuery("from FavProduct where product.id  IN (select id from Product) and active=true and user.id=:userId")
				    .setParameter("userId", userId).list();
			
		}
		
		 catch(Exception e) {
				logger.error("getFavProductListByProductId ",e);
			}
		return (list!=null && list.size()>0)?list:null;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getSearchProductDetails(String searchValue) {
		String appendStr = "";
		List<Product> productList = null;
		Query q=null;
		try
		{
		if(searchValue!=null) {
			appendStr  = appendStr+" m.productName LIKE '%"+searchValue+"%'";
			appendStr  = " ( "+appendStr+" )";
			
		}
		String  SQL = "From Product as m where "+appendStr;
	q=getSession().createQuery(SQL);
	
	productList=q.list();
	if (productList!=null && productList.size() > 0 ) {
		return productList;
	}
	}
		catch(Exception e)
		{
			logger.error("getSearchProductDetails ",e);
		}
		return productList!=null && !productList.isEmpty()?productList:null;
}
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getAllSearchProductDetails(String searchValue,int pagenumber,int pagerecord) {
		String appendStr = "";
		List<Product> productList = null;
		Query q=null;
		try
		{
		if(searchValue!=null) {
			appendStr  = appendStr+" m.productName LIKE '%"+searchValue+"%'";
			appendStr  = " ( "+appendStr+" )";

		}
		String  SQL = "From Product as m where "+appendStr;
		q=getSession().createQuery(SQL);
		if(pagenumber > 0 && pagerecord > 0)
		{
			q.setFirstResult(((pagenumber-1) * pagerecord));
			q.setMaxResults(pagerecord);
		}

		productList=q.list();
	
		}
		catch(Exception e)
		{
			logger.error("getAllSearchProductDetails ",e);
		}
		return productList!=null && !productList.isEmpty()?productList:null;
	}

	
	
	@SuppressWarnings("unchecked")
	public List<RecentViewProducts> getAllRecentViewProductsByUser(long user,Date date,int pagenumber,int pagerecord)
	{
		List<RecentViewProducts> list=null;
	    Query q=null;
		try
		{
//               String qString="SELECT * FROM `tbl_recentview_products`  WHERE `DD_CREATED_ON` >= NOW() - DATE( DATE_SUB( `DD_CREATED_ON` , INTERVAL 3 DAY )) AND `DN_USER`=:user AND `DN_ACTIVE`=1 ORDER BY `DN_ID` DESC LIMIT 50";
			String qString="from RecentViewProducts where created_on between :date and now() and active=1 and user.user_id=:user order by id desc";
			q=getSession().createQuery(qString).setParameter("user", user).setParameter("date", date).setMaxResults(50);
			if(pagenumber > 0 && pagerecord > 0)
			{
				q.setFirstResult(((pagenumber-1) * pagerecord));
				q.setMaxResults(pagerecord);
			}

			
			list=q.list();
		}
		catch(Exception e) {
			logger.error("getAllRecentViewProductsByUser ",e);
		}
		
		return (list!=null && list.size()>0)?list:null;
	}
	
	
	public long getRecentViewCount(long user,Date date)
	{
		long count=0;
		try
		{
			count=getSession().createQuery("from RecentViewProducts where created_on  between :date  and now() and active=1 and user.user_id=:user ").setMaxResults(50).setParameter("date",date).setParameter("user", user).list().size();
		}
		catch(Exception e) {
			logger.error("getRecentViewCount ",e);
		}
		
		return count;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<RecentViewProducts> getAlreadyViewedProduct(long user,long productid)
	{
		List<RecentViewProducts> list=null;
		try
		{
		
           list=getSession().createQuery("from RecentViewProducts where product.id=:productid and user.user_id=:user and active=1").setParameter("user", user).setParameter("productid", productid).list();
     
        }
		
		catch(Exception e) {
			logger.error("getAlreadyViewedProduct ",e);
		}
		
		return (list!=null && list.size()>0)?list:null;
	}
	
	
	@SuppressWarnings("unchecked")
	public RecentViewProducts selectLastRowTable(long user)
	{
		List<RecentViewProducts> list=null;
		try
		{
		
           list=getSession().createQuery(" from RecentViewProducts where  active=1 and user.id=:user  order by id desc ").setParameter("user", user).list();
        }
		
		catch(Exception e) {
			logger.error("selectLastRowTable ",e);
		}
		
		return (list!=null && list.size()>0)?list.get(0):null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getAllProductListByKiosk(long id, long productTypeid,int pagenumber, int pagerecord) {
		List<Product> list=null;
		Query q=null;
		try{
		
	           q=getSession().createQuery(" from Product where id In( select product.id from ProductKiosk where kiosk.id=:id) and productType.id=:productTypeid ").setParameter("id", id).setParameter("productTypeid", productTypeid);
	           
	           if(pagenumber > 0 && pagerecord > 0)
	   		{
	   			q.setFirstResult(((pagenumber-1) * pagerecord));
	   			q.setMaxResults(pagerecord);
	   		}
	           
	           list=q.list();
               
		}
		catch(Exception e) {
			logger.error("getAllProductListByKiosk ",e);
		}
		return (list!=null && list.size()>0)?list:null;
	}
	
	@Override
	public long getAllProductListByKioskCount(long id, long productTypeid,int pagenumber, int pagerecord) {
		long count=0;
		try{
	           count=getSession().createQuery("from Product where id In( select product.id from ProductKiosk where kiosk.id=:id) and productType.id=:productTypeid ").setParameter("id", id).setParameter("productTypeid", productTypeid).list().size();
    
		}
		catch(Exception e) {
			logger.error("getAllProductListByKioskCount ",e);
		}
		return count;
	}

	@Override
	public List<Product> getProductLisByKiosk(long kioskId, String searchvalue, int pagenumber, int pagerecord) {
		return null;
	}

	@Override
	public long getProductCountByBasket(long kid) {
		long count=0;
		try{
			if(kid>0)
			{
	           count=getSession().createQuery("from Product where id In( select product.id from ProductKiosk where kiosk.id=:kid)").setParameter("kid", kid).list().size();
			}
			else
			{
		           count=getSession().createQuery("from Product").list().size();

			}
		}
		catch(Exception e) {
			logger.error("getProductCountByBasket ",e);
		}
		return count;
	}

	@Override
	public Date getIntervelDate()
	{
		List<Date> date=null;
		try
		{
		date=getSession().createSQLQuery("SELECT DATE( DATE_SUB( CURDATE() , INTERVAL 2 DAY ) )").list();
		System.out.println("DATE CHECK JDNFHJFBHJ "+date);
		}
		catch(Exception e) {
			logger.error("getIntervelDate ",e);
		}
		return date!=null && !date.isEmpty()?date.get(0):null;
	}



	
}
	

	
	
	
	
	
	
