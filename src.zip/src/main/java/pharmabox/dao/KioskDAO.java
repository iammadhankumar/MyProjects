package pharmabox.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pharmabox.domain.Kiosk;
import pharmabox.domain.ProductKiosk;
import pharmabox.views.KioskView;

@SuppressWarnings("unchecked")
@Repository
@Transactional
public class KioskDAO implements IKioskDAO {

	private static final Logger logger = LoggerFactory.getLogger(KioskDAO.class);

	@Autowired
	private SessionFactory sessionFactory;

	private Session getSession(){
		return sessionFactory.getCurrentSession();
	}

	@Override
	public long registerKioskDetails(Kiosk kioskObj) {
		Long id = -1L;
		try {
			id=(Long) getSession().save(kioskObj);
		} catch(Exception e) {			
			logger.error("registerKioskDetails ",e);
		}
		return id;
	}

	@Override
	public void updateKiosk(Kiosk kiosk) {
		try {
			getSession().update(kiosk);
		} catch(Exception e) {
			logger.error("updateKiosk ",e);
		}
	}

	
	
	public Kiosk getKioskBypId(long product_id) {
	List<Kiosk> list = null;
		try {
			list=sessionFactory.getCurrentSession().createQuery("select kiosk.id from ProductKiosk where product.id=:product_id").setParameter("product_id", product_id).list();
		} 
		
		
		catch(Exception e) {
			logger.error("getKioskBypId ",e);
		}
		return ((list !=null && list.size()>0) ?(Kiosk)list:null);
	}
	
	
	@Override
	public List<Kiosk> getAllKioskDetails() {
		List<Kiosk> kioskList = null;
		try {
			kioskList = getSession().createQuery("from Kiosk where IsDeleted=0").list();
		} catch(Exception e) {
			logger.error("getAllKioskDetails ",e);
		}
	
		return kioskList!=null && !kioskList.isEmpty()?kioskList:null;
	}

	@Override
	public List<Kiosk> getAllSearchKioskDetails(String searchValue) {
		String appendStr = "";
		List<Kiosk> kioskList = null;
		try
		{
		if(searchValue!=null) {
			appendStr  = appendStr+" m.address1 LIKE '%"+searchValue+"%'";
			appendStr  = appendStr+" OR m.address2 LIKE '%"+searchValue+"%'";
			appendStr  = appendStr+" OR m.state LIKE '%"+searchValue+"%'";
			appendStr  = appendStr+" OR m.city LIKE '%"+searchValue+"%'";
			appendStr  = appendStr+" OR m.zipcode LIKE '%"+searchValue+"%'";
			appendStr  = " ( "+appendStr+" )";
		}
		String  SQL = "From Kiosk as m where m.IsDeleted=0 and "+appendStr;
		kioskList=getSession().createQuery(SQL).list();
		}
		catch(Exception e)
		{
			logger.error("getAllSearchKioskDetails ",e);
		}
	
		return kioskList!=null && !kioskList.isEmpty()?kioskList:null;
	}

	@Override
	public Kiosk getKioskById(long id) {
		List<Kiosk> list = null;
		try {
			list = getSession().createQuery("from Kiosk where id=:id and active=1").setParameter("id",id).list();
		} catch(Exception e) {
			System.out.println("catch"+e);
			logger.error("getKioskById ",e);
		}
		return (list!=null && list.size()>0)?(Kiosk)list.get(0):null;
	}

	@Override
	public List<Kiosk> getAllKioskMap(String latitude, String longitude) {
		List<Kiosk> list = null;
		try {
			String SQL=
					" FROM Kiosk WHERE   "
							+"( 3959 * ACOS( COS( RADIANS(latitude) ) * COS( RADIANS("+latitude+" ) ) * COS( RADIANS( longitude) - RADIANS("+longitude+") ) + "
							+"SIN( RADIANS(latitude) ) * SIN( RADIANS( "+latitude+" ) ) ) )   < 15 ORDER BY latitude ASC";
			list= getSession().createQuery(SQL).list();
		} catch(Exception e)	{
			logger.error("getAllKioskMap ",e);
		}
		return ((list !=null && list.size()>0) ?list:null);
	}

	@Override
	public List<Kiosk> getAllKioskList(int pagenumber,int pagerecord) {
		List<Kiosk> list= null;
		Query q=null;
		try {
			q = getSession().createQuery(" from Kiosk where active=1 order by kioskName ASC");
			
			if(pagenumber > 0 && pagerecord > 0)
			 {
			q.setFirstResult(((pagenumber-1) * pagerecord));
		      q.setMaxResults(pagerecord);
			 }
			
			list = q.list();
		} catch(Exception e) {
			logger.error("getAllKioskList ",e);
		}
		return ((list !=null && list.size()>0) ?list:null);
	}
	
	
	@Override
	public List<Kiosk> getAllKioskListByKioskId(long kid) {
		List<Kiosk> list= null;
		try {
			list = getSession().createQuery("from Kiosk where id=:kid ORDER BY ASC ").setParameter("kid", kid).list();
		} catch(Exception e) {
			logger.error("getAllKioskListByKioskId ",e);
		}
		return ((list !=null && list.size()>0) ?list:null);
	}

	@Override
	public List<Kiosk> getKioskLocationDetail(long kiosk_id) {
		List<Kiosk> list= null;
		try {
			list = getSession().createQuery("from Kiosk where kiosk_id=? and IsDeleted=0 ").setLong(0,kiosk_id).list();
		} catch(Exception e) {
			logger.error("getKioskLocationDetail ",e);
		}
		return ((list !=null && list.size()>0) ?list:null);
	}

	@Override
	public void deleteKiosk(long kiosk_id) {
		try {
			sessionFactory.getCurrentSession().createQuery("Update Kiosk SET IsDeleted=1 where id= ?").setParameter(0,kiosk_id).executeUpdate();
		} catch(Exception e) {
			logger.error("deleteKiosk ",e);
		}
	}

	@Override
	public List<Kiosk> getAllKioskListByActions() {
		List<Kiosk> kioskList = null;
		try {
			kioskList = getSession().createQuery("from Kiosk where active=1 and IsDeleted=0").list();
		} catch(Exception e) {
			logger.error("getAllKioskListByActions ",e);
		}
	
		return kioskList!=null && !kioskList.isEmpty()?kioskList:null;
	}

	@Override
	public Kiosk getKioskByKioskId(long id) {
		List<Kiosk> list = null;
		try {
			list = getSession().createQuery("from Kiosk where id=? and active=1").setParameter(0,id).list();
		} catch(Exception e) {
			logger.error("getKioskByKioskId ",e);
		}
		return (list!=null && list.size()>0)?(Kiosk)list.get(0):null;
	}

	@Override
	public Kiosk getKioskId(long kioskId) {
		List<Kiosk> list = null;
		try {
			list = getSession().createQuery("from Kiosk where kioskId=:kioskId and active=1").setParameter("kioskId",kioskId).list();
		} catch(Exception e) {
			logger.error("getKioskId ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
	}
	
	@Override
	public Kiosk getKioskByKioskID(long kioskId) {
		List<Kiosk> list = null;
		try {
			list = getSession().createQuery("from Kiosk where kioskId=:kioskId").setParameter("kioskId",kioskId).list();
		} catch(Exception e) {
			logger.error("getKioskByKioskID ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
	}

    @Override
    public Kiosk getKioskName(String kioskName) {
        List<Kiosk> list = null;
        try {
            list=sessionFactory.getCurrentSession().createQuery("from Kiosk where kioskName=:kioskName")
                    .setParameter("kioskName", kioskName).list();
        } catch(Exception e) {
            logger.error("getKioskName ",e);
        }
        return (list!=null && list.size() > 0)?list.get(0):null;
                }
	
	@Override
	public Kiosk getKioskByKioskIdAction(long id) {
		List<Kiosk> list = null;
		try {
			list = getSession().createQuery("from Kiosk where id=?").setParameter(0,id).list();
		} catch(Exception e) {
			logger.error(" ",e);
		}
		return (list!=null && list.size()>0)?(Kiosk)list.get(0):null;
	}

	@Override
	public Kiosk getKioskByIdWithoutAction(long kiosk_id) {
		List<Kiosk> list = null;
		try {
			list = getSession().createQuery("from Kiosk where kiosk_id=?").setParameter(0,kiosk_id).list();
		} catch(Exception e) {
			logger.error("getKioskByIdWithoutAction ",e);
		}
		return (list!=null && list.size()>0)?(Kiosk)list.get(0):null;
	}

  @Override
	public ProductKiosk getKioskByProductKioskId(long productkioskid) {
		List<ProductKiosk> list = null;
		try {
			list = getSession().createQuery(" from ProductKiosk where id=:productkioskid ").setParameter("productkioskid",productkioskid).list();
		} catch(Exception e) {
			logger.error("getKioskByProductKioskId ",e);
}
		return (list!=null && list.size()>0)?list.get(0):null;
		
}

public List<Kiosk> getAllKioskListUsingKioskId (List<Long> pkObj)
{
	List<Kiosk> list=null;

	try
	{
		Criteria c=getSession().createCriteria(Kiosk.class);
		c.add(Restrictions.in("id", pkObj))
		.add(Restrictions.eq("active",true))
		.addOrder(Order.asc("kioskName"));
		list = c.list();
}
	
	catch(Exception e) {
		logger.error("getAllKioskListUsingKioskId ",e);
}
	return (list!=null && list.size()>0)?list:null;
}

@Override
public List<Kiosk> getKioskListByProductId(long pid) {
	return null;
}

@Override
public List<Kiosk> getAllKioskListByProduct(long pid, int pagenumber, int pagerecord) {
	List<Kiosk> list= null;
	Query q=null;
	try {
		q = getSession().createQuery("from KioskView where pid=:pid and active=1").setParameter("pid", pid);
		
		if(pagenumber > 0 && pagerecord > 0)
		 {
		q.setFirstResult(((pagenumber-1) * pagerecord));
	      q.setMaxResults(pagerecord);
		 }
		
		list = q.list();
	} catch(Exception e) {
		logger.error("getAllKioskListByProduct ",e);
	}
	return ((list !=null && list.size()>0) ?list:null);
}

@Override
public List<KioskView> getAllKioskViewListByProducts(long pid, int pagenumber, int pagerecord) {
	List<KioskView> list= null;
	Query q=null;
	try {
		q = getSession().createQuery("from KioskView where pid=:pid and active=1").setParameter("pid", pid);
		
		if(pagenumber > 0 && pagerecord > 0)
		 {
		q.setFirstResult(((pagenumber-1) * pagerecord));
	      q.setMaxResults(pagerecord);
		 }
		
		list = q.list();
	} catch(Exception e) {
		logger.error("getAllKioskViewListByProducts ",e);
	}
	return ((list !=null && list.size()>0) ?list:null);
}

@Override
public long getAllKioskViewListByProductscount(long pid) {
	long count=0;

	try {
		count = getSession().createQuery("from KioskView where pid=:pid and active=1").setParameter("pid", pid).list().size();
		
		
		
	} catch(Exception e) {
		logger.error("getAllKioskViewListByProductscount ",e);
	}
	return count;
}

@Override
public long getAllKioskListByProductcount(long pid) {
	long count=0;

	try {
		count = getSession().createQuery("from KioskView where pid=:pid and active=1").setParameter("pid", pid).list().size();
		
		
		
	} catch(Exception e) {
		logger.error("getAllKioskListByProductcount ",e);
	}
	return count;
}

}
		
