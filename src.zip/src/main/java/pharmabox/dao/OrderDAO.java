package pharmabox.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pharmabox.domain.Order;
import pharmabox.domain.OrderBasket;
import pharmabox.domain.Product;
import pharmabox.domain.RewardsPurchaseInfo;
import pharmabox.domain.User;

@SuppressWarnings("unchecked")
@Repository
@Transactional
public class OrderDAO implements IOrderDAO{
	
	private static final Logger logger = LoggerFactory.getLogger(OrderDAO.class);

	
	@Autowired
	private SessionFactory sessionFactory;

	private Session getSession(){
		return sessionFactory.getCurrentSession();
	}
	
	
	@Override
	public long registerNewOrder(Order order) {
		Long id = -1L;
		try {
			
			id=(Long) getSession().save(order);
		} catch(Exception e) {		
			logger.error("registerNewOrder ",e);
		}
		return id;
	}
	
	@Override
	public long registerRewardsPurchaseInfo(RewardsPurchaseInfo rewardPurchase) {
		Long id = -1L;
		try {
			
			id=(Long) getSession().save(rewardPurchase);
		} catch(Exception e) {		
			logger.error("registerRewardsPurchaseInfo ",e);
		}
		return id;
	}
	
	@Override
	public void updateOrder(Order order) {
		try {
			getSession().update(order);
		} catch(Exception e) {
			logger.error("updateUser ",e);
		}
	}
	
	
	
	@Override
	public List<User> getUserInfo(long userId)
	{
		List<User> list=null;
		try {
			list= sessionFactory.getCurrentSession().createQuery("from User where user_id=:userId").setParameter("userId", userId).list();
		}
		
		catch(Exception e) {
			logger.error("getUserInfo ",e);
		}
		
		return list!=null && !list.isEmpty()?list:null;
	}
	
	
	@Override
	public List<Product> getProductInfo(long pid)
	{
		List<Product> list=null;
		try {
			list= sessionFactory.getCurrentSession().createQuery("from Product where id=:pid").setParameter("pid", pid).list();
		}
		
		catch(Exception e) {
			logger.error("getProductInfo ",e);
		}
		
		return list!=null && !list.isEmpty()?list:null;
	}
	
	
	@Override
	public RewardsPurchaseInfo getRewardPurchaseInfoById(long id)
	{
		List<RewardsPurchaseInfo> list=null;
		try {
						
			list= sessionFactory.getCurrentSession().createQuery("from RewardsPurchaseInfo where id=:id").setParameter("id", id).list();
		             
		}
		
		catch(Exception e) {
			logger.error("getRewardPurchaseInfoById ",e);
		}
		
		return (list!=null && list.size()>0)?list.get(0):null;
	}
	
	
	@Override
	public Order getOrderInfo(String orderno)
	{
		List<Order> list=null;
		try {
			list= sessionFactory.getCurrentSession().createQuery("from Order where orderNo=:orderno").setParameter("orderno", orderno).list();
			}
		
		catch(Exception e) {
			logger.error("getOrderInfo ",e);
		}
		
		return (list!=null && list.size()>0)?(Order)list.get(0):null;
	}


	@Override
	public List<Order> getOrderInfoByUser(long userId,int pagenumber,int pagerecord)
	{
		List<Order> list=null;
		Query q=null;
		try {
			q= sessionFactory.getCurrentSession().createQuery("from Order where purchaseStatus=1 and user.user_id=:userId order by id desc").setParameter("userId", userId);
		             
			if(pagenumber>0 && pagerecord>0) 
			{
				q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
			}
			list=q.list();
		}
		
		catch(Exception e) {
			logger.error("getOrderInfoByUser ",e);
		}
		
		return (list!=null && list.size()>0)?list:null;
	}
	
	
	@Override
	public List<Order> getOrderInfoList(int pagenumber,int pagerecord)
	{
		List<Order> list=null;
		Query q=null;
		try {
			q= sessionFactory.getCurrentSession().createQuery("from Order where purchaseStatus=1 order by id desc");
		             
			if(pagenumber>0 && pagerecord>0) 
			{
				q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
			}
			list=q.list();
		}
		
		catch(Exception e) {
			logger.error("getOrderInfoList ",e);
		}
		
		return (list!=null && !list.isEmpty())?list:null;
	}
	
	
	@Override
	public long getOrderInfoListCount()
	{
		long count=0;

		try {
			count= sessionFactory.getCurrentSession().createQuery("from Order where purchaseStatus=1").list().size();
		}
		
		catch(Exception e) {
			logger.error("getOrderInfoListCount ",e);
		}
		
		return count;
	}
	
	
	
	@Override
	public Order getOrderInfoById(long userId,String orderNumber,long orderId)
	{
		List<Order> list=null;
		try {
			if(orderNumber!=null)
			{
				System.out.println("ON "+orderNumber);
		        list= sessionFactory.getCurrentSession().createQuery("from Order where purchaseStatus=1 and orderNo=:orderNumber order by createdOn desc").setParameter("orderNumber",orderNumber).list();
			}
			
			else
			{
				list= sessionFactory.getCurrentSession().createQuery("from Order where purchaseStatus=1 and user.user_id=:userId and orderId=:orderId").setParameter("orderId",orderId).setParameter("userId", userId).list();
				
			}
		
		}
		
		catch(Exception e) {
			logger.error("getOrderInfoById ",e);
		}
		
		return (list!=null && list.size()>0)?list.get(0):null;
	}
	
	
	
	@Override
	public Order getOrderInfoByBasket(long bid)
	{
		List<Order> list=null;
		try {
						
			list= sessionFactory.getCurrentSession().createQuery("select orderBasket from Order IN ( from OrderBasket where basket.id=:bid)").setParameter("bid", bid).list();
		    		}
		
		catch(Exception e) {
			logger.error("getOrderInfoByBasket ",e);
		}
		
		return (list!=null && list.size()>0)?list.get(0):null;
	}


	
	@Override
	public List<Order> getOrderDetailsByUser(long userId,int pagenumber,int pagerecord)
	{
		List<Order> list=null;
		Query q=null;
		try {
			q= sessionFactory.getCurrentSession().createQuery("from Order where purchaseStatus=1 and user.user_id=:userId").setParameter("userId", userId);
		             
			if(pagenumber>0 && pagerecord>0) 
			{
				q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
			}
			list=q.list();
		}
		
		catch(Exception e) {
			logger.error("getOrderDetailsByUser ",e);
		}
		
		return (list!=null && list.size()>0)?list:null;
	}

	
	@Override
	public List<OrderBasket> getOrderBasketInfoByUser(long userId,int pagenumber,int pagerecord)
	{
		List<OrderBasket> list=null;
		Query q=null;
		try {
			q= sessionFactory.getCurrentSession().createQuery("select basket.product from OrderBasket where active=0 and purchase=1 and user.user_id=:userId").setParameter("userId", userId);
		             
			if(pagenumber>0 && pagerecord>0) 
			{
				q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
			}
			list=q.list();
		}
		
		catch(Exception e) {
			logger.error("getOrderBasketInfoByUser ",e);
		}
		
		return (list!=null && list.size()>0)?list:null;
	}

	@Override
	public List<Order>  getOrderInfoByUserId(List<User> userId)
	{
		List<Order> list=null;
		try
		{
			list=sessionFactory.getCurrentSession().createQuery("from Order where user.user_id in( select user_id from User)").list();
		}
		

		catch(Exception e) {
			logger.error("getOrderInfoByUserId ",e);
		}
		return (list!=null && list.size()>0)?list:null;
	}
	
	
	@Override
	public long getorderCount(long userId,boolean purchase)
	{
		long count=0;
		try
		{
			count=sessionFactory.getCurrentSession().createQuery(" from Order where purchaseStatus=:purchase and user.id=:userId")
					.setParameter("purchase", purchase)
					.setParameter("userId", userId).list().size();
		}

		catch(Exception e) {
			logger.error("getorderCount ",e);
		}
		return count;

	}



	@Override
	public Order getOrderByOrderNo(String orderNo) {
      List<Order> list=null;
      try
      {
    	  list=getSession().createQuery("from Order where orderNo=:orderNo and basketStatus.id=4").setParameter("orderNo", orderNo).list();
      }
      catch(Exception e) {
			logger.error("getOrderByOrderNo ",e);
		}
		return list!=null && !list.isEmpty()?list.get(0):null;
	}




}
