package pharmabox.views;


import java.util.HashMap;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Immutable;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
@Table(name="view_kiosk")
@Immutable
public class KioskView  {

	@Id
	@JsonIgnore
	private long pkey;
	
	private long id;


	private long kioskId;	
	

	private boolean active;	


	private String kioskName;

	private double latitude;

	private double longitude;
	
	private long pid;
	
	@Transient
	private HashMap<String,Double> coordinate;
	
	

	public HashMap<String, Double> getCoordinate() {
		return coordinate;
	}



	public void setCoordinate(HashMap<String, Double> coordinate) {
		this.coordinate = coordinate;
	}


	private String address=" ";
	


	public long getPid() {
		return pid;
	}



	public void setPid(long pid) {
		this.pid = pid;
	}





	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}




	public long getId() {
		return id;
	}



	public void setId(long id) {
		this.id = id;
	}


	public long getKioskId() {
		return kioskId;
	}

	public void setKioskId(long kioskId) {
		this.kioskId = kioskId;
	}

	public String getKioskName() {
		return kioskName;
	}

	public void setKioskName(String kioskName) {
		this.kioskName = kioskName;
	}




	public boolean isActive() {
		return active;
	}



	public void setActive(boolean active) {
		this.active = active;
	}


	
	public long getPkey() {
		return pkey;
	}



	public void setPkey(long pkey) {
		this.pkey = pkey;
	}

	
	


	}