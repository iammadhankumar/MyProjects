package pharmabox;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.Barcode128;

import pharmabox.dao.IAddProductKioskServiceDao;
import pharmabox.domain.Kiosk;
import pharmabox.domain.Product;
import pharmabox.domain.ProductKiosk;
import pharmabox.domain.ProductType;
import pharmabox.domain.Rewards;
import pharmabox.repository.KioskRepository;
import pharmabox.service.IAdminService;
import pharmabox.service.IKioskService;
import pharmabox.service.IProductService;
import pharmabox.service.IPromotionService;
import pharmabox.utils.CommonProperties;
import pharmabox.utils.CommonUtils;
import pharmabox.utils.UserByToken;

@Component
@PropertySource("classpath:application.properties")
public class ScheduledTasks {
	
    	private static final Logger logger = LogManager.getLogger(ScheduledTasks.class);

	
	@Autowired
	private IProductService productService;
	
	@Autowired
	private IKioskService kioskService;
	
	@Autowired
	KioskRepository kioskRepo;
	
	
	@Autowired
	private IPromotionService promotionService;

	@Autowired
	private IAddProductKioskServiceDao productKioskService;

	
	@Autowired
	private IAdminService adminService;

	@Autowired
	UserByToken tokenUser;

	CommonUtils commonUtils = CommonUtils.getInstance();

	
	@Scheduled(cron="${cron.product}", zone="${cron.zone}")
	public void getProductResponse() throws ParseException 
	{
		JSONArray jsonArray =new JSONArray();
		try 
		{   
			

			
		    String url1 = "https://data.point24h.com/mobile_webservice/getProducts.php?user=944191bfbc1d87ee4117b800c06fd967&img=1";
	        URL obj = new URL(url1);
	        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
	        con.setRequestMethod("GET");
	        con.setRequestProperty("User-Agent", "Mozilla/5.0");
	         con.setRequestProperty("Accept-Charset", "ISO-8859-1");
	        int responseCode = con.getResponseCode();
	        System.out.println("\nSending 'GET' request to URL : " + url1);
	        System.out.println("Response Code : " + responseCode);
	 
	        BufferedReader in = new BufferedReader(
	                new InputStreamReader(con.getInputStream()));
	        String inputLine;
	        StringBuffer response = new StringBuffer();
	 
	        while ((inputLine = in.readLine()) != null) {
	            response.append(inputLine);
	        }
	        in.close();
	        System.out.println("RESPONSE "+response.toString());
	        jsonArray = kioskExternal(response.toString());
		} catch (MalformedURLException e) {
           logger.error("getProductResponse ",e);
    } catch (IOException e) {
			logger.error("getProductResponse ",e);		
			}

		
	}

	
	
	 
	@SuppressWarnings({ "unchecked", "unused" })
	private JSONArray kioskExternal(String value)
	{
		String productBaseUrl="http://products.point24h.com/";
		JSONArray  jsonArray=new JSONArray();
		try
		{
			long kiosk=0;
			int z=0;
			long kioskid=0;
			long pi = 0;
			ProductKiosk pk = new ProductKiosk();
			JSONObject obj=(JSONObject) new JSONParser().parse(value);
			JSONArray array=(JSONArray) obj.get("machines");
			JSONObject json33 = (JSONObject) array.get(0);
			System.out.println("JSON33 "+json33);
			JSONArray array33 = (JSONArray) json33.get("products");
			System.out.println("array33 "+array33);
			JSONObject json44 = (JSONObject) array33.get(0);
			System.out.println(json44);
			System.out.println(json44.get("categories"));
			System.out.println("ARRAY SIZE "+array.size());
      for(int x=0;x<array.size();x++)
			{
			JSONObject json3 = (JSONObject) array.get(x);	
			long mId = (long)json3.get("id");
			String mName = (String)json3.get("name");	
		//	System.out.println("KO "+kioskObj+" "+mId);
				
				
					Kiosk kioskObj = new Kiosk();
					kioskObj.setKioskId(mId);
					kioskObj.setKioskName(!mName.isEmpty()?mName.trim():String.valueOf(mId));
					kioskObj.setActive(true);
					kioskObj.setCreated_on(new Date());
					Kiosk kioskObj1 = kioskService.getKioskId(mId);

					if(kioskObj1==null)
					{
					 kioskid = 	kioskService.registerKioskDetails(kioskObj);
					 kioskObj1 = kioskService.getKioskById(kioskid);
					 pk.setKiosk(kioskObj1);
					 }
					else
					{
						kioskObj1.setKioskId(mId);
						kioskObj1.setActive(true);
						kioskObj1.setKioskName(!mName.isEmpty()?mName.trim():String.valueOf(mId));
						 pk.setKiosk(kioskObj1);
						kioskService.updateKiosk(kioskObj1);
					}
					System.out.println("KIOSKUID "+kioskid);
					json3.put("name", mName);
					json3.put("id",mId);
					jsonArray.add(json3);	
				
				
				JSONObject array1=(JSONObject) array.get(x);
				JSONArray array2=(JSONArray) array1.get("products");
               if(array2!=null && !array2.isEmpty())
               {
				for(int y=0;y<array2.size();y++)
				{
					JSONObject json2 = (JSONObject) array2.get(y);	
					if(json2 != null)
					{
						JSONObject json=new JSONObject();
							String id = (String)json2.get("id")!=null ? String.valueOf(json2.get("id")):null;
							String name = (String)json2.get("name")!=null ? json2.get("name").toString():null;	
							float price = json2.get("price") != null ? Float.parseFloat(json2.get("price").toString()):0;	
							long qt = json2.get("qt") != null ?Long.parseLong(json2.get("qt").toString()):0;
							String img=json2.get("img") !=null ? json2.get("img").toString():null;
							
								Product productObj=new Product();
								productObj.setProductId(id.trim());
								productObj.setProductName(name.trim());
								productObj.setPrice(price);
								productObj.setProductDescription(" ");
								productObj.setProductImage(productBaseUrl+img);

							

								if( !(json2.get("categories") instanceof JSONArray) && json2.get("categories")!=null)
								{
									
									JSONObject json4=(JSONObject) json2.get("categories");
									String cat=json4!=null?json4.get("cat_1").toString():null;
									String cname=(String) cat!=null? cat.toString():null;
									String s1=cname!=null?cname.replace("&amp;","&"):null;
									Product productObj1=productService.getProductId(id);
									if(s1!=null && !s1.isEmpty())
									{
									ProductType pt=new ProductType();
									pt=productService.getProductTypeIdByProductTypeName(s1);	
									productObj.setProductType(pt);
									if(productObj1==null)
									{
									pi=productService.addNewProduct(productObj);
									productObj = productService.getById(pi);
									pk.setQuantity(qt);
									pk.setProduct(productObj);
									}
									else
									{
										productObj1.setPrice(price);
										productObj1.setProductDescription(" ");
										productObj1.setProductName(name.trim());
										System.out.println("DFJGHFHG "+productBaseUrl+img);
										productObj1.setProductImage(productBaseUrl+img);
										pk.setProduct(productObj1);
										productService.updateProduct(productObj1);
									}
									}
								}
							
							
//							else
//							{
//								productObj.setPrice(price);
//								productObj.setProductDescription(" ");
//								productObj.setProductName(name);
//								productObj.setProductImage(productBaseUrl+img);
//								productService.updateProduct(productObj);
//							}
					
							json.put("name", name);
							json.put("id",id);
							json.put("price", price);
							json.put("qt",qt);

							jsonArray.add(json);
							ProductKiosk prk =pk.getKiosk()!=null && pk.getProduct()!=null?productKioskService.getProductKioskByProductandKioskId(pk.getKiosk().getId(), pk.getProduct().getId()):null;
							if(prk == null && pk.getKiosk()!=null && pk.getProduct()!=null)
							{
								productKioskService.registerNewProductKiosk(pk);
							}
							else
							{
								prk=productKioskService.getProductKioskByProductandKioskId(pk.getKiosk().getId(), pk.getProduct().getId());
								prk.setQuantity(qt);
								productKioskService.updateProductKiosk(prk);
							}

						}

					}
//				
//				else
//				{
//					System.out.println("INNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN");
//					kioskObj.setKioskId(mId);
//					kioskObj.setKioskName(!mName.isEmpty()&&mName!=null?mName.trim():String.valueOf(mId));
//					kioskObj.setActive(true);
//					kioskObj.setCreated_on(new Date());
//			     	kioskService.updateKiosk(kioskObj);
//					
//				}
//			
			}}}
		catch(Exception e)
		{
			logger.error("kioskExternal ",e);		
		}
		return jsonArray;
	}
	
	
	
	
	@Scheduled(cron="${cron.category}", zone="${cron.zone}")
	public void getCategoryResponse() throws ParseException, IOException {
         JSONArray jsonArray=new JSONArray();
	     String user="944191bfbc1d87ee4117b800c06fd967";
	     String value="";

		try {   
			URL url = new URL("http://dati.erentcinema.it/mobile_webservice/getProducts.php?user="+user+"&cat=1");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "+ conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			String output;
			while ((output = br.readLine()) != null) {
				value= output;
			}
			conn.disconnect();
		} catch (MalformedURLException e) {
      logger.error("getCategoryResponse ",e);	
      } catch (IOException e) {
          logger.error("getCategoryResponse ",e);	
		}
		JSONObject obj=(JSONObject) new JSONParser().parse(value);
		JSONArray array=(JSONArray) obj.get("categories");
		Iterator<?> k = array.iterator();
		while(k.hasNext())
		{
			JSONObject json3 = (JSONObject) k.next();
			String cName = (String)json3.get("name");	
			String pic=(String)json3.get("pic");
			cName=cName!=null && !cName.isEmpty()?cName.replace("&amp;","&"):null;
			
			String pathValue = CommonProperties.getBaseURL()+CommonProperties.getImagePath()+CommonProperties.getCategoryImagePath();
			System.out.println("PATH VALUE "+pathValue);
			System.out.println(pathValue+cName+".png");

			String path1=CommonProperties.getBasePath();
			String path2=commonUtils.createExportDirectory(path1, CommonProperties.getImagePath());
			String path3=commonUtils.createExportDirectory(path2, CommonProperties.getCategoryImagePath());
			String path=path3;
			try (FileOutputStream imageOutFile = new FileOutputStream(path3+cName+".png")) {
				System.out.println("INNN TRYYYY");
			      byte[] imageByteArray = Base64.getDecoder().decode(pic);
			      imageOutFile.write(imageByteArray);
			    } catch (FileNotFoundException e) {
			      System.out.println("Image not found" + e);
			    } catch (IOException ioe) {
			      System.out.println("Exception while reading the Image " + ioe);
			    }
			ProductType PTObj = array!=null? productService.getProductTypeName(cName):null;
			  System.out.println(""+PTObj);
			if(PTObj == null) 
			{
				PTObj=new ProductType();
				PTObj.setProductTypeName(cName);
				PTObj.setProductTypeImage(pathValue+cName+".png");
				productService.addNewProductType(PTObj);
			}
			else
			{
				PTObj.setProductTypeName(cName);
				PTObj.setProductTypeImage(pathValue+cName+".png");
				productService.updateProductType(PTObj);
			}
		}
	}
	

	@Scheduled(cron="${cron.reward}", zone="${cron.zone}")
	public void getPromotionResponse() throws ParseException 
	{

		JSONObject  jsonObject=new JSONObject();
		String value=null;

		String user="944191bfbc1d87ee4117b800c06fd967";
		try {   
			URL url = new URL("https://data.point24h.com/mobile_webservice/getAvailablePromo.php?user="+user);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "+ conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			String output;
			while ((output = br.readLine()) != null) {
				value= output;
			}
			conn.disconnect();
			jsonObject =getPromo(value);
		} catch (MalformedURLException e) {
			logger.error("getPromotionResponse ",e);		
		} catch (IOException e) {
			logger.error("getPromotionResponse ",e);		
		}
	
	}


	private JSONObject getPromo(String value) 
	{
		Rewards reward=null;
		try
		{
			System.out.println("JSON "+value);
			JSONArray obj=(JSONArray) new JSONParser().parse(value);
			JSONArray jo = (JSONArray) obj; 

			for(int i=0;i<jo.size();i++)
			{
				JSONObject jsonObject = (JSONObject) jo.get(i);
				String code=(String) jsonObject.get("code").toString()!=null && !jsonObject.get("code").toString().isEmpty()?jsonObject.get("code").toString():null;
				String name=(String) jsonObject.get("name").toString()!=null && !jsonObject.get("name").toString().isEmpty()?jsonObject.get("name").toString():null;
				String startDate=(String) jsonObject.get("start_date").toString()!=null &&  !jsonObject.get("start_date").toString().isEmpty() ? jsonObject.get("start_date").toString():null;
				String endDate=(String) jsonObject.get("end_date").toString()!=null && !jsonObject.get("end_date").toString().isEmpty() ? jsonObject.get("end_date").toString():null;
				String productCode=(String) jsonObject.get("product_code").toString()!=null && !jsonObject.get("product_code").toString().isEmpty() ?jsonObject.get("product_code").toString():null;
				String productName=(String) jsonObject.get("product_name").toString()!=null && !jsonObject.get("product_name").toString().isEmpty()?jsonObject.get("product_name").toString():null;
				String machine=(String)jsonObject.get("machine")!=null && !jsonObject.get("machine").toString().isEmpty()? jsonObject.get("machine").toString():null;
				double promoValue=jsonObject.get("promo_value")!=null && !jsonObject.get("promo_value").toString().isEmpty()? Double.parseDouble( jsonObject.get("promo_value").toString()):0;
				String promoType=(String) jsonObject.get("promo_type")!=null && !jsonObject.get("promo_type").toString().isEmpty()? jsonObject.get("promo_type").toString():null;

				reward=code!=null?promotionService.getByCodeAndActive(code):null;
				if(reward==null)
				{
					String barcodepath = CommonProperties.getBaseURL()
							+ CommonProperties.getImagePath() + CommonProperties.getBarcode();
					String path1=CommonProperties.getBasePath();
					String path2=commonUtils.createExportDirectory(path1, CommonProperties.getImagePath());
					String path3=commonUtils.createExportDirectory(path2, CommonProperties.getBarcode());
					
					JSONObject json = generateBarcode(code);
					System.out.println(barcodepath);
					reward=new Rewards();
					reward.setPromoCode(code);
					reward.setActive(true);
					reward.setCreatedOn(new Date());
					reward.setRewardsName(name);
					reward.setPromoValue(promoValue);
					reward.setPromoType(promoType);
					reward.setStartDate(startDate);
					if(endDate!=null)
					{
					reward.setExpiry(endDate);
					SimpleDateFormat sdf= new SimpleDateFormat("dd-MM-yyy");
					//DateTimeFormatter.ofPattern("MM-dd-yyyy", Locale.ENGLISH).format(ldt)
					Date date=sdf.parse(endDate);
					reward.setExpiryOn(date);
					}
					reward.setProductName(productName);
					reward.setProductCode(productCode);
					reward.setMachine(machine);
					String path = json.get("path").toString();
					reward.setBarcode(path);
					reward.setBarcode(barcodepath+reward.getBarcode());
					promotionService.registerNewPromotion(reward);
//					System.out.println("PROMOTION "+prom);
				
				}
				else
				{
					reward.setPromoCode(code);
					reward.setCreatedOn(new Date());
					reward.setRewardsName(name);
					reward.setStartDate(startDate);
					reward.setPromoValue(promoValue);
					reward.setPromoType(promoType);
					if(endDate!=null)
					{
					reward.setExpiry(endDate);
					SimpleDateFormat sdf= new SimpleDateFormat("dd-MM-yyyy");
					//DateTimeFormatter.ofPattern("MM-dd-yyyy", Locale.ENGLISH).format(ldt)
					Date date=sdf.parse(endDate);
					reward.setExpiryOn(date);
					}
					reward.setProductName(productName);
					reward.setProductCode(productCode);
					reward.setMachine(machine);
					promotionService.updateReward(reward);
				}




			}
		}
		catch(Exception e)
		{
			logger.error("getPromo ",e);		
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	private JSONObject generateBarcode(String couponCode) throws DocumentException {
		JSONObject json = new JSONObject();
		String path = CommonProperties.getBasePath() + CommonProperties.getImagePath() + CommonProperties.getBarcode();
		try {
			Barcode128 code128 = new Barcode128();
			code128.setCode(couponCode);
			java.awt.Image rawImage = code128.createAwtImage(Color.BLACK, Color.WHITE);
			BufferedImage resizedImage = new BufferedImage(500, 120, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = resizedImage.createGraphics();
			g.drawImage(rawImage, 0, 0, 500, 120, null);
			ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
			ImageIO.write(resizedImage, "png", bytesOut);
			g.dispose();

			byte[] pngImageData = bytesOut.toByteArray();
			try(FileOutputStream fos = new FileOutputStream(path + "/" + couponCode + ".png"))
			{
			fos.write(pngImageData);
			fos.close();
			json.put("values", couponCode);
			json.put("path", couponCode + ".png");
			return json;
			}
		} catch (Exception e) {
			logger.error("generateBarcode ",e);		
			}
		return json;
	}

	
	
	@Scheduled(cron="${cron.expireReward}", zone="${cron.zone}")
	@SuppressWarnings("unused")
	public void deactivExpiredRewards() throws ParseException 
	{
		long rewardCount=0;
		List<Rewards> expiredRewardsList=null;
		rewardCount=adminService.getOverAllRewardsListCount();
		 if(rewardCount>0)
		 {
		     adminService.updateExpiredRewards();
		 }
	}
	
	
	
	
	
	
	
	
	
	
	
	



}
