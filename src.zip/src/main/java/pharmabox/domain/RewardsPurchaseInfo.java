package pharmabox.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_rewads_purchase")
public class RewardsPurchaseInfo {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private long id;
	
	@Column(name="DN_ACTIVE")
	private boolean active;
	
	@Column(name="DN_ACTUAL_PRICE")
	private float actualPrice;
	
	@Column(name="DN_DISCOUNTED_PRICE")
	private float discountedPrice;
	
	@Column(name="DN_REWARDS_PRICE")
	private float rewardsPrice;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public float getActualPrice() {
		return actualPrice;
	}

	public void setActualPrice(float actualPrice) {
		this.actualPrice = actualPrice;
	}

	public float getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(float discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public float getRewardsPrice() {
		return rewardsPrice;
	}

	public void setRewardsPrice(float rewardsPrice) {
		this.rewardsPrice = rewardsPrice;
	}

}
