package pharmabox.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

import com.fasterxml.jackson.annotation.JsonIgnore;




@Entity
@Table(name="tbl_product")
public class Product implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private long id;
	
	@Column(name="PRODUCT_ID")
	private String productId;
	
	
	@Column(name="PRODUCT_NAME")
	private String productName;
	

	@Column(name="PRICE")
	private float price;
	
	@JsonIgnore
	@Column(name="QUANTITY")
	private long quantity;
	
	@JsonIgnore
	@Column(name="WEIGHT",columnDefinition = "0")
	private long weight;
	
	 
    public long getWeight() {
		return weight;
	}

	public void setWeight(long weight) {
		this.weight = weight;
	}

	@OneToOne(targetEntity =ProductType.class,fetch=FetchType.EAGER)
	@JoinColumn(name="DN_PRODUCT_TYPE")
	private ProductType productType;
    
    
	 
//    @OneToOne(targetEntity =Kiosk.class,fetch=FetchType.EAGER)
//	@JoinColumn(name="DN_KIOSK")
//	private Kiosk kiosk;
//    
//
//	public Kiosk getKiosk() {
//		return kiosk;
//	}
//
//	public void setKiosk(Kiosk kiosk) {
//		this.kiosk = kiosk;
//	}

	public ProductType getProductType() {
		return productType;
	}

	public void setProductType(ProductType productType) {
		this.productType = productType;
	}

	@Column(name="PRODUCT_IMAGE")
	@ColumnDefault(" ")
	private String productImage=" ";

   @Column(name="PRODUCT_FAVOURITE" ,columnDefinition = "boolean default false")
	private boolean productFavourite;
   

	@Column(name="PRODUCT_DESCRIPTION",columnDefinition="text")
	@ColumnDefault(" ")
	private String productDescription=" ";
	
	
	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	
	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	
	
	public boolean isProductFavourite() {
		return productFavourite;
	}

	public void setProductFavourite(boolean productFavourite) {
		this.productFavourite = productFavourite;
	}
	
	

}