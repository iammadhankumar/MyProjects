package pharmabox.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="tbl_order")
public class Order implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private long id;

	@Column(name="DN_ORDERNO" )
	private String orderNo;

	@OneToOne ( targetEntity = BasketStatus.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_BASKET_STATUS")
	private BasketStatus basketStatus;
	
	@Column(name="DN_PURCHASESTATUS")
	private boolean purchaseStatus;

	

	@OneToMany(targetEntity = OrderBasket.class,cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	@JoinColumn (name = "DN_ORDER_ID")
	private List<OrderBasket> orderBasket;

	public List<OrderBasket> getOrderBasket()
    {
		return orderBasket;
	}
   
	

	public void setOrderBasket(List<OrderBasket> orderBasket) {
		this.orderBasket = orderBasket;
	}


	@OneToOne(targetEntity = User.class, fetch = FetchType.EAGER )
	@JoinColumn(name = "DN_USER")
    private User user;
	
	@Column(name="DN_ORDER_BARCODE")
     private String barcode;
	
	@OneToOne(targetEntity = Rewards.class, fetch = FetchType.EAGER )
	@JoinColumn(name = "DN_REWARDS")
    private Rewards reward;
	
	@Column(name="DN_CREATEDON")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
	private Date createdOn;
	
	@OneToOne ( targetEntity = RewardsPurchaseInfo.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_REWARD_PURCHASE")
	private RewardsPurchaseInfo rewardsPurchase;
	
	@Column(name="DN_PRICE")
	private float price;

	
	@Column(name="DN_TRANSACTION_ID")
	private String transactionId;

	public String getTransactionId() {
		return transactionId;
	}



	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}



	public float getPrice() {
		return price;
	}


	public void setPrice(float price) {
		this.price = price;
	}


	public Rewards getReward() {
		return reward;
	}


	public void setReward(Rewards reward) {
		this.reward = reward;
	}


	public Date getCreatedOn() {
		return createdOn;
	}


	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}


	public String getBarcode() {
		return barcode;
	}


	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getOrderNo() {
		return orderNo;
	}


	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}


	


	public BasketStatus getBasketStatus() {
		return basketStatus;
	}


	public void setBasketStatus(BasketStatus basketStatus) {
		this.basketStatus = basketStatus;
	}
	
	
	 public boolean isPurchaseStatus() {
			return purchaseStatus;
		}


		public void setPurchaseStatus(boolean purchaseStatus) {
			this.purchaseStatus = purchaseStatus;
		}




	

	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}
	
	public RewardsPurchaseInfo getRewardsPurchase() {
		return rewardsPurchase;
	}


	public void setRewardsPurchase(RewardsPurchaseInfo rewardsPurchase) {
		this.rewardsPurchase = rewardsPurchase;
	}

	
	
}
