package pharmabox.domain;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.ws.rs.ext.ParamConverter.Lazy;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="tbl_basket")
@Lazy
public class Basket {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="BID" , nullable = false )
	private long bid;
	
	@Column(name="DN_QUANTITY")
	private long quantity;

//	@JsonIgnore
//  @OneToOne ( targetEntity = Kiosk.class, fetch = FetchType.EAGER )
//  @JoinColumn (name = "DN_KIOSK")
//   private Kiosk kiosk;
	
//	@Column(name="DN_PRICE")
//	private long price;
// 
//	public long getPrice() {
//		return price;
//	}
//
//	public void setPrice(long price) {
//		this.price = price;
//	}

	

	
//	
//
//	@OneToOne ( targetEntity = Product.class, fetch = FetchType.EAGER )
//    @JoinColumn (name = "DN_PRODUCT")
//    private Product product;
	

	

	
//	public Kiosk getKiosk() {
//		return kiosk;
//	}
//
//	public void setKiosk(Kiosk kiosk) {
//		this.kiosk = kiosk;
//	}
	
	@Column(name="DB_SHIPPING_AMOUNT" )
	private float shippingamount;
	
	public float getShippingamount() {
		return shippingamount;
	}

	public void setShippingamount(float shippingamount) {
		this.shippingamount = shippingamount;
	}

	@OneToOne ( targetEntity = ProductKiosk.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_PRODUCTKIOSK")
	private ProductKiosk productKiosk;


	public ProductKiosk getProductKiosk() {
		return productKiosk;
	}

	public void setProductKiosk(ProductKiosk productKiosk) {
		this.productKiosk = productKiosk;
	}

	@OneToOne ( targetEntity = User.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_USER")
	private User user;
	
	@Column(name="DD_CREATED_ON")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date createdOn;

	@Column(name="DB_ACTIVE")
    private boolean active;

	@Column(name="DB_ACTIONS")
	private boolean actions;
	
	@JsonIgnore
	@OneToOne ( targetEntity = BasketStatus.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_BASKET_STATUS")
	private BasketStatus basketStatus;
	
	

   	
	@Column(name="DB_PURCHASE",columnDefinition = "BOOLEAN DEFAULT false")
	private boolean purchase;
	
	@Transient
	private boolean instock;
	
	@OneToOne ( targetEntity = Rewards.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_REWARD")
	private Rewards reward;
	
	@Column(name="DB_REWARDS_USED",columnDefinition = "BOOLEAN DEFAULT false")
	private boolean rewardsUsed;
	
	@Column(name="DB_ACTUAL_PRICE")
	private float actualPrice;
	

	@Column(name="DB_DISCOUNTED_PRICE")
	private float discountedPrice;
	
	@Column(name="DB_REWARDS_PRICE")
	private float rewardsPrice;

	
	public float getActualPrice() {
		return actualPrice;
	}

	public void setActualPrice(float actualPrice) {
		this.actualPrice = actualPrice;
	}	

	public float getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(float discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public float getRewardsPrice() {
		return rewardsPrice;
	}

	public void setRewardsPrice(float rewardsPrice) {
		this.rewardsPrice = rewardsPrice;
	}

	public boolean isRewardsUsed() {
		return rewardsUsed;
	}

	public void setRewardsUsed(boolean rewardsUsed) {
		this.rewardsUsed = rewardsUsed;
	}

	public Rewards getReward() {
		return reward;
	}

	public void setReward(Rewards reward) {
		this.reward = reward;
	}
	
	


	
	/*
	 * @Column(name="DN_SHIPPING_AMOUNT") private double shipping;
	 * 
	 * 
	 * public double getShipping() { return shipping; }
	 * 
	 * public void setShipping(double shipping) { this.shipping = shipping; }
	 */

	public boolean isInstock() {
		return instock;
	}

	public void setInstock(boolean instock) {
		this.instock = instock;
	}
	
	@Column(name="DN_PRICE")
	private float price;

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}


	public boolean isPurchase() {
		return purchase;
	}

	public BasketStatus getBasketStatus() {
		return basketStatus;
	}

	public void setBasketStatus(BasketStatus basketStatus) {
		this.basketStatus = basketStatus;
	}

	public void setPurchase(boolean purchase) {
		this.purchase = purchase;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isActions() {
		return actions;
	}

	public void setActions(boolean actions) {
		this.actions = actions;
	}
	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public long getBid() {
		return bid;
	}

	public void setBid(long bid) {
		this.bid = bid;
	}
//
	


	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	

	
	
//
//	public Product getProduct() {
//		return product;
//	}
//
//	public void setProduct(Product product) {
//		this.product = product;
//	}

	


    
	
}
