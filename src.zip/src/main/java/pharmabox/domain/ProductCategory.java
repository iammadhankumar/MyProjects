package pharmabox.domain;

public class ProductCategory {
	
	

}
