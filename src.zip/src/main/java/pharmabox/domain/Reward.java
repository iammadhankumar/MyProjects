package pharmabox.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_reward")
public class Reward implements Serializable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private Long id;


	@Column(name="DN_ACTIVE" )
	private boolean active;	
	
	@Column(name="DN_CODE" )
	private String code;
	
	@Column(name="DN_NAME" )
	private String name;

	@Column(name="DN_START_DATE" )
	private String startDate;
	
	@Column(name="DN_END_DATE" )
	private String endDate;
	
	
	@Column(name="DN_PRODUCT_CODE" )
	private String productCode;
	
	
	@Column(name="DN_PRODUCT_NAME" )
	private String productName;
	
	
	@Column(name="DN_MACHINE" )
	private String machine;





	public Long getId() {
		return id;
	}
	
	
	public void setId(Long id) {
		this.id = id;
	}


	public boolean isActive() {
		return active;
	}


	public void setActive(boolean active) {
		this.active = active;
	}


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getStartDate() {
		return startDate;
	}


	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}


	public String getEndDate() {
		return endDate;
	}


	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}


	public String getProductCode() {
		return productCode;
	}


	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public String getMachine() {
		return machine;
	}
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}



	public void setMachine(String machine) {
		this.machine = machine;
	}

}
