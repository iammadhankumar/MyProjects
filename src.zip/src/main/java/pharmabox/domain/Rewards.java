package pharmabox.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="tbl_rewards")
public class Rewards {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private long id;
	
	@Column(name="DN_ACTIVE")
	private boolean active;
	
	@Column(name="DN_REWARDSNAME")
    private String rewardsName;
	
	@Column(name="DN_PARCENTAGE")
	private double percentage;
	
	@Column(name="DN_REWARD_IMAGE")
	private String rewardImage;
	
	@Column(name="DN_PROMOCODE")
	private String promoCode;
	
	@Column(name="DN_REWARDS_BARCODE")
	private String barcode;
	
	@Column(name="DD_CREATED_ON")
	@JsonFormat(pattern="dd-MM-yyyy HH:mm:ss")
	private Date createdOn;
	
	@Column(name="DN_START_DATE")
	private String startDate;
	
	@JsonIgnore
	@Column(name="DN_EXPIRED_ON")
	private String expiry;
	
	@Column(name="DN_EXPIRY_ON")
	@JsonFormat(pattern="dd-MM-yyyy")
	private Date expiryOn;
	
	@Column(name="DN_PRODUCT_CODE")
	private String productCode;
	
	@Column(name="DN_PRODUCT_NAME")
	private String productName;
	
	@Column(name="DN_PROMO_VALUE")
	private double promoValue;
	
	@Column(name="DN_PROMO_TYPE")
	private String promoType;
	
	public String getPromoType() {
		return promoType;
	}

	public void setPromoType(String promoType) {
		this.promoType = promoType;
	}

	public double getPromoValue() {
		return promoValue;
	}

	public void setPromoValue(double promoValue) {
		this.promoValue = promoValue;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	@Column(name="DN_MACHINE")
	private String machine;
	
	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getMachine() {
		return machine;
	}

	public void setMachine(String machine) {
		this.machine = machine;
	}


	
	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	
	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public String getRewardImage() {
		return rewardImage;
	}

	public void setRewardImage(String rewardImage) {
		this.rewardImage = rewardImage;
	}

	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}


	public String getExpiry() {
		return expiry;
	}

	public void setExpiry(String expiry) {
		this.expiry = expiry;
	}

	public Date getExpiryOn() {
		return expiryOn;
	}

	public void setExpiryOn(Date expiryOn) {
		this.expiryOn = expiryOn;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getRewardsName() {
		return rewardsName;
	}

	public void setRewardsName(String rewardsName) {
		this.rewardsName = rewardsName;
	}


	

}
