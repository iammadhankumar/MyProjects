//package pharmabox.domain;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//@Entity
//@Table(name="tbl_dietary_preference")
//public class DietaryPreference {
//
//	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
//	@Column(name="DN_ID" , nullable = false )
//	private long dietaryId;
//
//	@Column(name="DC_DIETARY_NAME")
//	private String dietaryName;
//	
//	@Column(name="DB_ACTIVE")
//	private boolean active;
//
//	public long getDietaryId() {
//		return dietaryId;
//	}
//
//	public void setDietaryId(long dietaryId) {
//		this.dietaryId = dietaryId;
//	}
//
//	public String getDietaryName() {
//		return dietaryName;
//	}
//
//	public void setDietaryName(String dietaryName) {
//		this.dietaryName = dietaryName;
//	}
//
//	public boolean isActive() {
//		return active;
//	}
//
//	public void setActive(boolean active) {
//		this.active = active;
//	}
//
//	public DietaryPreference(long dietaryId, String dietaryName, boolean active) {
//		super();
//		this.dietaryId = dietaryId;
//		this.dietaryName = dietaryName;
//		this.active = active;
//	}
//
//	public DietaryPreference() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//}
