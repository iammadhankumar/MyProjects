package pharmabox.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="tbl_basket_status")
public class BasketStatus {
	

@Id
@GeneratedValue(strategy=GenerationType.AUTO)
@Column(name="DN_ID",nullable=false)
private Long basketStatusId;

@Column(name="DC_BASKETSTATUS")
private  String basketStatus;

public Long getBasketStatusId() {
		return basketStatusId;
	}

	public void setBasketStatusId(Long basketStatusId) {
		this.basketStatusId = basketStatusId;
	}

	public String getBasketStatus() {
		return basketStatus;
	}

	public void setBasketStatus(String basketStatus) {
		this.basketStatus = basketStatus;
	}

}
