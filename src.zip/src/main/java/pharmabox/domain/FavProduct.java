package pharmabox.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="tbl_favourite")
public class FavProduct implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private long id;
	
	@OneToOne(targetEntity =User.class,fetch=FetchType.EAGER)
    @JoinColumn(name="DN_USERID")
	private User user;
	
	@OneToOne(targetEntity =Product.class,fetch=FetchType.EAGER)
	@JoinColumn(name="DC_PRODUCTID")
	private Product product;


	@Column(name="DC_ACTIVE")
	private boolean active;

	@Column(name="DD_CREATED_ON")
	@JsonFormat(pattern="MM-dd-yyyy HH:mm:ss")
	private Date createdOn;
	
	@Column(name="DD_UPDATED_ON")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "UTC")
	private Date updatedOn;

	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	

	
	
	
	



}
