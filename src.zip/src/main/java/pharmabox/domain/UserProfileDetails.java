package pharmabox.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name="tbl_user_profile")
public class UserProfileDetails implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name="DN_PROFILE_ID" , nullable = false ,unique=true)
	private String userProfileId;
	
	@Column(name="DC_FIRSTNAME")
	private String firstName;

	@Column(name="DC_LASTNAME")
	private String lastName;
	
	@Column(name="DC_EMAIL")
	private String email;
	
//	@Column(name="DC_PROFESSION")
//	private String profession;
//	
//	@Column(name="DC_PROFILE_IMAGE")
//	private String profileImage;
//	
//	@Column(name="DC_PROFILE_CV")
//	private String profileCv;
//	
//	@Column(name="DC_CV_NAME")
//	private String profileCvName;
//
//	@Column(name="DATE_OF_BIRTH")
//	@JsonFormat(pattern="yyyy-MM-dd")
//	private Date dob;	
//	
//	@Column(name="GENDER")
//	private int gender;
//	
//	@OneToOne ( targetEntity = Address.class, fetch = FetchType.EAGER )
//	@JoinColumn (name = "DN_USER_ADDRESS")
//	private Address address;
//	
//	@OneToOne (targetEntity = Sport.class, fetch = FetchType.EAGER )
//	@JoinColumn (name = "DC_PRIMARY_SPORT")
//	private Sport primarySport;
//	
//	@OneToOne (targetEntity = Sport.class, fetch = FetchType.EAGER )
//	@JoinColumn (name = "DC_SECONDARY_SPORT")
//	private Sport secondarySport;
//	
//	@OneToOne (targetEntity = Sport.class, fetch = FetchType.EAGER )
//	@JoinColumn (name = "DC_THIRD_SPORT")
//	private Sport thirdSport;
//	
//	@OneToMany(targetEntity = WorkHistory.class,cascade = CascadeType.ALL)
//	@LazyCollection(LazyCollectionOption.FALSE)
//	@JoinColumn (name = "DN_USER_PROFILE_ID")
//	private List<WorkHistory> workHistory;
//	
//	@ManyToMany(cascade = CascadeType.ALL)
//	@LazyCollection(LazyCollectionOption.FALSE)
//	@JoinTable(name = "tbl_user_profile_skill", joinColumns = {
//			@JoinColumn(name = "DN_PROFILE_ID") }, inverseJoinColumns = { @JoinColumn(name = "DN_SKILL_ID") })
//	private List<Skill> skills;
//	
//	/*@OneToMany(cascade = CascadeType.ALL)
//	@LazyCollection(LazyCollectionOption.FALSE)
//	//@JoinColumn (name = "DN_USER_PROFILE_ID")
//	@JoinTable(name = "tbl_user_profile_skill", joinColumns = {
//			@JoinColumn(name = "DN_PROFILE_ID")}, inverseJoinColumns = {
//					@JoinColumn(name = "DN_SKILL_ID")})
//	private List<Skill> skills;*/
//	
//	@OneToMany(targetEntity = Qualification.class,cascade = CascadeType.ALL)
//	@LazyCollection(LazyCollectionOption.FALSE)
//	@JoinColumn (name = "DN_USER_PROFILE_ID")
//	private List<Qualification> qualification;
//		
//	@OneToMany(targetEntity = Education.class,cascade = CascadeType.ALL)
//	@LazyCollection(LazyCollectionOption.FALSE)
//	@JoinColumn (name = "DN_USER_PROFILE_ID")
//	private List<Education> education;
//	
//	@ManyToMany(cascade = CascadeType.ALL)
//	@LazyCollection(LazyCollectionOption.FALSE)
//	@JoinTable(name = "tbl_user_profile_interest", joinColumns = {
//			@JoinColumn(name = "DN_PROFILE_ID") }, inverseJoinColumns = { @JoinColumn(name = "DN_INTEREST_ID") })
//	private List<Interests> interests;
//	
//	@ManyToMany(targetEntity = Sport.class,cascade = CascadeType.ALL)
//	@LazyCollection(LazyCollectionOption.FALSE)
//	@JoinTable(name = "tbl_user_sport", joinColumns = {
//			@JoinColumn(name = "DN_PROFILE_ID") }, inverseJoinColumns = { @JoinColumn(name = "DN_SPORT_ID") })
//	private List<Sport> sportsInterest;
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name="DB_ACTIVE")
	private boolean active;
	
	public String getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(String userProfileId) {
		this.userProfileId = userProfileId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

//	public String getProfileDescription() {
//		return profileDescription;
//	}
//
//	public void setProfileDescription(String profileDescription) {
//		this.profileDescription = profileDescription;
//	}
//
//	public Date getDob() {
//		return dob;
//	}
//
//	public void setDob(Date dob) {
//		this.dob = dob;
//	}
//
//	public String getPlaceOfBirth() {
//		return placeOfBirth;
//	}
//
//	public void setPlaceOfBirth(String placeOfBirth) {
//		this.placeOfBirth = placeOfBirth;
//	}
//
//	public int getGender() {
//		return gender;
//	}
//
//	public void setGender(int gender) {
//		this.gender = gender;
//	}
//
//	public String getProfession() {
//		return profession;
//	}
//
//	public void setProfession(String profession) {
//		this.profession = profession;
//	}
//
//	public String getProfileImage() {
//		return profileImage;
//	}
//
//	public void setProfileImage(String profileImage) {
//		this.profileImage = profileImage;
//	}

//	public Address getAddress() {
//		System.out.println("in address");
//		return address;
//	}
//
//	public void setAddress(Address address) {
//		this.address = address;
//	}
//
//	public Sport getPrimarySport() {
//		return primarySport;
//	}
//
//	public void setPrimarySport(Sport primarySport) {
//		this.primarySport = primarySport;
//	}
//
//	public Sport getSecondarySport() {
//		return secondarySport;
//	}
//
//	public void setSecondarySport(Sport secondarySport) {
//		this.secondarySport = secondarySport;
//	}
//
//	public Sport getThirdSport() {
//		return thirdSport;
//	}
//
//	public void setThirdSport(Sport thirdSport) {
//		this.thirdSport = thirdSport;
//	}
//
//	public List<WorkHistory> getWorkHistory() {
//		return workHistory;
//	}
//
//	public void setWorkHistory(List<WorkHistory> workHistory) {
//		this.workHistory = workHistory;
//	}
//
//	public List<Education> getEducation() {
//		return education;
//	}
//
//	public void setEducation(List<Education> education) {
//		this.education = education;
//	}
//
//	public List<Skill> getSkills() {
//		return skills;
//	}
//
//	public void setSkills(List<Skill> skills) {
//		this.skills = skills;
//	}
//
//	public List<Qualification> getQualification() {
//		return qualification;
//	}
//
//	public void setQualification(List<Qualification> qualification) {
//		this.qualification = qualification;
//	}
//
//	public List<Interests> getInterests() {
//		return interests;
//	}
//
//	public void setInterests(List<Interests> interests) {
//		this.interests = interests;
//	}
//
//	public boolean isActive() {
//		return active;
//	}
//
//	public void setActive(boolean active) {
//		this.active = active;
//	}
//
//	public String getProfileCv() {
//		return profileCv;
//	}
//
//	public void setProfileCv(String profileCv) {
//		this.profileCv = profileCv;
//	}
//
//	public List<Sport> getSportsInterest() {
//		return sportsInterest;
//	}
//
//	public void setSportsInterest(List<Sport> sportsInterest) {
//		this.sportsInterest = sportsInterest;
//	}
//
//	public String getProfileCvName() {
//		return profileCvName;
//	}
//
//	public void setProfileCvName(String profileCvName) {
//		this.profileCvName = profileCvName;
//	}
//	
}
