package pharmabox.repository;

import org.springframework.data.repository.CrudRepository;

import pharmabox.domain.RewardsMaintain;

public interface RewardsMaintainRepository extends CrudRepository<RewardsMaintain, Long> {

}
