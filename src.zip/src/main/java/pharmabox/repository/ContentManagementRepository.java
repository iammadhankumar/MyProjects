package pharmabox.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import pharmabox.domain.ContentManagement;

public interface ContentManagementRepository extends CrudRepository<ContentManagement, Long>{

	Optional<ContentManagement> findBycontentId(long contentId);

	ContentManagement getByLabel(String label);







}
