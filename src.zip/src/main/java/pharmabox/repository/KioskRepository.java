package pharmabox.repository;

import org.springframework.data.repository.CrudRepository;

import pharmabox.domain.Kiosk;

public interface KioskRepository extends CrudRepository<Kiosk, Long>{

}
