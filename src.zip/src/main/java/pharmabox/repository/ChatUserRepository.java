//package pharmabox.repository;
//
//import java.util.Date;
//
//import org.springframework.data.repository.CrudRepository;
//
//
//
//public interface ChatUserRepository extends CrudRepository<ChatUser, String>{
//
//	long countByUserType_userTypeId(long userTypeId);
//
//	Long countByActive(boolean active);
//
//	Long countByActiveAndCreatedOnBetween(boolean active, Date fromDate, Date toDate);
//}
