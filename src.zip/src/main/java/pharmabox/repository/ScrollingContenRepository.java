package pharmabox.repository;

import org.springframework.data.repository.CrudRepository;

import pharmabox.domain.ScrollingContent;

public interface ScrollingContenRepository extends CrudRepository<ScrollingContent, Long> {

	ScrollingContent findById(long id);
   
	
	

}
