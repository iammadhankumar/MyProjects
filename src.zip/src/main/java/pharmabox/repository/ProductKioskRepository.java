//package pharmabox.repository;
//
//import org.springframework.data.repository.CrudRepository;
//
//import pharmabox.domain.ProductKiosk;
//
//public interface ProductKioskRepository extends CrudRepository<ProductKiosk, Long> {
//	
//	//SELECT * FROM `tbl_product_kiosk` WHERE `DN_KIOSK_ID`=1 AND `DN_PRODUCT`=7
//
//}
