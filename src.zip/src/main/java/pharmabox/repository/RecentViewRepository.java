package pharmabox.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import pharmabox.domain.RecentViewProducts;

public interface RecentViewRepository extends CrudRepository<RecentViewProducts, Long> {
	//Query="select * from `tbl_recentview_products` where `DD_CREATED_ON` between 'date' and now() and `DN_ACTIVE`=1 and `DN_USER`=:user";
	@Query(value=" from RecentViewProducts where created_on between date and now() and active=1 and user.id=:user")
	 List<RecentViewProducts> getRecentViewRepositoriesList(String date,long user);
	

//	@Query(value="SELECT * FROM `tbl_recentview_products` WHERE `DD_CREATED_ON`>= NOW() - INTERVAL 3 DAY AND`DD_CREATED_ON`<= NOW() AND `DN_USER`=:user AND `DN_ACTIVE`=1 ORDER BY `DN_ID` DESC LIMIT 50",nativeQuery=true)
//	List<RecentViewProducts> getAllRecentViewProductsByUsers(@Param("user") long user,Pageable pageable);
	
//	@Query(value="FROM RecentViewProducts WHERE created_on>= NOW() - INTERVAL 3 DAY AND created_on<= NOW() AND user.user_id=:user AND active=1 ORDER BY id DESC LIMIT 50")
//	List<RecentViewProducts> getAllRecentViewProductsByUsers1(@Param("user") long user,Pageable pageable);
}
