package pharmabox.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import pharmabox.domain.Promotion;

public interface PromotionRepository extends CrudRepository<Promotion,Long>{

	@Query("from Promotion where code=:code and active=1")
	Promotion getByCodeAndActive(@Param("code") String code);

}
