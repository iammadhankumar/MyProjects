package pharmabox.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import pharmabox.domain.Basket;



public interface BasketRepository extends CrudRepository<Basket, Long>{

	@Query(value="SELECT ROUND(SUM(`DN_PRICE`),2) FROM `tbl_basket` WHERE `DB_ACTIVE`=1 AND `DB_PURCHASE`=0 AND `DN_USER`=:userId",nativeQuery=true)
	float sumOfBaskets(@Param("userId") long userId);
	
	

}
