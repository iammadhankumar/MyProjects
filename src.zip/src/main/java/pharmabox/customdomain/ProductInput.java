package pharmabox.customdomain;



public class ProductInput {


	private String productId;
	
	private String productName;
	
	private String productImage;
	
	private String description;
	
	private long quantity;
	
	private long kioskId;
	
	private long productTypeID;

	private boolean productFavourite;

	private float price;
	

	public long getKioskId() {
		return kioskId;
	}

	public void setKioskId(long kioskId) {
		this.kioskId = kioskId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isProductFavourite() 
	{
		return productFavourite;
	}

	public void setProductFavourite(boolean productFavourite) {
		this.productFavourite = productFavourite;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	
	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	
	public long getProductTypeID() {
		return productTypeID;
	}

	public void setProductTypeID(long productTypeID) {
		this.productTypeID = productTypeID;
	}

	
	
}
