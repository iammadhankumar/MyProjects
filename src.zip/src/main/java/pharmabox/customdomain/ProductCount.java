package pharmabox.customdomain;

import java.util.List;

import pharmabox.domain.Product;

public class ProductCount {
	
	private long count;
	
	private  List<Product> ProductList;
  
	private long Basketcount;
	
	public long getBasketcount() {
		return Basketcount;
	}

	public void setBasketcount(long basketcount) {
		Basketcount = basketcount;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	public List<Product> getProductList() {
		return ProductList;
	}

	public void setProductList(List<Product> productList) {
		 this.ProductList = productList;
	}
	
	
}
