package pharmabox.customdomain;

import java.util.List;

import pharmabox.domain.BasketStatus;

public class OrderInput {
	
	private long id;
	
	private String orderNo;
	
	private BasketStatus basketStatus;
	
	private boolean purchaseStatus;

	private long basketStatusId;

	private List<Long> bid;
	
	private String nonceToken;
	
	private float amount;
	
	
	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public String getNonceToken() {
		return nonceToken;
	}

	public void setNonceToken(String nonceToken) {
		this.nonceToken = nonceToken;
	}

	private long user;
	
	private long quantity;

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public BasketStatus getBasketStatus() {
		return basketStatus;
	}

	public void setBasketStatus(BasketStatus basketStatus) {
		this.basketStatus = basketStatus;
	}


	public boolean isPurchaseStatus() {
		return purchaseStatus;
	}

	public void setPurchaseStatus(boolean purchaseStatus) {
		this.purchaseStatus = purchaseStatus;
	}



	public long getUser() {
		return user;
	}

	public void setUser(long user) {
		this.user = user;
	}

	public List<Long> getBid() {
		return bid;
	}

	public void setBid(List<Long> bid) {
		this.bid = bid;
	}
	

	public long getBasketStatusId() {
		return basketStatusId;
	}

	public void setBasketStatusId(long basketStatusId) {
		this.basketStatusId = basketStatusId;
	}


	

}
