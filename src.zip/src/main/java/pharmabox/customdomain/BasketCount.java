package pharmabox.customdomain;

import java.util.List;

import pharmabox.domain.Basket;
 

public class BasketCount {

	
	private long Basketcount;
	
	public long getBasketcount() {
		return Basketcount;
	}



	public void setBasketcount(long basketcount) {
		Basketcount = basketcount;
	}



	private String grandTotal;
	
	private String tax;
	 
	private String total;
	
	
	public String getTax() {
		return tax;
	}



	public void setTax(String tax) {
		this.tax = tax;
	}



	public String getTotal() {
		return total;
	}



	public void setTotal(String total) {
		this.total = total;
	}



	public String getGrandTotal() {
		return grandTotal;
	}



	public void setGrandTotal(String grandTotal) {
		this.grandTotal = grandTotal;
	}



	private  List<Basket> BasketList;



	//private Basket basket;


	/*
	 * public Basket getBasket() { return basket; }
	 * 
	 * 
	 * 
	 * public void setBasket(Basket basket) { this.basket = basket; }
	 * 
	 */

	public List<Basket> getBasketList() {
		return BasketList;
	}



	public void setBasketList(List<Basket> basketList) {
		this.BasketList = basketList;
	}	
	
	
	
	
	
	
}
