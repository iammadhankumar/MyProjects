package pharmabox.customdomain;

import java.util.Date;
import java.util.List;

public class RewardsInput {
	
	private long rewardId;
	
	private long id;
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	private String rewardsName;
	
	private double percentage;
	
	private String rewardImage;
	
	
	private String expiryOn;
	
	private Date date;
	
	private String couponCode;
	
	private long bid;
	
	private long type;
	
	private List<Long> basketId;
	
	

	
	public List<Long> getBasketId() {
		return basketId;
	}

	public void setBasketId(List<Long> basketId) {
		this.basketId = basketId;
	}

	public long getBid() {
		return bid;
	}

	public void setBid(long bid) {
		this.bid = bid;
	}

	public long getRewardId() {
		return rewardId;
	}

	public void setRewardId(long rewardId) {
		this.rewardId = rewardId;
	}

	
	public String getCouponCode() {
		return couponCode;
	}

	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getExpiryOn() {
		return expiryOn;
	}

	public void setExpiryOn(String expiryOn) {
		this.expiryOn = expiryOn;
	}

	public String getRewardImage() {
		return rewardImage;
	}

	public void setRewardImage(String rewardImage) {
		this.rewardImage = rewardImage;
	}

	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	public String getRewardsName() {
		return rewardsName;
	}

	public void setRewardsName(String rewardsName) {
		this.rewardsName = rewardsName;
	}

	
	public long getType() {
		return type;
	}

	public void setType(long type) {
		this.type = type;
	}


	

}
