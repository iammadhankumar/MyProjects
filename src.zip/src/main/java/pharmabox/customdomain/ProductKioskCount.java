package pharmabox.customdomain;

import java.util.List;

import pharmabox.domain.Kiosk;
import pharmabox.domain.ProductKiosk;

public class ProductKioskCount {
	
private  List<Kiosk> kioskList;
private  List<ProductKiosk> productKioskList;
private  long  productQuantity;
	
	public long getProductQuantity() {
	return productQuantity;
}

public void setProductQuantity(long productQuantity) {
	this.productQuantity = productQuantity;
}

	private long count;
	private long Kioskcount;
	private boolean status;

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public long getKioskcount() {
		return Kioskcount;
	}

	public void setKioskcount(long Kioskcount) {
		this.Kioskcount = Kioskcount;
	}

	public List<Kiosk> getKioskList() {
		return kioskList;
	}

	public void setKioskList(List<Kiosk> kioskList) {
		this.kioskList = kioskList;
	}
	
	public List<ProductKiosk> getProductKioskList() {
		return productKioskList;
	}

	public void setProductKioskList(List<ProductKiosk> productKioskList) {
		this.productKioskList = productKioskList;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

}
