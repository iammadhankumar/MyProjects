package pharmabox.customdomain;


public class NonceInput {

	private long id;
	private String nonceToken;
	private float amount;


	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNonceToken() {
		return nonceToken;
	}
	public void setNonceToken(String nonceToken) {
		this.nonceToken = nonceToken;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	
	

}
