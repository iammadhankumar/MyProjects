package pharmabox.customdomain;

public class UserCounts {

	private Long chatUserCount;
	
	private Long advertiserCount;
	
	private Long redeemerCount;
	
	private Long RetmerCount;
	
	private Long totalCampaignCount;
	
	private Long totalActiveCampaignCount;
	
	private Long ytdCampaignCount;
	
	private Long ytdActiveCampaignCount;

	public Long getChatUserCount() {
		return chatUserCount;
	}

	public void setChatUserCount(Long chatUserCount) {
		this.chatUserCount = chatUserCount;
	}

	public Long getAdvertiserCount() {
		return advertiserCount;
	}

	public void setAdvertiserCount(Long adveriserCount) {
		this.advertiserCount = adveriserCount;
	}

	public Long getRedeemerCount() {
		return redeemerCount;
	}

	public void setRedeemerCount(Long redeemerCount) {
		this.redeemerCount = redeemerCount;
	}

	public Long getRetmerCount() {
		return RetmerCount;
	}

	public void setRetmerCount(Long retmerCount) {
		RetmerCount = retmerCount;
	}

	public Long getTotalCampaignCount() {
		return totalCampaignCount;
	}

	public void setTotalCampaignCount(Long totalCampaignCount) {
		this.totalCampaignCount = totalCampaignCount;
	}

	public Long getTotalActiveCampaignCount() {
		return totalActiveCampaignCount;
	}

	public void setTotalActiveCampaignCount(Long totalActiveCampaignCount) {
		this.totalActiveCampaignCount = totalActiveCampaignCount;
	}

	public Long getYtdCampaignCount() {
		return ytdCampaignCount;
	}

	public void setYtdCampaignCount(Long ytdCampaignCount) {
		this.ytdCampaignCount = ytdCampaignCount;
	}

	public Long getYtdActiveCampaignCount() {
		return ytdActiveCampaignCount;
	}

	public void setYtdActiveCampaignCount(Long ytdActiveCampaignCount) {
		this.ytdActiveCampaignCount = ytdActiveCampaignCount;
	}
		
}
