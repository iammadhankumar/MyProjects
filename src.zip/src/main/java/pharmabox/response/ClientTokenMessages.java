package pharmabox.response;

import javax.xml.bind.annotation.XmlElement;




public class ClientTokenMessages {
	
	@XmlElement(name="status")
	public ResponseStatus status;
	
	@XmlElement(name="clientToken")
	String clientToken;



	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}
	
	

	public String getClientToken() {
		return clientToken;
	}

	public void setClientToken(String clientToken) {
		this.clientToken = clientToken;
	}

	public ClientTokenMessages(ResponseStatus status,String clientToken){
		super();
		this.status=status;
		this.clientToken=clientToken;
	}




	

}
