package pharmabox.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;

import pharmabox.domain.Order;

public class OrderMessages {
	
	@XmlElement(name="status")
	public ResponseStatus status;
	
	@XmlElement(name="order")
	private Collection<Order> orderentities;
	
	@XmlElement(name="count")
	private long orderCount;

	
	public long getOrderCount() {
		return orderCount;
	}

	public void setOrderCount(long orderCount) {
		this.orderCount = orderCount;
	}

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public Collection<Order> getOrderentities() {
		return orderentities;
	}

	public void setOrderentities(Collection<Order> orderentities) {
		this.orderentities = orderentities;
	}

	
	public OrderMessages(ResponseStatus status,Collection<Order> orderentities,long orderCount)
	{
		super();
		this.status=status;
		this.orderentities=orderentities;
		this.orderCount=orderCount;
		
	}

}
