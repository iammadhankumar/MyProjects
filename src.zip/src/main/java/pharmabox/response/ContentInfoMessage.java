package pharmabox.response;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import pharmabox.domain.ContentManagement;

@XmlRootElement(name="ContentInfo")
public class ContentInfoMessage {

	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name="ContentManagement")
	private ContentManagement entity=new ContentManagement();			
	public ContentInfoMessage(){
		super();
	}		
	public ContentManagement getEntity() {
		return entity;
	}
	public void setEntity(ContentManagement entity) {
		this.entity = entity;
	}
	public ContentInfoMessage(ContentManagement Contentinfo){
		super();
		setEntity(Contentinfo);
	}		
	public ContentInfoMessage(ResponseStatus status,ContentManagement Contentinfo){
		super();
		this.status=status;
		this.entity=Contentinfo;
	}
}