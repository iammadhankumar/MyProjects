package pharmabox.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import pharmabox.customdomain.ProductCount;
import pharmabox.domain.Product;


@XmlRootElement(name = "product")
public class ProductMessage {
	
	@XmlElement(name = "status")
	public ResponseStatus status;

	private Collection<Product> entities;

	@XmlElement(name = "Product")
	public Collection<Product> getEntities() {
		return entities;
	}
	@XmlElement(name = "count")
	public ProductCount count;
	



	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public ProductCount getCount() {
		return count;
	}

	public void setCount(ProductCount count) {
		this.count = count;
	}

	public void setEntities(Collection<Product> entities) {
		this.entities = entities;
	}

	public ProductMessage(){
		super();
	}
	
	public ProductMessage(ResponseStatus status,Collection<Product> entities){
		super();
		this.status=status;
		this.entities=entities;
	}
	
	public ProductMessage(ResponseStatus status,ProductCount count,Collection<Product>entities){
		super();
		this.status=status;
		this.entities=entities;
		this.count=count;
	}
	

	
	public ProductMessage(ResponseStatus status,ProductCount count){
		super();
		this.status=status;
		this.count=count;
	}
}
