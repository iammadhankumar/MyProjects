package pharmabox.response;






import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;





@XmlRootElement(name="Basket")
public class CountMessage {	
	
	@XmlElement(name="status")
	public ResponseStatus status;

	
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}

	@XmlElement(name="basket")
	 private long count;
	
	
	
	public CountMessage(ResponseStatus status,long count){
		super();
		this.status=status;
		this.count=count;
	}
}


