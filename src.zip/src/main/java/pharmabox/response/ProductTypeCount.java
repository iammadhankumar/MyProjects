package pharmabox.response;

import java.util.List;

import pharmabox.domain.ProductType;

public class ProductTypeCount {
	
	private long count;
	
	private  List<ProductType> ProductTypeList;
  
	private long Basketcount;
	
	public long getBasketcount() {
		return Basketcount;
	}

	public void setBasketcount(long basketcount) {
		Basketcount = basketcount;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	public List<ProductType> getProductTypeList() {
		return ProductTypeList;
	}

	public void setProductTypeList(List<ProductType> productTypeList) {
		 this.ProductTypeList = productTypeList;
	}
	
	
}