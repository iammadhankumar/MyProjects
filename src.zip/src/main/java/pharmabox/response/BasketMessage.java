package pharmabox.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;

import pharmabox.domain.Product;



public class BasketMessage {
	
	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name="product")
	private Collection<Product> productInfo;
	
	@XmlElement(name="count")
	private long count;

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public Collection<Product> getProductInfo() {
		return productInfo;
	}

	public void setProductInfo(Collection<Product> productInfo) {
		this.productInfo = productInfo;
	}
	
	
	public BasketMessage(ResponseStatus status,Collection<Product> productInfo,long count)
	{
		super();
		this.status=status;
		this.productInfo=productInfo;
		this.count=count;
	}	
	

}
