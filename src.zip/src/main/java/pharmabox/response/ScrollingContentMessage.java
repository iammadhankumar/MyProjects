package pharmabox.response;

import javax.xml.bind.annotation.XmlElement;

import pharmabox.domain.ScrollingContent;

public class ScrollingContentMessage {
	
	@XmlElement(name = "status")
	public ResponseStatus status;
	
	@XmlElement(name = "scrollingcontent")
	public ScrollingContent scrollingContent;
	
	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public ScrollingContent getScrollingContent() {
		return scrollingContent;
	}

	public void setScrollingContent(ScrollingContent scrollingContent) {
		this.scrollingContent = scrollingContent;
	}


	
	public ScrollingContentMessage(ResponseStatus status,ScrollingContent scrollingContent){
		super();
		this.status=status;
		this.scrollingContent=scrollingContent;
	}
}
