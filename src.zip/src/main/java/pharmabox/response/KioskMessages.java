package pharmabox.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import pharmabox.domain.Kiosk;

@XmlRootElement(name="Kiosk")
public class KioskMessages {

	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name = "Kiosk")
	private Collection<Kiosk> entities;
	
	public Collection<Kiosk> getEntities() {
		return entities;
	}
	public void setEntities(Collection<Kiosk> entities) {
		this.entities = entities;
	}

	@XmlElement(name = "Kiosk")
	private long count;
	
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	public KioskMessages(){
		super();
	}
	
	
	
	public ResponseStatus getStatus() {
		return status;
	}
	public void setStatus(ResponseStatus status) {
		this.status = status;
	}
	
	public KioskMessages(ResponseStatus status,Collection<Kiosk> entities,long count){
		super();
		this.status=status;
		this.entities=entities;
		this.count=count;
	}
}