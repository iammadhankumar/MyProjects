package pharmabox.response;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.json.simple.JSONObject;

import pharmabox.domain.User;

@XmlRootElement(name="user")
public class UserMessage {

	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name="user")
	private User _entity=new User();
	
	@XmlElement(name="user")
	private JSONObject token=new JSONObject();
	
	

	
	public JSONObject getObject() {
		return token;
	}
	public void setObject(JSONObject object) {
		this.token = token;
	}
	public User getUser() {
		return _entity;
	}
	public void setEntity(User user) {
		this._entity = user;
	}	
	public UserMessage(){
		super();
	}	
	public UserMessage(User user){
		super();
		setEntity(user);
	}	
	public UserMessage(ResponseStatus status,User user){
		super();
		this.status=status;
		this._entity=user;
	}	
	
	public UserMessage(ResponseStatus status,User user,JSONObject  token){
		super();
		this.status=status;
		this._entity=user;
		this.token=token;
	}	
	
	
	public UserMessage(ResponseStatus status){
		
		this.status=status;
		
	}	
}