package pharmabox.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import pharmabox.domain.ProductType;


@XmlRootElement(name = "productType")
public class ProductTypeMessage {
	
	@XmlElement(name = "status")
	public ResponseStatus status;

	private Collection<ProductType> producttype;


	@XmlElement(name = "count")
	public ProductTypeCount count;
	
	public ProductTypeMessage(){
		super();
	}
	public ProductTypeMessage(ResponseStatus status,ProductTypeCount count){
		super();
		this.status=status;
		this.count=count;
	}
	public ProductTypeMessage(ResponseStatus status,Collection<ProductType> producttype){
		super();
		this.status=status;
		this.producttype=producttype;
	}
	
	public ProductTypeMessage(ResponseStatus status,ProductTypeCount count,Collection<ProductType> producttype){
		super();
		this.status=status;
		this.producttype=producttype;
		this.count=count;
	}
	

}