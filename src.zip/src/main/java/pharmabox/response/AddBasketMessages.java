package pharmabox.response;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import pharmabox.customdomain.AddBasketCount;





@XmlRootElement(name="Basket")
public class AddBasketMessages {	
	
	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name="user")
	private AddBasketCount Basket=new AddBasketCount();
	
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}

	@XmlElement(name="basket")
	 private long count;
	public AddBasketCount getEntity() {
		return Basket;
	}
	public void setEntity(AddBasketCount Basket) {
		this.Basket = Basket;
	}
	public AddBasketMessages(){
		super();
	}
	
	public AddBasketMessages(AddBasketCount Basket){
		super();
		setEntity(Basket);
	}

	public AddBasketMessages(ResponseStatus status,AddBasketCount Basket){
		super();
		this.status=status;
		this.Basket=Basket;
	}
	
	public AddBasketMessages(ResponseStatus status,long count){
		super();
		this.status=status;
		this.count=count;
	}
}


