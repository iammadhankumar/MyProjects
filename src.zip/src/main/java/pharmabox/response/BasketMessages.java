package pharmabox.response;

import javax.xml.bind.annotation.XmlElement;

import pharmabox.domain.Basket;



public class BasketMessages {
	
	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name="basket")
	private Basket basketInfo=new Basket();
	
	public Basket getBasket() {
		return basketInfo;
	}
	public void setEntity(Basket basketInfo) {
		this.basketInfo = basketInfo;
	}	
	
	
	
	public BasketMessages(ResponseStatus status,Basket basketInfo){
		super();
		this.status=status;
		this.basketInfo=basketInfo;
	}	
	
	public BasketMessages(ResponseStatus status){
		super();
		this.status=status;
		
	}	

}
