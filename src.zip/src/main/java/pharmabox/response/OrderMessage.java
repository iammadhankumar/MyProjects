package pharmabox.response;

import javax.xml.bind.annotation.XmlElement;

import pharmabox.domain.Order;
import pharmabox.domain.Product;
import pharmabox.domain.User;

public class OrderMessage {
	
	@XmlElement(name="status")
	public ResponseStatus status;
	
	@XmlElement(name="order")
	private Order orderentities=new Order();
	
	private User userEntity;
	
	private Product productEntity;

	
	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public Order getOrderentities() {
		return orderentities;
	}

	public void setOrderentities(Order orderentities) {
		this.orderentities = orderentities;
	}

	
//	public OrderMessage(ResponseStatus status,Collection<Order> orderentity){
//		super();
//		this.status=status;
//		this.orderentity=orderentity;
//		
//	}
	
	public User getUserEntity() {
		return userEntity;
	}

	public void setUserEntity(User userEntity) {
		this.userEntity = userEntity;
	}

	public Product getProductEntity() {
		return productEntity;
	}

	public void setProductEntity(Product productEntity) {
		this.productEntity = productEntity;
	}

	public OrderMessage(ResponseStatus status,Order orderentities){
		super();
		this.status=status;
		this.orderentities=orderentities;
		
	}
	
	
	public OrderMessage(ResponseStatus status,Order orderentities,User userEntity,Product productEntity){
		super();
		this.status=status;
		this.orderentities=orderentities;
		this.userEntity=userEntity;
		this.productEntity=productEntity;
		
	}
}
