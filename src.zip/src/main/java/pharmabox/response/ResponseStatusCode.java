package pharmabox.response;

public class ResponseStatusCode {
	
	public static final int STATUS_OK 				= 200;
	public static final int STATUS_UNAUTHORIZED 	= 401;
	public static final int STATUS_CONFLICT 		= 409;
	public static final int STATUS_INTERNAL_ERROR 	= 500;
	public static final int STATUS_REQUIRED 		= 204;
	public static final int STATUS_INVALID 	= 400;
	public static final int STATUS_NOTMATCHED 		= 205;
	public static final int STATUS_NOTMATCHED1 		= 205;

	public static final int STATUS_NORECORD 		= 206;
	public static final int STATUS_ACTIVATION_CODE_EXPIRED	= 227;
	public static final int STATUS_INSUFFICIENT =228;
	public static final int STATUS_AlREADY_EXISTS	= 302;
	public static final int STATUS_AlREADY_EXIST	= 232;
	public static final int STATUS_AlREADY_EXPIRED	= 231;
	public static final int STATUS_DATA_REQUIRED 		= 230;
	public static final int STATUS_NORECORDFOUND 		= 204;
	public static final int STATUS_NOT_ACCEPTABLE   = 406;

	
}
