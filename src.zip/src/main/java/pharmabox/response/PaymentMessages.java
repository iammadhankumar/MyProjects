package pharmabox.response;

import javax.xml.bind.annotation.XmlElement;

public class PaymentMessages {
	
	@XmlElement(name="status")
	public ResponseStatus status;

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	
	public PaymentMessages(ResponseStatus status){
		super();
		this.status=status;
		
	}	
}
