package pharmabox.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import pharmabox.domain.Kiosk;

@XmlRootElement(name="Kiosk")
public class KioskMessage {

	@XmlElement(name="status")
	public ResponseStatus status;	
	private Collection<Kiosk> entities;
	//private ProductKioskCount count;

	@XmlElement(name = "Kiosk")
	public Collection<Kiosk> getEntities() {
		return entities;
	}
	public KioskMessage(){
		super();
	}
	public KioskMessage(ResponseStatus status,Collection<Kiosk>entities){
		super();
		this.status=status;
		this.entities=entities;
		
	}
}