package pharmabox.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;

import pharmabox.views.KioskView;

public class KioskViewMessage {
	

	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name = "Kioskview")
	private Collection<KioskView> entities;
	
	public Collection<KioskView> getEntities() {
		return entities;
	}
	public void setEntities(Collection<KioskView> entities) {
		this.entities = entities;
	}

	@XmlElement(name = "Kioskview")
	private long count;
	
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	public KioskViewMessage(){
		super();
	}
	
	
	
	public ResponseStatus getStatus() {
		return status;
	}
	public void setStatus(ResponseStatus status) {
		this.status = status;
	}
	
	public KioskViewMessage(ResponseStatus status,Collection<KioskView> entities,long count){
		super();
		this.status=status;
		this.entities=entities;
		this.count=count;
	}

}
