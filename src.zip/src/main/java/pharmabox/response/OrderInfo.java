package pharmabox.response;

import javax.xml.bind.annotation.XmlElement;

import pharmabox.domain.Order;

public class OrderInfo {

	
	@XmlElement(name="status")
	public ResponseStatus status;	
	
	@XmlElement(name="order")
	public Order order;

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}	
	
	
	public OrderInfo(ResponseStatus status,Order order){
		super();
		this.status=status;
		this.order=order;
	}
	
}
