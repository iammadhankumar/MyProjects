package pharmabox.response;

import javax.xml.bind.annotation.XmlElement;

public class RewardCalculation {
	
	@XmlElement(name="status")
	public ResponseStatus status;
	
	@XmlElement(name="actualPrice")
	public float actualPrice;
	
	@XmlElement(name="rewardsPercentage")
	public long rewardsPercentage;
	
	@XmlElement(name="discountPrice")
	public float discountedPrice;
	
	@XmlElement(name="rewardsPrice")
	public float rewardsPrice;

	public float getRewardsPrice() {
		return rewardsPrice;
	}

	public void setRewardsPrice(float rewardsPrice) {
		this.rewardsPrice = rewardsPrice;
	}

	public float getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(float discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	
	
	

	public long getRewardsPercentage() {
		return rewardsPercentage;
	}

	public void setRewardsPercentage(long rewardsPercentage) {
		this.rewardsPercentage = rewardsPercentage;
	}

	public float getActualPrice() {
		return actualPrice;
	}

	public void setActualPrice(float actualPrice) {
		this.actualPrice = actualPrice;
	}
	public RewardCalculation(ResponseStatus status,float actualPrice,long rewardsPercentage,float rewardsPrice,float discountedPrice)
	{
		super();
		this.status=status;
		this.actualPrice=actualPrice;
		this.rewardsPercentage=rewardsPercentage;
		this.rewardsPrice=rewardsPrice;
		this.discountedPrice=discountedPrice;
	}

}
