package pharmabox.response;

import javax.xml.bind.annotation.XmlElement;

import pharmabox.domain.Rewards;

public class RewardMessage {
	
	@XmlElement(name = "status")
	public ResponseStatus status;
	
	@XmlElement(name="reward")
	public Rewards reward;

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public Rewards getReward() {
		return reward;
	}

	public void setReward(Rewards reward) {
		this.reward = reward;
	}
	
	public RewardMessage(ResponseStatus status,Rewards reward){
		super();
		this.status=status;
		this.reward=reward;
	}
	

}
