package pharmabox.response;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import pharmabox.domain.User;

@XmlRootElement(name="users")
public class UserMessages {

	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name="user")
	private List<User> _entity=new ArrayList<User>();
	

	public ResponseStatus getStatus() {
		return status;
	}
	public void setStatus(ResponseStatus status) {
		this.status = status;
	}
	public List<User> get_entity() {
		return _entity;
	}
	public void set_entity(List<User> _entity) {
		this._entity = _entity;
	}
	
	public List<User> getUser() {
		return _entity;
	}
	public void setEntity(List<User> user) {
		this._entity = (List<User>) user;
	}	
	public UserMessages(){
		super();
	}	
	public UserMessages(List<User> user){
		super();
		setEntity(user);
	}	

	
	
	public UserMessages(ResponseStatus status,List<User> user){
		super();
		this.status=status;
		this._entity=user;
	
	}
}