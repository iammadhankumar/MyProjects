package pharmabox.helper;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import pharmabox.domain.ContentManagement;
import pharmabox.repository.ContentManagementRepository;
import pharmabox.response.ContentInfoMessage;
import pharmabox.response.ResponseListMessage;
import pharmabox.response.ResponseMessages;
import pharmabox.response.ResponseStatus;
import pharmabox.response.ResponseStatusCode;
import pharmabox.service.ContentManagementService;
import pharmabox.utils.CommonUtils;
import pharmabox.validation.BasicValidation;

@Service
public class ContentInfoHelper {

	
	@Autowired 
	private ContentManagementService contentManagementService;
	
	
	@Autowired
	BasicValidation basicValidation;

	
	@Autowired
	ContentManagementRepository contentManagementRepository;
	
	CommonUtils commonUtils 		= CommonUtils.getInstance();
	
	private static final Logger logger = LogManager.getLogger(ContentInfoHelper.class);
	
	public ContentInfoMessage getprivacyInfo(@RequestParam(value="label")String label,final HttpServletResponse response){
		ResponseStatus status = null;
		ContentManagement contentInfo=null;
		response.setHeader("Cache-Control", "no-cache");
		try{
			contentInfo=contentManagementService.getPrivacyPolicyInfo(label);
			if (contentInfo!=null) {
				status=new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");		
			}
			else {
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Record");	
			}
		}catch(Exception e){
          logger.error("getprivacyInfo ",e);
        status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return new ContentInfoMessage(status, contentInfo);
	}
	
	public ResponseMessages<ContentManagement> saveAndUpdateContentManagement(@RequestBody ContentManagement contentManagement) {
		ResponseStatus status = null;
		ContentManagement cms = null;
		try
		{
			System.out.println(contentManagement.getDescription());
			if(contentManagement.getDescription()!=null && !contentManagement.getDescription().isEmpty())
			{
				
				if(contentManagement.getLabel()!=null && !contentManagement.getLabel().isEmpty())
				{ 
					if(contentManagement.getTitle() !=null && !contentManagement.getTitle().isEmpty())
					{
					cms=contentManagementRepository.getByLabel(contentManagement.getLabel());
					cms.setDescription(contentManagement.getDescription());
					cms.setLabel(contentManagement.getLabel());
					cms.setTitle(contentManagement.getTitle());
					contentManagementRepository.save(cms);
					status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"SUCCESS");
					}
					else
					{
						status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"Title Required");
					}
				}
				else
				{
					status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"Label Required");
				}
				
			}
			else
			{
				status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"Description Required");
			
			}
		
			
		}
		catch(Exception e)
		{
			logger.error("saveAndUpdateContentManagement ",e);
			status=new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"InternalError");
		}
		
		return new ResponseMessages<>(status,cms);
	}
	
	public ResponseListMessage<ContentManagement> getAllContentManagement(HttpServletResponse response) {
		ResponseStatus status = null;
		List<ContentManagement> contentManagementList = null;
		try
		{
			contentManagementList = contentManagementService.getAllContentManagement();
			if(basicValidation.checkListnullandsize(contentManagementList))
			{
				response.setStatus(ResponseStatusCode.STATUS_OK);
				status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"SUCCESS");
			}
			else
			{
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"NO RECORD FOUND");
				return new ResponseListMessage<>(status,null);
			}
		}
		catch(Exception e)
		{
			logger.error("getAllContentManagement ",e);
			status=new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"InternalError");
		}
		return new ResponseListMessage<>(status,contentManagementList);
	}
	
	public ResponseMessages<ContentManagement> getContentManagementByType(@RequestParam(value="label")String label,HttpServletResponse response) {
		ResponseStatus status = null;
		ContentManagement cms = null;
		try
		{
		cms = contentManagementService.getContentManagementByContentType(label);
		if(cms != null)
		{
			status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"SUCCESS");
		}
		else
		{
			status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"NO RECORD FOUND");
			return new ResponseMessages<>(status,null);
		}
		}
		catch(Exception e)
		{
			logger.error("getContentManagementByType ",e);
			status=new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"InternalError");
		}
		return new ResponseMessages<>(status,cms);
	}

	public ResponseMessages<ContentManagement> getFaq(String label, HttpServletResponse response) {
		ResponseStatus status = null;
		ContentManagement cms = null;
        try
        {
    		cms = contentManagementService.getContentManagementByContentType(label);
    		System.out.println("CMS "+cms);
    		if(cms!=null)
    		{
    			status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"SUCCESS");
    		}
    		else
    		{
    			status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"NO RECORD FOUND");
    			return new ResponseMessages<>(status,null);
    		}
    		
        }
    	catch(Exception e)
		{
			logger.error("getFaq ",e);
			status=new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"InternalError");
		}
		return new ResponseMessages<>(status,cms);
	}
	
	


}
