package pharmabox.helper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseBody;

import com.braintreegateway.BraintreeGateway;
import com.braintreegateway.ClientTokenRequest;
import com.braintreegateway.Customer;
import com.braintreegateway.CustomerRequest;
import com.braintreegateway.Environment;
import com.braintreegateway.Result;
import com.braintreegateway.TransactionRequest;

import pharmabox.domain.User;
import pharmabox.response.ClientTokenMessages;
import pharmabox.response.ResponseStatus;
import pharmabox.response.ResponseStatusCode;
import pharmabox.utils.UserByToken;

@Service
public class PayPalHelper
{

	@Autowired
	UserByToken tokenUser;
	
	public @ResponseBody ClientTokenMessages getClientToken(final HttpServletResponse response,final HttpServletRequest request,final TransactionRequest requ) throws Exception
	{
		ResponseStatus status=null;
		String clientToken=null;
		  User user=null;
		 user = tokenUser.getUser(request);
		try
		{
			
			 BraintreeGateway gateway = new BraintreeGateway(
			            Environment.SANDBOX,
			            "7tqb9bqyq6dyyfpt",
			            "9sb465cwq5ys68fz",
			            "0bd5057c4b622a1395fb67d29d7e08a1"
			        );
			 
			 CustomerRequest reque = new CustomerRequest()
					  .id(String.valueOf(user.getUser_id()));
					
                  System.out.println("REQUE "+reque);
					Result<Customer> result = gateway.customer().create(reque);
					
					System.out.println("RES "+result);
//					System.out.println(result.isSuccess());
//					System.out.println("RES TARGET "+result.getTarget().getId());
					if(result.isSuccess())
					{
						  ClientTokenRequest clientTokenRequest = new ClientTokenRequest()
						  .customerId(result.getTarget().getId());
						   clientToken = gateway.clientToken().generate(clientTokenRequest);
						   System.out.println("CLT "+clientToken);
		
			     
					}
//					 clientToken.get(new Route("/client_token") {
//						  @Override
//						  public Object handle(Request request, Response response) {
//						    return gateway.clientToken().generate();
//						  }
//						});
			else
		    {
				status=new ResponseStatus(ResponseStatusCode.STATUS_CONFLICT,"CONNOT GET TOKEN");
				return new ClientTokenMessages(status,clientToken);
		    }
			
		}
		
		catch(Exception e){
			e.printStackTrace();
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
	
		status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
		return new ClientTokenMessages(status,clientToken);
	}
}
