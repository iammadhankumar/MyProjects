package pharmabox.helper;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;

import org.apache.commons.lang.RandomStringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.Barcode128;

import pharmabox.customdomain.signupCustomDomain;
import pharmabox.domain.User;
import pharmabox.domain.UserType;
import pharmabox.domain.VerificationCode;
import pharmabox.email.EmailManager;
import pharmabox.oauth2.TokenGeneration;
import pharmabox.response.ResponseStatus;
import pharmabox.response.ResponseStatusCode;
import pharmabox.response.UpdateUserMessage;
import pharmabox.response.UserMessage;
import pharmabox.service.IUserService;
import pharmabox.service.IVerificationService;
import pharmabox.utils.CommonProperties;
import pharmabox.utils.CommonUtils;
import pharmabox.utils.UserByToken;
import pharmabox.validation.UserValidation;

@PropertySource("classpath:application.properties")
@Service
public class UserHelper {
	
	private static final Logger logger = LoggerFactory
			.getLogger(UserHelper.class);

	@Autowired
	private IVerificationService VerificationService;

	@Autowired
	private IUserService userService;

	@Autowired
	UserByToken tokenUser;
	
	@Autowired
	private Environment env;

	
	CommonUtils commonUtils = CommonUtils.getInstance();

	String cmnUtils = CommonUtils.getBasicAuthHeader("pharmabox","pharmabox");
		
	@SuppressWarnings("unused")
	public UserMessage createUser(@RequestBody signupCustomDomain signupObj ,@FormParam("username") String username,@FormParam("password") String password,@FormParam("deviceToken") String deviceToken,HttpServletRequest request, final HttpServletResponse response) throws Exception{
		ResponseStatus status = null;
		User user=null;
		UserType usertype=null;
		JSONObject token=null;
		User facebookcheck=null;
		String fullDomain ="";
		response.setHeader("Cache-Control", "no-cache");
		String filepath= null; //CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.getBannerImage();
		String facebookpath= null; //CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.getFacebookLogo();

		try {

			usertype=userService.getUserTypeById(signupObj.getUserType());

			String validation=UserValidation.checkUserFieldsEmpty(signupObj.getEmail(),signupObj.getFirst_name(), signupObj.getLast_name(),signupObj.isPromotions(),signupObj.isTermsAndCondition()); 
			System.out.println("validation");
			System.out.println(validation);

			System.out.println(validation);
			if(validation.equalsIgnoreCase("Success") ) { 

				if(UserValidation.isEmailFormat(signupObj.getEmail()))
				{

					if (UserValidation.isAlphaNumeric(signupObj.getPassword())) 
					{

						User check=userService.getUserByEmail(signupObj.getEmail()); 
						if(!signupObj.getFacebook_id().isEmpty() || signupObj.getFacebook_id()!=null){
							if(signupObj.getFacebook_id().length()>0){
								facebookcheck=userService.getUserByFacebook(signupObj.getFacebook_id());
							}				
						}
						//check email duplication
						if(check!=null){
							if(signupObj.getFacebook_id().isEmpty() || signupObj.getFacebook_id()==null) {
								status=new ResponseStatus(ResponseStatusCode.STATUS_AlREADY_EXISTS,"User already exists");
								return new UserMessage(status,null);
							}
						} if(check!=null && facebookcheck==null){
							if(!signupObj.getFacebook_id().isEmpty() || signupObj.getFacebook_id()!=null) {	

								if(check.getFacebook_id() != null && check.getFacebook_id().equals(commonUtils.generateEncryptedPwd(signupObj.getFacebook_id()))) {
									user=facebookcheck;
									status=new ResponseStatus(ResponseStatusCode.STATUS_AlREADY_EXISTS,"Facebook user already exist");
									return new UserMessage(status, check);
								}else{	
									check.setFacebook_id(commonUtils.generateEncryptedPwd(signupObj.getFacebook_id()));							
									userService.updateUser(check); 
									Long userId=check.getUser_id();
									if(userId>0){
										user=userService.getUserById(userId);
										status=new ResponseStatus(ResponseStatusCode.STATUS_AlREADY_EXISTS,"Facebookid updated");
										return new UserMessage(status,null);
									}						
								}
							}
						} 	

						else {						
//							JSONObject json = generateBarcode ();
//							String card_id =json!=null?json.get("values").toString():null;
//							String path=json!=null?json.get("path").toString():null;	

							 String imagesPath=Image();

						user = new User();
						user.setEmail(signupObj.getEmail());
						user.setPassword(commonUtils.generateEncryptedPwd(signupObj.getPassword()));
                        user.setFirst_name(signupObj.getFirst_name());
  						user.setLast_name(signupObj.getLast_name());
						user.setCreated_on(new Date());
						user.setActive(true);
						user.setPromotions(signupObj.isPromotions());
						user.setProfileimage(signupObj.getProfileimage()!=null && !signupObj.getProfileimage().isEmpty() ?signupObj.getProfileimage().contains("https://") || signupObj.getProfileimage().contains("http://")?signupObj.getProfileimage():env.getProperty("cloudFrontUrl")+signupObj.getProfileimage():null );
						user.setTermsAndCondition(signupObj.isTermsAndCondition());
						user.setActions(signupObj.isActions());
						user.setDeviceToken(signupObj.getDeviceToken());
						user.setDeviceType(signupObj.getDeviceType());
						user.setUserType(usertype);
						if(!signupObj.getFacebook_id().isEmpty() || signupObj.getFacebook_id()!=null){
							if(signupObj.getFacebook_id().length()>0){
								user.setFacebook_id(commonUtils.generateEncryptedPwd(signupObj.getFacebook_id()));
							}
						}

						Long userId=userService.registerNewUser(user);
						if(userId>0){
							user=userService.getUserById(userId);
							if(signupObj.isActions()) {
								String s=signupObj.getEmail();
								String[] names=s.split("@");
								if(names.length > 0){
									fullDomain = names[names.length-1];
									//Company company=userService.getDomain(fullDomain);
									//									if(company !=null)
									//									{
									//										user.setCompany_id(company);
									//
									//										//user.setCorporateName(corporateName);
									//										//String confirmLink=CommonProperties.getBaseURL()+CommonProperties.getContextPath()+EmailConfiguration.getCorporateFileName();
									//										//EmailManager.activateUserViaEmail(user.getEmail(),user.getFirst_name(),confirmLink);
									//										String	encodeId="token="+userId;
									//										String encodeUrl= URLEncoder.encode(encodeId, "UTF-8");
									//										if(userId > 0){     
									//											String confirmLink = CommonProperties.getBaseURL()+CommonProperties.getFrontEndPath()+"activation.html?"+encodeUrl;
									//											//confirmation mail to new user
									//											System.out.println("mail sending");
									//											String imagelogo=CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.gettemplate();
									//											EmailManager.activateUserViaEmail(user.getEmail(),user.getFirst_name(),confirmLink,CommonProperties.getBaseURL(),filepath,user.getCompany_id().getCompany_name(),imagelogo);
									//											System.out.println("mail sended");
									//										}																			
									//									}
								}
							} else {									
								//System.out.println("filepath:"+filepath);
								/*String twitterpath=CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.gettwitterLogo();
							String instragrampath=CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.getinstragramLogo();
							String pinterestpath=CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.getpinterestLogo();
							String imagelogo=CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.getimageLogo();*/
								//EmailManager.registerUser(user.getEmail(),user.getFirst_name(),filepath,facebookpath,twitterpath,instragrampath,pinterestpath);
								String imagelogo=CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.gettemplate();
								//	System.out.println("imagelogo:"+imagelogo);
								System.out.println("register user mail sending");
								System.out.println(user.getEmail());
								System.out.println(user.getFirst_name());
								EmailManager.registerUser(user.getEmail(),user.getFirst_name(),filepath,imagelogo);
								System.out.println("register user mail sended");



							}

						}
						status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
						System.out.println(signupObj.getEmail());
						System.out.println(signupObj.getPassword());
						token =  TokenGeneration.loginwithregister(signupObj.getEmail(),signupObj.getPassword());
						System.out.println("OBJect***************************");
						System.out.println("kkkkkkk"+token);

						//						if(user!=null)
						//						{
						//							System.out.println("INNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN");
						//							EmailManager.sentPromotionAndDiscountMail(user.getEmail(), user.getFirst_name(),"testmailobs@gmail.com");
						//						}
						//						



					}
					}

					else {
						status=new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED,"Password should have one number, minimum of eight characters and a symbol");
						return new UserMessage(status, null,null);		

					}	

				}
				else
				{
					status=new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED,"please check you email pattern");
					return new UserMessage(status, null,null);		

				}

			}

			else
			{
				status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,validation);
				return new UserMessage(status, null,null);		

			}
		}
		catch(Exception e) {
			logger.error("createUser ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new UserMessage(status, null,null);		

		}		

		return new UserMessage(status, user,token);		
	}
	
	@SuppressWarnings("unchecked")
	private JSONObject generateBarcode() throws DocumentException{
		JSONObject json=new JSONObject();
		String values=RandomStringUtils.randomAlphanumeric(13).toUpperCase();
		String path1=CommonProperties.getBasePath();
		String path2 = commonUtils.createExportDirectory(path1, CommonProperties.getImagePath() );
		String path=commonUtils.createExportDirectory(path2,  CommonProperties.getBarcode());
//		CommonProperties.getBasePath()+CommonProperties.getImagePath() + CommonProperties.getBarcode();	
		System.out.println("PATH "+path);
		try {
			Barcode128 code128 = new Barcode128();
			code128.setCode(values); 
			java.awt.Image rawImage = code128.createAwtImage(Color.BLACK, Color.WHITE);

			BufferedImage resizedImage = new BufferedImage(500,120, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = resizedImage.createGraphics();
			g.drawImage(rawImage, 0, 0,500,120,null);
			ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
			ImageIO.write(resizedImage, "png", bytesOut);
			g.dispose();

			byte[] pngImageData = bytesOut.toByteArray();
			try(FileOutputStream fos = new FileOutputStream(path+"/"+values+".png"))
			{
			fos.write(pngImageData);
			fos.close();
			json.put("values", values);
			json.put("path", values+".png");			
			return json;
			}
		}
		catch(Exception e){
			logger.error("generateBarcode ",e);
		}	return json;




	}
	
	private String Image(){
		String facebookpath=CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.getFacebookLogo();
		String twitterpath=CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.gettwitterLogo();
		String instragrampath=CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.getinstragramLogo();
		String pinterestpath=CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.getpinterestLogo();
		String filepaths=facebookpath+twitterpath+instragrampath+pinterestpath;
		System.out.println("filepaths:"+filepaths);
		return filepaths;

	}



	public UserMessage viewProfile(@FormParam("email") String email,final HttpServletResponse response){
		ResponseStatus status = null;
		User user=null;
		String path=CommonProperties.getBaseURL()+CommonProperties.getImagePath()+CommonProperties.getBarcode();
		response.setHeader("Cache-Control", "no-cache");
		try {
			user=userService.getUserByEmail(email);
			if(user!=null) {

				status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
			} else {
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No record found");
			}
		}catch(Exception e){
			logger.error("viewProfile ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return new UserMessage(status, user);
	}


	public UserMessage loginUser(@FormParam("email") String email,@FormParam("password") String password,@FormParam("devicetoken") String deviceToken,@FormParam("devicetype") String deviceType,@RequestParam(value="traffic",required=false,defaultValue="0") int traffic,final HttpServletResponse response)
	{
		ResponseStatus status = null;
		User user=null;
		JSONObject token=null;
		long type=0;
		response.setHeader("Cache-Control", "no-cache");
		try{
			
			user=userService.getUserByEmailAndType(email,traffic);	
			
			//System.out.println(password);
			password=commonUtils.generateEncryptedPwd(password);
			System.out.println("PASSWORD"+password);
			
			if(user!=null) {
				if(!user.isActive())
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_INVALID, "User is not active");
					return new UserMessage(status,null);
				}
				System.out.println(user.getPassword());
				System.out.println(password);
				if(user.getPassword().equals(password)) {
					System.out.println("equal");
					
				
					
						
					status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
					token = TokenGeneration.loginwithregister(email,password);
					System.out.println("OBJect***************************");
				
				
					//System.out.println(token);
				} 
				else {
					status = new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED, "Invalid Username or Password, please try again!");
					return new UserMessage(status,null);
				}
			} else {
				response.setStatus(ResponseStatusCode.STATUS_INVALID);
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"Please Enter Valid Username");
				return new UserMessage(status,null);
			}
		} catch(Exception e) {
			logger.error("loginUser ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return new UserMessage(status,user,token);
	}
	
	public UserMessage forgetPassword(@FormParam("email") String email,final HttpServletResponse response,final HttpServletRequest request){
		ResponseStatus status = null;
		User user=null;
		User userCheck=null;
		VerificationCode verificationcode= new VerificationCode();
		String path=CommonProperties.getBaseURL()+CommonProperties.getImagePath()+CommonProperties.getBarcode();
		String filepath=CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.getBannerImage();
		response.setHeader("Cache-Control", "no-cache");
		try{



			if(!email.isEmpty() && email != null) {


				if(UserValidation.isEmailFormat(email))
				{

					userCheck=userService.getUserByEmail(email);
					if(userCheck!=null)

					{


						user=userService.getUserPasswordByEmailId(email);	

						if(email.equals(user.getEmail()))
						{
							System.out.println(user.getEmail());

							if(user !=null ) { //update particular user 
								List<VerificationCode> verificationList = VerificationService.getVerificationListByUserId(user.getUser_id());
								if(verificationList != null && verificationList.size() > 0) {
									for(VerificationCode vc : verificationList) {
										vc.setActive(false);
										vc.setUpdatedOn(new Date());
										VerificationService.update(vc);
									}
								}
								String values=RandomStringUtils.randomAlphanumeric(8).toUpperCase();

								verificationcode.setVerificationCode(commonUtils.generateEncryptedPwd(values));
								verificationcode.setCreatedOn(new Date());
								verificationcode.setUpdatedOn(new Date());
								verificationcode.setUser_id(user);
								verificationcode.setActive(true);
								VerificationService.save(verificationcode);
								/*VerificationCode verificationObj = VerificationService.getVerificationByverificationId(id);

					userService.updateUser(user);*/

								String imagelogo=CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.gettemplate();
								String name=null;
								name=user.getFirst_name();
								//							if( name==null ){
								//								name=user.getCompany_id().getContact_name();
								//							}	
								System.out.println("Fp");
								EmailManager.forgotPwd1(email,values,filepath,name,imagelogo);
								//	user.setBarcode(path+"/"+user.getBarcode());
								status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Verification code has been sent");	
							}



						}

						else
						{
							status=new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED,"Your Email Address is Not Correct");
							return new UserMessage(status, null);	
						}

					}

					else
					{
						status=new ResponseStatus(ResponseStatusCode.STATUS_INVALID,"Invalid Email Address");
						return new UserMessage(status, null);	
					}

				}



				else {
					status=new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED,"please check your email pattern");
					return new UserMessage(status, null);
				}

			}



			else 
			{
				status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"Email is required");
				return new UserMessage(status, null);
			}


		}
		catch(Exception e) {
			logger.error("forgetPassword ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new UserMessage(status, null);
		}	

		return new UserMessage(status, user);		
	}

	
	public UserMessage resetpassword(@FormParam("new_password") String new_password,@FormParam("confirm_password") String confirm_password,@FormParam("verification_Code") String verification_Code,final HttpServletResponse response){
		ResponseStatus status = null;
		User user=null;
		VerificationCode verificationObj = null;
		response.setHeader("Cache-Control", "no-cache");

		try{

			if(new_password != null && !new_password.isEmpty()) {

				if(confirm_password!=null && !confirm_password.isEmpty()) 
				{
					if(verification_Code != null && !verification_Code.isEmpty()) {
						if (UserValidation.isAlphaNumeric(new_password) && UserValidation.isAlphaNumeric(confirm_password)) {
							System.out.println(new_password);
							System.out.println(confirm_password);

							if(new_password.equals(confirm_password))
							{

								String encrpted  = commonUtils.generateEncryptedPwd(verification_Code);
								verificationObj = VerificationService.getVerificationByverificationCode(encrpted);
								if(verificationObj != null && verificationObj.getUser_id() != null) {				

									user=userService.getUserById(verificationObj.getUser_id().getUser_id());

									if(user!=null) {
										Instant then = null;
										if (verificationObj != null){
											then = verificationObj.getCreatedOn().toInstant();
										}
										Instant now = Instant.now();
										Instant twentyFourHoursEarlier;
										twentyFourHoursEarlier = now.minus(24, ChronoUnit.HOURS);
										Boolean within24Hours = (then != null) ? (!then.isBefore(twentyFourHoursEarlier)) && then.isBefore(now) : false;
										if(!within24Hours) {
											status=new ResponseStatus(ResponseStatusCode.STATUS_ACTIVATION_CODE_EXPIRED,"Otp expired");	
											return new UserMessage(status, null);
										}
										user.setPassword(commonUtils.generateEncryptedPwd(new_password));				
										userService.updateUser(user);
										verificationObj.setActive(false);
										verificationObj.setUpdatedOn(new Date());
										VerificationService.update(verificationObj);
										status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Password changed successfully");	
									}else {
										status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"user  doesn't exists");
									}
								} else {
									status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"Invalid verification code");
								}
							}

							else {
								status=new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED 	,"password mismatch");
							}

						}


						else
						{
							status=new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED,"Password should have one number, minimum of eight characters and a symbol");	
						}

					}
					else
					{
						status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"Verification code is Required");
					}


				}
				else
				{
					status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"confirm password is Required");
				}	

			}
			else
			{
				status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"new password is Required");
			}


		}

		catch(Exception e) {
			logger.error("resetpassword ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}	

		return new UserMessage(status, null);		
	}
	

	public UserMessage changePassword(@RequestParam("currentpassword") String currentpassword, @RequestParam("newpassword") String newpassword,
			@RequestParam("confirmpassword") String confirmpassword, final HttpServletRequest request, final HttpServletResponse response){
		ResponseStatus status = null;
		User user=null;
		String path=CommonProperties.getBaseURL()+CommonProperties.getImagePath()+CommonProperties.getBarcode();
		user = tokenUser.getUser(request);
		response.setHeader("Cache-Control", "no-cache");
		try{
			if((currentpassword!=null && !currentpassword.isEmpty())&& (newpassword!=null && !newpassword.isEmpty()) && (confirmpassword!=null && !confirmpassword.isEmpty()))
			{
				if (isAlphaNumeric(currentpassword) && isAlphaNumeric(newpassword) &&  isAlphaNumeric(confirmpassword) ) 
				{
				currentpassword=commonUtils.generateEncryptedPwd(currentpassword);	
			    if(!(currentpassword.equals(user.getPassword())))
				{
					status=new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED,"Your Current password is wrong");
					return new UserMessage(status, null);
				}
					if(!(newpassword.equals(confirmpassword)))
					{
						status=new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED,"New Password And Confirm Password Must Be Equal");
						return new UserMessage(status, null);
					}
					user=userService.getUserById(user.getUser_id());
					currentpassword=commonUtils.generateEncryptedPwd(currentpassword);	
					if(user!=null )
					{
						
						user.setPassword(commonUtils.generateEncryptedPwd(newpassword));
						userService.updateUser(user); 
						status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
					} 

					else
					{
						status=new ResponseStatus(ResponseStatusCode.STATUS_INVALID ,"Invalid User");
						return new UserMessage(status, null);
					}
				}

				else{
					status=new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED,"Password should have one number, minimum of eight characters and a symbol");
				}

			} 

			else {
				status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"Please Enter All the required Fields");
				return new UserMessage(status, null);
			}

		}catch(Exception e) {
			logger.error("changePassword ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}	

		return new UserMessage(status, user);		
	}



	public static boolean isAlphaNumeric(String password) {

		Pattern pattern = Pattern.compile("((?=.*[0-9])(?=.*[!?@#$%^&*()._-]).{8,})");
		return pattern.matcher(password).matches();
	}

	public static boolean isEmailFormat(String email) {

		Pattern pattern = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
		return pattern.matcher(email).matches();

	}

	public static String checkUserFieldsEmpty(String email,String first_name, String last_name, boolean b, boolean c) {

		if(email == null || email.isEmpty())
		{
			System.out.println("email null");
			return "Email is required";
		}
		if(first_name == null || first_name.isEmpty())
		{
			System.out.println("fn null");
			return "FirstName is required";

		}


		if(last_name == null || last_name.isEmpty())
		{
			System.out.println("ln null");
			return "LastName is required"; 
		}


		return "Success";
	}
	
	public UpdateUserMessage viewProfile(@FormParam("userId") long userId ,final HttpServletResponse response){
		ResponseStatus status = null;
		User user=null;
		String path=CommonProperties.getBaseURL()+CommonProperties.getImagePath()+CommonProperties.getBarcode();
		response.setHeader("Cache-Control", "no-cache");
		try {
			user=userService.getUserById(userId);
			if(user!=null) {

				status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
			} else {
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No record found");
				return new UpdateUserMessage(status, null);
			}
		}catch(Exception e){
			logger.error("viewProfile ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		//	user.setBarcode(path+"/"+user.getBarcode());
		return new UpdateUserMessage(status, user);
	}
	
	public UpdateUserMessage updateUser(@RequestBody signupCustomDomain obj,final HttpServletRequest request,final HttpServletResponse response){
		ResponseStatus status = null;
		User user=null;
		response.setHeader("Cache-Control","no-cache");
		try{


			if(obj != null)
			{
				System.out.println("not null");
				System.out.println(obj.getUserId());
				String profilevalidation=UserValidation.checkUpdateFieldsEmpty(obj.getEmail(),obj.getFirst_name(), obj.getLast_name(),obj.isPromotions(),obj.isTermsAndCondition()); 

				//user=userService.getUserById(obj.getUserId());
				user=tokenUser.getUser(request);
				if(user != null && profilevalidation.equalsIgnoreCase("Success"))
				{     	
					if(UserValidation.isEmailFormat(obj.getEmail()))
					{
						user.setFirst_name(obj.getFirst_name());
						user.setLast_name(obj.getLast_name());
						user.setEmail(obj.getEmail());
						user.setActions(obj.isActions());
						user.setUpdated_on(new Date());
						user.setProfileimage(obj.getProfileimage().contains("https://") || obj.getProfileimage().contains("http://")?obj.getProfileimage():env.getProperty("cloudFrontUrl")+obj.getProfileimage());
						userService.updateUser(user); 
						status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"User updated successfully");

					}
					else {
						status=new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED,"Please Check your email pattern");
						return new UpdateUserMessage(status, null);
					}	
				}

				else {
					status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,profilevalidation);
					return new UpdateUserMessage(status, null);
				}	

			}


			else {
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"user not found");
				return new UpdateUserMessage(status, null);
			}			


		}
		catch(Exception e) {
			
			logger.error("updateUser ",e);
		}

		return new UpdateUserMessage(status, user);
	}


	public ResponseStatus UpdateLocation(@RequestBody signupCustomDomain userObj ,HttpServletRequest request,final HttpServletResponse response){

		User user=null;
		User userId=null;
		ResponseStatus status=null;;

		try
		{
			user = tokenUser.getUser(request);
			System.out.println("User******"+user);
			if(user!=null)
			{

				user.setLatitude(userObj.getLatitude());
				user.setLangitude(userObj.getLongitude());

				if(userObj.getLatitude()!=null && userObj.getLongitude()!=null)
				{
					userService.updateUser(user);
					status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"updated successfully");						

				}
				else
				{
					status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"Both latitude and Longitude Required");
				}
			}


		}


		catch(Exception e) {
			logger.error("UpdateLocation ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}

		return status;
	}


	public UserMessage GetLocation(@RequestBody signupCustomDomain userObj ,HttpServletRequest request,final HttpServletResponse response)
	{
		ResponseStatus status=null;
		List<User> user=null;
		User userEntity = tokenUser.getUser(request);
		User userObject=null;

		try
		{
			userObject = userService.getUserById(userEntity.getUser_id());

		}

		catch(Exception e)
		{
			logger.error("GetLocation ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}

		return new  UserMessage (status,userObject);
	}

	
	public @ResponseBody ResponseStatus updateUserStatus(@RequestBody signupCustomDomain userObj, final HttpServletRequest request,final HttpServletResponse response)
	{
		ResponseStatus status=null;
		User user=null;
		User userEntity = tokenUser.getUser(request);
		try
		{
			if(userEntity!=null)
			{
				user=(userObj.getUser_id()>0)?userService.getUserById(userObj.getUser_id()):null;
				if(user!=null)
				{
					user.setActive(!user.isActive());
					userService.updateUser(user);
					status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"User Active Status Updated");
				}
				else
				{
					status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND,"No User Selected");
				}
			}
			else
			{	
				status=new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED,"UnAuthorized User");	
			}

		}

		catch(Exception e)
		{
			logger.error("updateUserStatus ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return status;
	}
	

	

}
