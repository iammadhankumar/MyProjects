package pharmabox.helper;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.braintreegateway.BraintreeGateway;
import com.braintreegateway.Environment;
import com.braintreegateway.Result;
import com.braintreegateway.Transaction;
import com.braintreegateway.TransactionRequest;
import com.braintreegateway.ValidationError;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.Barcode128;

import pharmabox.customdomain.OrderInput;
import pharmabox.domain.Basket;
import pharmabox.domain.BasketStatus;
import pharmabox.domain.Order;
import pharmabox.domain.OrderBasket;
import pharmabox.domain.Product;
import pharmabox.domain.ProductKiosk;
import pharmabox.domain.Rewards;
import pharmabox.domain.RewardsMaintain;
import pharmabox.domain.RewardsPurchaseInfo;
import pharmabox.domain.User;
import pharmabox.repository.RewardsMaintainRepository;
import pharmabox.response.OrderInfo;
import pharmabox.response.OrderMessage;
import pharmabox.response.OrderMessages;
import pharmabox.response.ResponseStatus;
import pharmabox.response.ResponseStatusCode;
import pharmabox.service.IAddProductKioskService;
import pharmabox.service.IAdminService;
import pharmabox.service.IBasketService;
import pharmabox.service.IOrderService;
import pharmabox.service.IUserService;
import pharmabox.utils.CommonProperties;
import pharmabox.utils.CommonUtils;
import pharmabox.utils.UserByToken;

@Service
public class OrderHelper {
	
	@Autowired
	UserByToken tokenUser;

	@Autowired
	private IOrderService orderService;

	@Autowired
	private IAdminService adminService;

	@Autowired
	private IBasketService basketService;

	@Autowired
	private IUserService userService;

	@Autowired
	private RewardsMaintainRepository rewardMaintainRepo;


	@Autowired
	private IAddProductKioskService  AddProductKioskService;

	CommonUtils commonUtils = CommonUtils.getInstance();
	private static final Logger logger = LogManager.getLogger(OrderHelper.class);
	
	
	
	@SuppressWarnings("unused")
	public OrderMessage addOrderInfo(@RequestBody OrderInput orderInputObj,final HttpServletRequest request,final HttpServletResponse response) throws Exception 
	{
		ResponseStatus status = null;
		User user = null;
		User userInfo = null;
		Product product = null;
		Order order = null;
		List<Basket> basket = null;
		Basket basketObj=null;
		Basket basketobj=null;
		RewardsPurchaseInfo rewardsPurchase=null;
		RewardsMaintain rewardsMaintain=null;
		float originalAmount=0;
		float rewardsAmount=0;
		long percentage=0;
		float discountedAmount=0;
		String transactionID=null;
		Rewards rewardObj=null;
		OrderBasket orderBasketObj=null;
		List<OrderBasket> orderBasketlist=new ArrayList<>();
		user = tokenUser.getUser(request);
		String orderNo = null;
	     Order orderObj=null;
		try 
		{
			userInfo = userService.getUserById(user.getUser_id());
			if (userInfo != null)
			{
				if(orderInputObj.getAmount()>0)
				 {
				if((orderInputObj.getNonceToken()!=null && ! orderInputObj.getNonceToken().isEmpty()) && (orderInputObj.getAmount()>0))
				{
					BraintreeGateway gateway = new BraintreeGateway(
							Environment.SANDBOX,
							"7tqb9bqyq6dyyfpt",
							"9sb465cwq5ys68fz",
							"0bd5057c4b622a1395fb67d29d7e08a1"
							);
					
					Float f=orderInputObj.getAmount();
					TransactionRequest req = new TransactionRequest()
							.amount(new BigDecimal(Float.toString(orderInputObj.getAmount())))		
							.paymentMethodNonce(orderInputObj.getNonceToken())
							.options()
							.submitForSettlement(true)
							.done();


					Result<Transaction> result = gateway.transaction().sale(req);

					if (result.isSuccess()) {
						Transaction transaction = result.getTarget();
						System.out.println("Success! This is a valid nonce token:");
						transactionID=transaction.getId();

						System.out.println(transactionID);
					} 

					else if (result.getTransaction() != null) 
					{
						Transaction transaction = result.getTransaction();
						System.out.println("Error processing transaction:");
						System.out.println("  Status: " + transaction.getStatus());
						System.out.println("  Code: " + transaction.getProcessorResponseCode());
						System.out.println("  Text: " + transaction.getProcessorResponseText());	

						status=new ResponseStatus(ResponseStatusCode.STATUS_AlREADY_EXPIRED,"Nonce Token Expired");
						return new OrderMessage(status,null);       

					} 

					else {
						for (ValidationError error : result.getErrors().getAllDeepValidationErrors()) 
						{
							System.out.println("Attribute: " + error.getAttribute());
							System.out.println("  Code: " + error.getCode());
							System.out.println("  Message: " + error.getMessage());
							status=new ResponseStatus(ResponseStatusCode.STATUS_INVALID,"Invalid Nonce Token");

						}
						return new OrderMessage(status,null);

					}

				}

				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED, "Nonce Token and amount Required");
					return new OrderMessage(status, null);
				}
				}
				basket=basketService.getBasketbyListCheck(orderInputObj.getBid(),user.getUser_id());
				if ( basket!=null) 
				{
					String barcodepath=CommonProperties.getBaseURL()+CommonProperties.getImagePath()+CommonProperties.getBarcode();
					
					orderNo = commonUtils.randomNumbers();
					JSONObject json = generateBarcode(orderNo);
					String code =json.get("values").toString();
					String path=json.get("path").toString();
					System.out.println(orderNo);
					order=new Order();
					order.setOrderNo(orderNo);
					order.setBasketStatus(basketService.setBasketStatus(4));
					order.setPurchaseStatus(true);  
					order.setUser(userInfo);
					order.setBarcode(path);
					order.setTransactionId(transactionID);
					order.setBarcode(barcodepath+"/"+order.getBarcode());
					order.setCreatedOn(new Date());
					for(int i = 0; i < basket.size(); i++) 
					{
						basketObj=basketService.getBasketByUser(user.getUser_id(),basket.get(i).getBid());
						originalAmount=(originalAmount+basket.get(i).getPrice());
						rewardObj=basketObj.getReward();
						orderBasketObj=new OrderBasket();
						orderBasketObj.setBasket(basketObj);
						orderBasketlist.add(orderBasketObj);
						if(basketObj != null) 
						{
							ProductKiosk productKioskObj=AddProductKioskService.getProductKioskBypId(basketObj.getProductKiosk().getId());
							basketobj=basketService.getbasketDetailsbypid(productKioskObj.getId(),user.getUser_id());

							product= productKioskObj != null ? productKioskObj.getProduct():null;
							if(productKioskObj != null)
							{
								if(product !=null && productKioskObj.getQuantity()>=basketobj.getQuantity())
								{	
									if(basketobj!=null)
									{
										productKioskObj.setQuantity((productKioskObj.getQuantity()-basket.get(i).getQuantity()));
										AddProductKioskService.updateProductKiosk(productKioskObj);
										basketService.updateBasket(basketobj);
										basketService.UpdateBasketActive(basket.get(i).getBid());
									}
								}
							}
						}
					}
					if(rewardObj!=null)
					{
						order.setReward(rewardObj);
						originalAmount=originalAmount+((originalAmount*13)/100);
						rewardsAmount=(float) rewardObj.getPromoValue();
						percentage=(long) rewardObj.getPercentage();
						discountedAmount=(float)originalAmount-rewardsAmount;
						rewardsPurchase=new RewardsPurchaseInfo();
						rewardsPurchase.setActive(true);
						rewardsPurchase.setActualPrice((orderInputObj.getAmount()*13)/100);
						rewardsPurchase.setDiscountedPrice(discountedAmount);
						rewardsPurchase.setRewardsPrice(rewardsAmount);
						order.setPrice(originalAmount);
						long rp=orderService.registerRewardsPurchaseInfo(rewardsPurchase);
						RewardsPurchaseInfo rewardsPurchaseObj=orderService.getRewardPurchaseInfoById(rp);
						order.setRewardsPurchase(rewardsPurchaseObj);
						rewardsMaintain=adminService.getRewardsMaintainByUser(rewardObj.getId(), user.getUser_id());
						if(rewardsMaintain!=null)
						{
							rewardsMaintain.setPurchase(true);
							rewardMaintainRepo.save(rewardsMaintain);		
						}
					}
					else
					{
						order.setPrice((orderInputObj.getAmount()*13)/100);
					}
					order.setOrderBasket(orderBasketlist);
					long orderId=  orderService.registerNewOrder(order);   
					status = new ResponseStatus(ResponseStatusCode.STATUS_OK,"success ");
				}
				else 
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND, " Basket Not Found.");
					return new OrderMessage(status, null);
				}
			}
			else 
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_INVALID, " User Not Found.");
				return new OrderMessage(status, null);
			}

		}
		catch (Exception e)
		{
			logger.error("OrderInfo ", e);

		}
		return new OrderMessage(status, order);
	}	


	@SuppressWarnings("unchecked")
	private JSONObject generateBarcode(String orderNo) throws DocumentException{
		JSONObject json=new JSONObject();
		String path=CommonProperties.getBasePath()+CommonProperties.getImagePath() + CommonProperties.getBarcode();	 
		try {   
			Barcode128 code128 = new Barcode128();
			code128.setCode(orderNo);   
			java.awt.Image rawImage = code128.createAwtImage(Color.BLACK, Color.WHITE);
			BufferedImage resizedImage = new BufferedImage(500,120, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = resizedImage.createGraphics();
			g.drawImage(rawImage, 0, 0,500,120,null);
			ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
			ImageIO.write(resizedImage, "png", bytesOut);
			g.dispose();

			byte[] pngImageData = bytesOut.toByteArray();
			try(FileOutputStream fos = new FileOutputStream(path+"/"+orderNo+".png"))
			{
			fos.write(pngImageData);
			fos.close();
			json.put("values", orderNo);
			json.put("path", orderNo+".png");
			return json;
			}
		} catch(Exception e) {
			logger.error("generateBarcode ", e);
		} return json;
	}

	
	public OrderInfo GetMyOrder(@RequestParam(value="orderId",required=false,defaultValue="0") Long orderId,@RequestParam(value="orderNo") String orderNo,final HttpServletRequest request, final HttpServletResponse response) throws Exception {

		ResponseStatus status = null;
		Order order = null;
		User user = null;
		user = tokenUser.getUser(request);
		try 
		{
			if (user != null) 
			{
				if(orderNo!=null)
				{
					order=orderService.getOrderInfoById(user.getUser_id(),orderNo,orderId);
					if(order==null )
					{
						status = new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED, "Order Not Found");
						return new OrderInfo(status, null);
					}
				}
				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED, "Order Number Required");
					return new OrderInfo(status, null);
				}		
			}
			else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND, "User Not Found");
				return new OrderInfo(status, null);
			}
		}

		catch (Exception e) 
		{
			logger.error("GetMyOrder ", e);

		}
		status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "success ");
		return new OrderInfo(status, order);
	}

	
	public OrderMessages GetMyOrderList(@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,final HttpServletRequest request, final HttpServletResponse response) throws Exception 
	{
		ResponseStatus status = null;
		List<Order> order = null;
		User user = null;
		user = tokenUser.getUser(request);
		long orderCount = 0;
		try 
		{
			if (user != null)
			{
				order = orderService.getOrderInfoByUser(user.getUser_id(), pagenumber, pagerecord);
				orderCount = orderService.getorderCount(user.getUser_id(), true);
				if (order==null ) 
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No Record");
					return new OrderMessages(status, null, 0);
				}
			} 
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED, "User Not Found");
				return new OrderMessages(status, null, 0);
			}
		}

		catch (Exception e) 
		{
			logger.error("GetMyOrderList ", e);

		}
		status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "success ");
		return new OrderMessages(status, order, orderCount);
	}


	public OrderMessage updateOrderStatus(@RequestBody OrderInput orderInputObj, HttpServletRequest request,
			HttpServletResponse response) {
		ResponseStatus status=null;
		Order order=null;
		BasketStatus basketStatus=null;
		try
		{
			
				order=orderService.getOrderByOrderNo(orderInputObj.getOrderNo());
				if(order!=null)
				{
					if(orderInputObj.getBasketStatusId()>4 && orderInputObj.getBasketStatusId()<7)
					{
					basketStatus=orderInputObj.getBasketStatusId()>0?basketService.setBasketStatus(orderInputObj.getBasketStatusId()):null;

					if(basketStatus!=null )
					{
						order.setBasketStatus(basketStatus);
						orderService.updateOrder(order);
						status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");
					}
					else
					{
						status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND, "BasketStatus Not Found");
						return new OrderMessage(status, null);
					}
				}
					else
					{
						status = new ResponseStatus(ResponseStatusCode.STATUS_INVALID, "Not Valid BasketStatus");
						return new OrderMessage(status, null);
					}
				}
				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND, "Order Not Found");
					return new OrderMessage(status, null);
				}

		}
		catch (Exception e) 
		{
			logger.error("updateOrderStatus ", e);

		}
		return new OrderMessage(status,order);
	}


}
