package pharmabox.helper;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.Barcode128;

import pharmabox.customdomain.KioskInput;
import pharmabox.customdomain.ProductInput;
import pharmabox.customdomain.RewardsInput;
import pharmabox.customdomain.ScrollingContentInput;
import pharmabox.domain.Kiosk;
import pharmabox.domain.Order;
import pharmabox.domain.Product;
import pharmabox.domain.ProductKiosk;
import pharmabox.domain.ProductType;
import pharmabox.domain.Rewards;
import pharmabox.domain.ScrollingContent;
import pharmabox.domain.User;
import pharmabox.repository.ScrollingContenRepository;
import pharmabox.response.AddProductResponse;
import pharmabox.response.ImageResponse;
import pharmabox.response.KioskMessages;
import pharmabox.response.OrderMessages;
import pharmabox.response.ResponseStatus;
import pharmabox.response.ResponseStatusCode;
import pharmabox.response.RewardMessage;
import pharmabox.response.RewardMessages;
import pharmabox.response.ScrollingContentMessage;
import pharmabox.response.ScrollingContentMessages;
import pharmabox.response.SelectedKioskMessage;
import pharmabox.response.UserMessages;
import pharmabox.service.IAddProductKioskService;
import pharmabox.service.IAdminService;
import pharmabox.service.IKioskService;
import pharmabox.service.IOrderService;
import pharmabox.service.IProductService;
import pharmabox.service.UserService;
import pharmabox.utils.CommonProperties;
import pharmabox.utils.CommonUtils;
import pharmabox.utils.ImageUtils;
import pharmabox.utils.UserByToken;
import pharmabox.validation.DateValidation;
import pharmabox.validation.KioskValidation;
import pharmabox.validation.ProductValidation;

@Service
public class AdminHelper {
	
	CommonUtils commonUtils = CommonUtils.getInstance();
	
	private static final Logger logger = LogManager.getLogger(AdminHelper.class);
	
	@Autowired
	UserService userService;

	@Autowired
	IKioskService kioskService;

	@Autowired
	UserByToken tokenUser;

	@Autowired
	IAdminService adminService;

	@Autowired
	IProductService productService;
	
	@Autowired 
	ScrollingContenRepository scrollingContentRepo;

	@Autowired
	IOrderService orderService;

	@Autowired
	IAddProductKioskService productKioskService;


	public static final String IMG_SMALL = "small";
	public static final String IMG_MEDIUM = "medium";
	public static final String IMG_ORIGINAL = "original";
	
	public UserMessages viewUsers(@RequestParam(value="stat",required=false) int stat,final HttpServletResponse response) {
		ResponseStatus status = null;
		List<User> user = null;
		response.setHeader("Cache-Control", "no-cache");
		try {
			user = userService.getAllUsersByStatus(stat);

			if (user != null) {

				status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");

			}

			else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No record found");
				return new UserMessages(status, null);
			}
		} catch (Exception e) {
			logger.error("viewUsers ", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return new UserMessages(status, user);
	}
	
	
	
	public RewardMessage addRewards(@RequestBody RewardsInput RewardsInputObj,
			final HttpServletRequest request, HttpServletResponse response) {
		ResponseStatus status = null;
		User user = null;
		Rewards reward = null;
		user = tokenUser.getUser(request);
		try {
			if (user != null) {
				
								if (RewardsInputObj.getCouponCode() != null
										&& !RewardsInputObj.getCouponCode().isEmpty()) {
									reward = adminService.getRewardByPromoCode(RewardsInputObj.getCouponCode());

									if (reward != null) {
										String barcodepath = CommonProperties.getBaseURL()
												+ CommonProperties.getImagePath() + CommonProperties.getBarcode();
										System.out.println(barcodepath);

										reward.setRewardsName(RewardsInputObj.getRewardsName());
										JSONObject json = generateBarcode(RewardsInputObj.getCouponCode());
										String code = json.get("values").toString();
										System.out.println("CODE " + code);
										String path = json.get("path").toString();
										reward.setBarcode(path);
										System.out.println("bpath" + barcodepath + "/" + reward.getBarcode());
										reward.setBarcode(barcodepath + "/" + reward.getBarcode());
										reward.setActive(true);

										adminService.updateRewards(reward);
									}

									else {
										status = new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED,
												"This reward Not found");
										return new RewardMessage(status, null);
									}
								} else {
									status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,
											"coupon code required");
									return new RewardMessage(status, null);
								}
							}

							else {
								status = new ResponseStatus(ResponseStatusCode.STATUS_INVALID,
										"Past date can't acceptable");
								return new RewardMessage(status, null);
							}

						

					
		} catch (Exception e) {
			logger.error("addRewards ", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new RewardMessage(status, null);

		}

		status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");
		return new RewardMessage(status, reward);
	}
	
	@SuppressWarnings("unchecked")
	private JSONObject generateBarcode(String couponCode) throws DocumentException {
		JSONObject json = new JSONObject();
		String path = CommonProperties.getBasePath() + CommonProperties.getImagePath() + CommonProperties.getBarcode();
		try {
			Barcode128 code128 = new Barcode128();
			code128.setCode(couponCode);
			java.awt.Image rawImage = code128.createAwtImage(Color.BLACK, Color.WHITE);
			BufferedImage resizedImage = new BufferedImage(500, 120, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = resizedImage.createGraphics();
			g.drawImage(rawImage, 0, 0, 500, 120, null);
			ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
			ImageIO.write(resizedImage, "png", bytesOut);
			g.dispose();

			byte[] pngImageData = bytesOut.toByteArray();
			try(FileOutputStream fos = new FileOutputStream(path + "/" + couponCode + ".png"))
			{
			fos.write(pngImageData);
			fos.close();
			json.put("values", couponCode);
			json.put("path", couponCode + ".png");
			return json;
			}
		} catch (Exception e) {
			logger.error("generateBarcode ",e);		}
		return json;
	}
	
	public RewardMessages getAllRewardList(
			@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,
			@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,
			@RequestParam(value="all", required=false ,defaultValue = "0") int all,HttpServletRequest request, HttpServletResponse response) {
		ResponseStatus status = null;
		List<Rewards> rewardcheck = null;
		List<Rewards> reward = null;
		User user = null;
		user = tokenUser.getUser(request);
		long rewardsCount = 0;
		try {
			if (user != null) {
				rewardsCount = adminService.getOverAllRewardsListCount();
				
				if(all==1)
				{
					
					rewardcheck=adminService.getAllRewardsListByall(pagenumber, pagerecord);
					reward = rewardcheck;
					if(reward==null)
					{
						status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "NO REWARDS LIST ADDED");
						return new RewardMessages(status, null, 0);
					}
					
					System.out.println("RGVDCBGVFGHV"+reward.size());
				}
				
				else
				{

				if (rewardsCount > 0) {
					rewardcheck = adminService.getOverAllRewardsList(pagenumber, pagerecord);

					if (rewardcheck != null) {
						reward = rewardcheck;

					}

				} else {
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "NO REWARDS LIST ADDED");
					return new RewardMessages(status, null, 0);
				}

			}}

			else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "User Not Found");
				return new RewardMessages(status, null, 0);
			}
		}

		catch (Exception e) {
			logger.error("getAllRewardList ",e);				
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new RewardMessages(status, null, 0);

		}
		status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success ");
		return new RewardMessages(status, reward, rewardsCount);
	}


	public RewardMessages getRewardList(
			@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,
			@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,
			HttpServletRequest request, HttpServletResponse response)

	{

		ResponseStatus status = null;
		List<Rewards> rewardcheck = null;
		List<Rewards> reward = null;
		List<Rewards> rewardObj = null;
		User user = null;
		user = tokenUser.getUser(request);
		long rewardsCount = 0;
		try {
			if (user != null) {
				rewardObj = adminService.getAllRewardsList(user.getUser_id());

				if (rewardObj != null) {
					rewardcheck = adminService.getRewardsList(user.getUser_id(), pagenumber, pagerecord);

					if (rewardcheck != null && rewardcheck.size() > 0) {
						reward = rewardcheck;
						rewardsCount = rewardObj.size();
						System.out.println("COUNT :" + rewardcheck.size());

					}

				} else {
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "NO REWARDS LIST ADDED");
					return new RewardMessages(status, null, 0);
				}

			}

			else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "User Not Found");
				return new RewardMessages(status, null, 0);
			}
		}

		catch (Exception e) {
			logger.error("getRewardList ",e);				
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new RewardMessages(status, null, 0);

		}
		status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success ");
		return new RewardMessages(status, reward, rewardsCount);
	}
	

	public RewardMessage getRewardById(@RequestParam(value = "rewardId") long rewardId,
			HttpServletRequest request, HttpServletResponse response) {
		ResponseStatus status = null;
		User user = null;
		Rewards reward = null;
		user = tokenUser.getUser(request);
		try {
			if (user != null) {

				reward = adminService.getRewardById(rewardId);
				if (reward == null) {
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND, "No RewardId Found");
					return new RewardMessage(status, null);
				}
			}

			else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED, "Unauthorized User");
				return new RewardMessage(status, null);
			}
		}

		catch (Exception e) {
			logger.error("getRewardById ",e);				
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new RewardMessage(status, null);

		}
		status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");
		return new RewardMessage(status, reward);
	}
	
	public ScrollingContentMessage addScrollingcontent(
			@RequestBody ScrollingContentInput scrollingInputObj, final HttpServletRequest request,
			HttpServletResponse response) {
		ResponseStatus status = null;
		User user = null;
		user = tokenUser.getUser(request);
		ScrollingContent scrollingContent = null;

		try {
			if (user != null) {
				if (scrollingInputObj.getType() != null && !scrollingInputObj.getUrl().isEmpty()) {
					if (scrollingInputObj.getUrl() != null && !scrollingInputObj.getUrl().isEmpty()) {
						scrollingContent = new ScrollingContent();
						scrollingContent.setType(scrollingInputObj.getType());
						scrollingContent.setUrl(scrollingInputObj.getUrl());
						scrollingContent.setCreatedOn(new Date());
						scrollingContent.setActive(true);
//						scrollingContent.setUser(user);
						adminService.registerScrollingContentInfo(scrollingContent);

					} else {
						status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED, "Scrolling url required");
						return new ScrollingContentMessage(status, null);
					}
				} else {
					status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED, "Scrolling content type required");
					return new ScrollingContentMessage(status, null);
				}
			} else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "User Not Found");
				return new ScrollingContentMessage(status, null);

			}
		}

		catch (Exception e) {
			logger.error("addScrollingcontent ",e);				
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new ScrollingContentMessage(status, null);

		}
		status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success ");
		return new ScrollingContentMessage(status, scrollingContent);
	}

	public ScrollingContentMessage editScrollingcontent(
			@RequestBody ScrollingContentInput scrollingInputObj, final HttpServletRequest request,
			HttpServletResponse response) {
		ResponseStatus status = null;
		User user = null;
		user = tokenUser.getUser(request);
		ScrollingContent scrollingContent = null;

		try {
			if (user != null) {
				if(scrollingInputObj.getId()>0)
				{
				if (scrollingInputObj.getType() != null && !scrollingInputObj.getUrl().isEmpty()) {
					if (scrollingInputObj.getUrl() != null && !scrollingInputObj.getUrl().isEmpty()) {
						scrollingContent = scrollingContentRepo.findById(scrollingInputObj.getId());
						scrollingContent.setType(scrollingInputObj.getType());
						scrollingContent.setUrl(scrollingInputObj.getUrl());
						//scrollingContent.setCreatedOn(new Date());
						scrollingContent.setActive(true);
//						scrollingContent.setUser(user);
						scrollingContentRepo.save(scrollingContent);

					} else {
						status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED, "Scrolling url required");
						return new ScrollingContentMessage(status, null);
					}
				} else {
					status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED, "Scrolling content type required");
					return new ScrollingContentMessage(status, null);
				}
			}
				
				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED, "id required");
					return new ScrollingContentMessage(status, null);
				}
			}
				
				
				
				else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "User Not Found");
				return new ScrollingContentMessage(status, null);

			}
		}

		catch (Exception e) {
			logger.error("editScrollingcontent ",e);				
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new ScrollingContentMessage(status, null);

		}
		status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success ");
		return new ScrollingContentMessage(status, scrollingContent);
	}
	
	
	public ScrollingContentMessages getScrollingContentList(
			@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,
			@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,
			HttpServletRequest request, HttpServletResponse response) {
		ResponseStatus status = null;
		User user = null;
		List<ScrollingContent> scrollingContent = null;
		List<ScrollingContent> scrollingContentObj = null;
		long scrollingContentCount = 0;
		try {
			scrollingContent = adminService.getAllScrollingContentList();
			if (scrollingContent != null) {
				System.out.println("mkdajfhjdsftygfcdgfDSXf");
				scrollingContentObj = adminService.getScrollingContentList(pagenumber, pagerecord);
				System.out.println(scrollingContentObj);

				if (scrollingContentObj != null && scrollingContentObj.size() > 0) {
					System.out.println("INN");

					scrollingContentCount = scrollingContent.size();
					status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");
				}

			} else

			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND,
						"NO SCROLLING CONTENT LIST ADDED");
				return new ScrollingContentMessages(status, null, 0);
			}
		}

		catch (Exception e) {
			logger.error("getScrollingContentList ",e);				
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");

		}


		return new ScrollingContentMessages(status, scrollingContentObj, scrollingContentCount);
	}
	

	public OrderMessages GetOrderList(
			@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,
			@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,
			final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		ResponseStatus status = null;
		List<Order> order = null;
		User user = null;
		user = tokenUser.getUser(request);
		long orderCount = 0;
		try {
			if (user != null) {
				order = orderService.getOrderInfoList(pagenumber, pagerecord);
				if (order==null) {
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Records Found");
					return new OrderMessages(status, null, 0);
				}
				orderCount = orderService.getOrderInfoListCount();

			} else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED, "User Not Found");
				return new OrderMessages(status, null, 0);
			}
		}

		catch (Exception e) {
			logger.error("GetOrderList ",e);				

		}
		status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "success ");
		return new OrderMessages(status, order, orderCount);
	}

	
	
	@SuppressWarnings("unused")
	public ImageResponse postImage(@FormParam("file") MultipartFile file, int type, HttpServletRequest request)
			throws IOException {
		ResponseStatus status = null;
		System.out.println("file::" + file);
		String fileName = "";
		String uploadUrl = "";
		String imageExtention="";
		User user = tokenUser.getUser(request);
		if (file != null) {
			 imageExtention = FilenameUtils.getExtension(file.getOriginalFilename());

			String path = CommonProperties.getBasePath() + CommonProperties.getImagePath();
			if (type == 1)// for product upload
			{

				path = path + CommonProperties.getProduct() + tokenUser.randomReferenceString();
			}

			if (type == 2)// for scrolling content image upload
			{

				path = path + CommonProperties.getScrollingContent() + tokenUser.randomReferenceString();
			}

			if (type == 3)// for scrolling content video upload
			{

				path = path + CommonProperties.getReward() + tokenUser.randomReferenceString();
			}

			File f = new File(path);
			if (!f.isDirectory()) {
				System.out.println("INN MAKE DIR");
				f.mkdirs();
			}
			fileName = file.getOriginalFilename();
			String sourceImg = path + "/" + IMG_ORIGINAL + "/" + fileName;
			byte[] byteArr = file.getBytes();
			InputStream inputStream = new ByteArrayInputStream(byteArr);
			new ImageUtils().fileCreation(path + "/" + IMG_ORIGINAL);
			new ImageUtils().writeToFile(inputStream, sourceImg);

			uploadUrl = sourceImg.replace(CommonProperties.getBasePath(), CommonProperties.getBaseURL());
		}
		status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");
		return new ImageResponse(status, uploadUrl);
	}
	
	
	
	public RewardMessage UpdateRewards(@RequestBody RewardsInput RewardsInputObj,
			final HttpServletRequest request, HttpServletResponse response) {
		ResponseStatus status = null;
		User user = null;
		Rewards reward = null;
		user = tokenUser.getUser(request);
		try {
			if (user != null) {
				if (RewardsInputObj.getRewardsName() != null && !RewardsInputObj.getRewardsName().isEmpty()) {

									String barcodepath = CommonProperties.getBaseURL() + CommonProperties.getImagePath()
											+ CommonProperties.getBarcode();
									System.out.println(barcodepath);

									reward = adminService.getRewardById(RewardsInputObj.getId());
									if (reward != null) {
										reward.setRewardsName(RewardsInputObj.getRewardsName());

										System.out.println("bpath" + barcodepath + "/" + reward.getBarcode());
										
										if(RewardsInputObj.getExpiryOn()!=null)
										{
											DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
											DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd-MM-yyy", Locale.ENGLISH);
											 @SuppressWarnings("unused")
											SimpleDateFormat isdf= new SimpleDateFormat("dd-MM-yyy");
											SimpleDateFormat sdf= new SimpleDateFormat("dd-MM-yyyy");
											LocalDate date = LocalDate.parse(RewardsInputObj.getExpiryOn(), inputFormatter).plusDays(1);
											String formattedDate = outputFormatter.format(date);
										
											
											if(formattedDate!=null && !formattedDate.isEmpty() && DateValidation.pastDateStringValidation(formattedDate))
											{
												 reward.setExpiry(formattedDate);
												
													Date date1=sdf.parse(formattedDate);
													reward.setExpiryOn(date1);
												
												
												System.out.println(formattedDate); 
										      reward.setExpiry(formattedDate);

											}
											else
											{
												status = new ResponseStatus(ResponseStatusCode.STATUS_AlREADY_EXPIRED, "Past date can't acceptable");
												return new RewardMessage(status, null);
											}

											}
										reward.setPercentage(RewardsInputObj.getPercentage());
										if(RewardsInputObj.getRewardImage()==null)
										{
										reward.setRewardImage(reward.getRewardImage());
											
										}
										else
										{
											if(RewardsInputObj.getRewardImage()==null)
											{
												status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED, "Reward image  Required");
												return new RewardMessage(status, null);
											}
											
											reward.setRewardImage(RewardsInputObj.getRewardImage());
											
											
										}
										
										
										reward.setActive(true);

										adminService.updateRewards(reward);
									}

									else {
										status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,
												"No Record to update");
										return new RewardMessage(status, null);
									}

								


//						}
//
//						else {
//							status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED, "Reward Image Required");
//							return new RewardMessage(status, null);
//						}
									
				}

				else {
					status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED, "Reward Name  Required");
					return new RewardMessage(status, null);
				}

			} else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED, "UnAuthorized User");
				return new RewardMessage(status, null);
			}

		} catch (Exception e) {
			logger.error("UpdateRewards ",e);				
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new RewardMessage(status, null);

		}

		status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");
		return new RewardMessage(status, reward);
	}
	
	
	
	
	public ResponseStatus updateRewardsStatus(@RequestBody RewardsInput rewardObj, final HttpServletRequest request,final HttpServletResponse response)
	{
		ResponseStatus status=null;
		Rewards reward=null;
		User user=null;
		user = tokenUser.getUser(request);
		try
		{
			System.out.println(user);
			
			if(user!=null)
			{
				reward=adminService.getRewardId(rewardObj.getId());
				if(reward!=null)
				{
					reward.setActive(!reward.isActive());
					adminService.updateRewards(reward);
					status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "reward Status Updated");
				}
				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND, "No reward Found");
				}
			}
			else
			{
			status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED, "Unauthorized User");
			}

		}



	catch(Exception e)
	{
		logger.error("updateRewardsStatus ",e);				
		status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
	}
	return status;

}
	
	public  SelectedKioskMessage editKiosk(@RequestBody KioskInput kioskinuputObj,
			final HttpServletResponse response) throws Exception {
		ResponseStatus status = null;
		Kiosk kiosk = null;
		response.setHeader("Cache-Control", "no-cache");

		try {
			String validation = KioskValidation.checkKioskFieldsEmpty(kioskinuputObj.getKioskId(),
					kioskinuputObj.getKioskName(), kioskinuputObj.getLatitude(), kioskinuputObj.getLongitude(),
					kioskinuputObj.getAddress());

			if (validation.equalsIgnoreCase("okay"))
			{
				kiosk = kioskService.getKioskById(kioskinuputObj.getId());
				if (kiosk != null) 
				{
					kiosk.setKioskId(kioskinuputObj.getKioskId());
					kiosk.setKioskName(kioskinuputObj.getKioskName());
					kiosk.setLatitude(kioskinuputObj.getLatitude());
					kiosk.setLongitude(kioskinuputObj.getLongitude());
					kiosk.setAddress(kioskinuputObj.getAddress());
					kiosk.setCreated_on(new Date());
					kioskService.updateKiosk(kiosk);
					status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");
				}
			} 
			else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND, validation);
			}
		} 
		catch (Exception e) {
			logger.error("editKiosk ",e);				
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return new SelectedKioskMessage(status, kiosk);
	}
	
	
	public  RewardMessages getAllRewards(
			@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,
			@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,
			HttpServletRequest request, HttpServletResponse response) {
		ResponseStatus status = null;
		List<Rewards> rewardcheck = null;
		List<Rewards> reward = null;
		User user = null;
		user = tokenUser.getUser(request);
		long rewardsCount = 0;
		try {
			if (user != null) {
		
					rewardcheck = adminService.getOverAllRewardsList(pagenumber, pagerecord);

					if (rewardcheck != null) {
						reward = rewardcheck;
						status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success ");

					}

				 else {
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "NO REWARDS LIST ADDED");
					return new RewardMessages(status, null, 0);
				}

			}

			else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "User Not Found");
				return new RewardMessages(status, null, 0);
			}
		}

		catch (Exception e) {
			logger.error("getAllRewards ",e);				
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new RewardMessages(status, null, 0);

		}
	
		return new RewardMessages(status, reward, rewardsCount);
	}

	public KioskMessages getAllKiosks(@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,HttpServletRequest request, HttpServletResponse response)
	{

		ResponseStatus status=null;
		List<Kiosk> kiosk=null;
		User user=null;
		user = tokenUser.getUser(request);

		try
		{
			if(user!=null)
			{
				System.out.println("error1");
				kiosk=adminService.getAllKiosks(pagenumber, pagerecord,0,0);
				System.out.println("error2");
				if(kiosk!=null)
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success ");
				}

				else {
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND, "NO KIOSK LIST FOUND");
					return new KioskMessages(status, null, 0);
				}
			}
			else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED, "UnAuthorized User");
				return new KioskMessages(status, null, 0);
			}
		}

		catch (Exception e) {
			logger.error("getAllKiosks ",e);				
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new KioskMessages(status, null, 0);

		}
		return new KioskMessages(status, kiosk, 0);

	}
	
	
	@SuppressWarnings("unused")
	public AddProductResponse addProducts(@RequestBody ProductInput productInputObj,
			final HttpServletRequest request, HttpServletResponse response) {
		ResponseStatus status = null;
		Product product = null;
		User user = null;
		user = tokenUser.getUser(request);
		boolean validation = false;
		ProductType productType = null;
		ProductKiosk productKiosk = null;
		Kiosk kiosk = null;
		long productTypeId = 0;
		long quantity=0;
		Product prod = null;
		Product productId = null;
		ProductKiosk pk = null;
		long kioskId=0;
		long pid = 0;
		try {
			if (user != null) {
				System.out.println(productInputObj);
				System.out.println("lkjhlkjhlkjhlkjhkjh" + productInputObj.getDescription());
				System.out.println("lkjhlkjhlkjhlkjhkjh" + productInputObj.getProductTypeID());
				productType = productService.getProductTypeId(productInputObj.getProductTypeID());
				System.out.println(productType.getId());
				productTypeId = productType.getId();
				String products = ProductValidation.checkProductFieldsEmpty(productInputObj.getProductId(),
						productInputObj.getProductName(), productInputObj.getPrice(), productTypeId,
						 productInputObj.getDescription(),
						productInputObj.getQuantity());
				validation = (products.equalsIgnoreCase("success")) ? true : false;
				if (validation) {
					product = productService.getProductByProductId(productInputObj.getProductId());
					if (product != null) {
						product.setProductId(productInputObj.getProductId());
						product.setProductName(productInputObj.getProductName());
						product.setPrice(productInputObj.getPrice());
						product.setProductType(productService.getProductTypeId(productInputObj.getProductTypeID()));
						product.setProductDescription(productInputObj.getDescription());
						if(productInputObj.getProductImage()!=null && !productInputObj.getProductImage().isEmpty())
						{
						product.setProductImage(productInputObj.getProductImage());
						}
						product.setWeight(0);
						product.setQuantity(0);
						productService.updateProduct(product);

						kiosk = kioskService.getKioskId(productInputObj.getKioskId());
						prod = productService.getById(product.getId());
						System.out.println(kiosk);
						if(kiosk!=null && prod!=null)
						{
					
						productKiosk =kiosk.getId()>0 && product.getId()>0?  productKioskService.getProductKioskByProductandKioskId(kiosk.getId(),prod.getId()):null;
						if(productKiosk!=null)
						{
					    quantity= productKiosk.getQuantity();
						productKiosk.setKiosk(kiosk);
						productKiosk.setQuantity(productInputObj.getQuantity());
						kioskId=kiosk.getId();
						productKiosk.setProduct(prod);
						productKioskService.updateProductKiosk(productKiosk);
						pk = productKioskService.getProductkiosk(productKiosk.getId());
						System.out.println("PK" + productKiosk.getId());
						status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
						}
						}
					}

					else {
						status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND, "No Records");
						return new AddProductResponse(status, null, 0, 0);
					}
				} else {
					status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED, products);
					return new AddProductResponse(status, null, 0, 0);
				}
			}

			else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED, "User Not Found");
				return new AddProductResponse(status, null, 0, 0);
			}
		} catch (Exception e) {
			logger.error("addProducts ",e);				

		}
		return new AddProductResponse(status, product,kioskId,quantity);

	}
	
	public ResponseStatus updateKioskStatus(@RequestBody KioskInput kioskObj, final HttpServletRequest request,final HttpServletResponse response)
	{
		ResponseStatus status=null;
		Kiosk kiosk=null;
		User user=null;
		user = tokenUser.getUser(request);
		try
		{
			
			if(user!=null)
			{
				kiosk=kioskService.getKioskByKioskID(kioskObj.getKioskId());
				if(kiosk!=null)
				{
					kiosk.setActive(!kiosk.isActive());
					kioskService.updateKiosk(kiosk);
					status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Kiosk Status Updated");
				}
				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Kiosk Found");
				}
			}
			else
			{
			status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED, "Unauthorized User");
			}

		}
		
		catch(Exception e)
		{
			logger.error("updateKioskStatus ",e);				
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return status;
		
	}
	


}
