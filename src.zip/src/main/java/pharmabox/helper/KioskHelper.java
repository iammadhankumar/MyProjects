package pharmabox.helper;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import pharmabox.customdomain.KioskInput;
import pharmabox.domain.Kiosk;
import pharmabox.domain.Product;
import pharmabox.domain.User;
import pharmabox.response.KioskMessage;
import pharmabox.response.KioskMessages;
import pharmabox.response.KioskViewMessage;
import pharmabox.response.ResponseStatus;
import pharmabox.response.ResponseStatusCode;
import pharmabox.service.IAdminService;
import pharmabox.service.IProductService;
import pharmabox.service.KioskService;
import pharmabox.utils.UserByToken;
import pharmabox.views.KioskView;

@Service
public class KioskHelper {
	
	@Autowired
	private KioskService kioskService;
	
	@Autowired
	private IAdminService adminService;
	
	@Autowired
	private IProductService productService;
	

	
	@Autowired
	private UserByToken tokenUser;
	
	private static final Logger logger = LoggerFactory
			.getLogger(KioskHelper.class);
	
	
	public KioskMessage getKioskLocationDetails(@FormParam("kiosk_id") long kiosk_id, final HttpServletResponse response){
		ResponseStatus status = null;
		List<Kiosk> kiosk=null;
		response.setHeader("Cache-Control", "no-cache");
		try {
			kiosk = kioskService.getKioskLocationDetail(kiosk_id);
			if (kiosk !=null) {
				status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
			}else {
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No Records");
			}
		}catch(Exception e){
       logger.error("getKioskLocationDetails ",e);		
       status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return new KioskMessage(status,kiosk);
	}
	

	@SuppressWarnings("unused")
	public KioskMessage getAllKioskMap(@FormParam("latitude") String latitude,@FormParam("longitude") String longitude,final HttpServletResponse response){
		ResponseStatus status = null;
		List<Kiosk> kiosk=null;
		response.setHeader("Cache-Control", "no-cache");
		double lat=0;
		double lng=0;
		try {
			kiosk = kioskService.getAllKioskMap(latitude,longitude);
			 lat= Float.parseFloat(latitude);
		      lng= Float.parseFloat(longitude);
			if (kiosk !=null){
				for(Kiosk k:kiosk){

					HashMap<String,Double> coordinate = new HashMap<String,Double>();
					coordinate.put("latitude", k.getLatitude());
					coordinate.put("longitude",  k.getLongitude());
					k.setCoordinate(coordinate);
					
				}
				status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
			}else{
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No kiosk available in this location");
			}
		}catch(Exception e){
		       logger.error("getAllKioskMap ",e);		
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return new KioskMessage(status,kiosk);
	}

	public static float  distFrom(float lat1, float lng1, float lat2, float lng2) {
		double earthRadius = 6371; //meters
		double dLat = Math.toRadians(lat2-lat1);
		double dLng = Math.toRadians(lng2-lng1);
		double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
				Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
				Math.sin(dLng/2) * Math.sin(dLng/2);
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
		float dist = (float) (earthRadius * c);
	return dist;
	}

	
	public KioskMessages getAllKioskList(@RequestParam(value="all" , required = false, defaultValue = "0") int all, @RequestParam(value="pagenumber" , required = false, defaultValue = "0") int pagenumber, @RequestParam(value="pagerecord" , required = false, defaultValue = "0") int pagerecord, @RequestParam(value="sortColumn" , required = false, defaultValue = "0") int sortColumn, @RequestParam(value="sortType" , required = false, defaultValue = "0") int sortType,final HttpServletResponse response){
		ResponseStatus status = null;
		List<Kiosk> kioskList=null;		
		long kioskcount=0;
		response.setHeader("Cache-Control", "no-cache");
		try 
		{
			if(all==0)
			{
			kioskList = kioskService.getAllKioskList(pagenumber,pagerecord);
			System.out.println(kioskList);
			if (kioskList !=null){
				for(Kiosk k:kioskList){

					HashMap<String,Double> coordinate = new HashMap<String,Double>();
				
					coordinate.put("latitude", k.getLatitude());
		
					coordinate.put("longitude",  k.getLongitude());
					k.setCoordinate(coordinate);
					
				}
				kioskcount=kioskList.size();
				status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
			} 
			else{
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No Kiosk Records");
				return new KioskMessages(status,null,0);

			}
		}
		if(all==1)
		{
			kioskList=adminService.getAllKiosks(pagenumber, pagerecord,sortColumn,sortType);
			if(kioskList!=null)
			{
			
			status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
			}
			else
			{
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No Kiosk Records");
				return new KioskMessages(status,null,0);
			}
		}
		}
			catch(Exception e)
			{
			  logger.error("getAllKioskList ",e);		
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		
		
		return new KioskMessages(status,kioskList,kioskcount);
	}
	
	
	public KioskViewMessage getAllKioskListByProduct(@RequestParam("pid") long pid,@RequestParam(value="pagenumber" , required = false, defaultValue = "0") int pagenumber, @RequestParam(value="pagerecord" , required = false, defaultValue = "0") int pagerecord,final HttpServletResponse response){
		ResponseStatus status = null;
		List<KioskView> kiosk=null;
		Product product=null;
		long kioskcount=0;
		response.setHeader("Cache-Control", "no-cache");
		try {
			
			product=pid>0?productService.getById(pid):null;
			if(product!=null)
			{
				kiosk=kioskService.getAllKioskViewListByProducts(pid, pagenumber, pagerecord);
                System.out.println("KIOSK "+kiosk);
				if (kiosk !=null)
				{
				
						for(KioskView k:kiosk){

							HashMap<String,Double> coordinate = new HashMap<String,Double>();
						
							coordinate.put("latitude", k.getLatitude());
				
							coordinate.put("longitude",  k.getLongitude());
							k.setCoordinate(coordinate);
							
						}
					kioskcount=kioskService.getAllKioskViewListByProductscount(pid);
						status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
				}

				else{
					status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No Kiosk Records");
					return new KioskViewMessage(status,null,0);

				}

			}

			else
			{
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"Product Not Found");
				return new KioskViewMessage(status,null,0);
			}
		}catch(Exception e){
			  logger.error("getAllKioskListByProduct ",e);		
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}

		return new KioskViewMessage(status,kiosk,kioskcount);
	}

	public ResponseStatus KioskUpdateStatus(@RequestBody KioskInput kioskInput,final HttpServletRequest request,final HttpServletResponse response)
	{
		ResponseStatus status=null;
		User userEntity = tokenUser.getUser(request);
		Kiosk kiosk=null;
		
		try
		{
			kiosk= (kioskInput.getKioskId()>0)?kioskService.getKioskId(kioskInput.getKioskId()):null;
			

			if(userEntity!=null)
			{
			if(kiosk!=null)
			{
				kiosk.setActive(!kiosk.isActive());
				kioskService.updateKiosk(kiosk);
				status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Kiosk Status Updated");
				
			}
			else
			{
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"Kiosk Not Found");
				
			}
			}
			else
			{	
				status=new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED,"UnAuthorized User");	
			}

			
		}
		
		catch(Exception e){
			  logger.error("KioskUpdateStatus ",e);		
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return status;
		
		
	
	}
	
	
	
	
	

}
