package pharmabox.helper;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.LazyInitializationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import pharmabox.customdomain.AddBasketInput;
import pharmabox.customdomain.BasketCount;
import pharmabox.customdomain.BasketCountByUser;
import pharmabox.customdomain.RewardsInput;
import pharmabox.domain.Basket;
import pharmabox.domain.Kiosk;
import pharmabox.domain.Product;
import pharmabox.domain.ProductKiosk;
import pharmabox.domain.Rewards;
import pharmabox.domain.RewardsMaintain;
import pharmabox.domain.User;
import pharmabox.repository.BasketRepository;
import pharmabox.repository.RewardsMaintainRepository;
import pharmabox.response.BasketCountByUserMessage;
import pharmabox.response.BasketCountMessage;
import pharmabox.response.BasketMessages;
import pharmabox.response.CountMessage;
import pharmabox.response.ResponseStatus;
import pharmabox.response.ResponseStatusCode;
import pharmabox.response.RewardCalculation;
import pharmabox.service.IAddProductKioskService;
import pharmabox.service.IAdminService;
import pharmabox.service.IBasketService;
import pharmabox.service.IKioskService;
import pharmabox.service.IProductService;
import pharmabox.utils.CommonUtils;
import pharmabox.utils.UserByToken;

@Service
public class BasketHelper {
	
	private static final Logger logger = LogManager.getLogger(BasketHelper.class);

	
	@Autowired
	private IAddProductKioskService AddProductKioskService;

	@Autowired
	UserByToken tokenUser;

	@Autowired
	private IBasketService basketService;

	@Autowired
	private RewardsMaintainRepository rewardsMaintainrepo;

	@Autowired
	private IKioskService kioskService;

	@Autowired
	private IProductService productService;

	@Autowired
	private IAdminService adminService;
	
	@Autowired
	BasketRepository basketRepo;

	CommonUtils commonUtils= CommonUtils.getInstance();
	
	public BasketMessages addtobasket(@RequestBody AddBasketInput AddBasketInputObj,final HttpServletRequest request, HttpServletResponse response) throws LazyInitializationException
	{
		ResponseStatus status=null;
		Product product=null;
		Kiosk kiosk=null;
		Basket basket=null;
		List<Basket> basketCheck=null;
		Basket basketQuantityIncrease=null;
		Basket basketinfo=null;
		User user=null;
		Rewards reward=null;
		float discountedPrice=0;
		float rewardsPrice=0;
		float totalamount=0;
		ProductKiosk prodKiosk=null;
		user = tokenUser.getUser(request);
		try
		{
		if(user!=null)
		{
			basketCheck=basketService.getbasketforkioskcheck(user.getUser_id());	
			
			product=AddBasketInputObj.getPrimarypId()>0?productService.getById(AddBasketInputObj.getPrimarypId()):null;
			kiosk=basketCheck==null?kioskService.getKioskById(AddBasketInputObj.getKioskId()):kioskService.getKioskById(basketCheck.get(0).getProductKiosk().getKiosk().getId());
			
			prodKiosk=product!=null && kiosk!=null ? AddProductKioskService.getProductKioskByproductId(product.getId(),kiosk.getId()):null;
			
			if(prodKiosk!=null)
			{	
			 basketinfo=basketService.getbasketbyproductkioskidanduserid(prodKiosk.getId(), user.getUser_id());
			 if(prodKiosk.getQuantity()!=0)
			 {
			if(basketCheck!=null && !basketCheck.isEmpty())
			{
				if(basketinfo!=null && basketinfo.getQuantity()>=prodKiosk.getQuantity())
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_INSUFFICIENT,"Out Of Stock");
					return new BasketMessages(status, null);	
				}
				if(basketCheck.size()>=4 && basketService.getBasketByProductKioskandUser(prodKiosk.getId(),user.getUser_id())==false)
               {
					status = new ResponseStatus(ResponseStatusCode.STATUS_NOT_ACCEPTABLE,"Oops! Only 4 products are allowed per transaction.");
					return new BasketMessages(status, null);
               }
				
				 basketQuantityIncrease = basketService.getBasketByProductKioskAndUser(prodKiosk.getId(),user.getUser_id());

				 
              reward=basketCheck.get(0).getReward()!=null?adminService.getRewardById(basketCheck.get(0).getReward().getId()):null;
				 
				 if(reward!=null)
				 {
					 totalamount= basketRepo.sumOfBaskets(user.getUser_id());
				 }
				 
				 if(basketQuantityIncrease!=null)
				 {
					 basketQuantityIncrease.setQuantity(basketQuantityIncrease.getQuantity()+1);
					 basketQuantityIncrease.setPrice(basketQuantityIncrease.getPrice()+product.getPrice());
					 basketService.updateBasket(basketQuantityIncrease);
					 status = new ResponseStatus(ResponseStatusCode.STATUS_OK,"Quantity Increased.");
					 return new BasketMessages(status,null);
				 }
//					 if(reward!=null)
//					 {
//						  totalamount=totalamount+product.getPrice();
//			        	  rewardsPrice=(float) reward.getPromoValue();
//			        	  discountedPrice=(totalamount-rewardsPrice)<0?0:totalamount-rewardsPrice;
//			        	  basket =new Basket();
//			        	  basket.setActualPrice(totalamount);
//			        	  basket.setDiscountedPrice(discountedPrice);
//			        	  basket.setRewardsPrice(rewardsPrice);
//			        	  basket.setReward(reward);
//			        	  basket.setRewardsUsed(true);
//			        	  basketService.updateRewardsInfo(totalamount,discountedPrice,rewardsPrice,reward,true,user.getUser_id());
//					 }
				 
				
			}
			          basket=new Basket();
			          basket.setActive(true);
			          basket.setCreatedOn(new Date());
			          basket.setActions(true);
			          basket.setBasketStatus(basketService.setBasketStatus(1));
			          basket.setPrice(product.getPrice());
			          basket.setProductKiosk(prodKiosk);
			          basket.setPurchase(false);
			          basket.setQuantity(1);
			          basket.setUser(user);
			          if(reward!=null)
			          { 
			        	  basket.setReward(reward);
			        	  basket.setRewardsUsed(true);
			        	  totalamount=totalamount+product.getPrice();
			        	  rewardsPrice=(float) reward.getPromoValue();
			        	  discountedPrice=(totalamount-rewardsPrice)<0?0:totalamount-rewardsPrice;
			        	  basket.setActualPrice(totalamount);
			        	  basket.setDiscountedPrice(discountedPrice);
			        	  basket.setRewardsPrice(rewardsPrice);
			        	  basket.setReward(basketCheck.get(0).getReward());
			        	  basket.setRewardsUsed(true);
			        	  basketService.updateRewardsInfo(totalamount,discountedPrice,rewardsPrice,reward,true,user.getUser_id());
			          }
			          basketService.registerNewToBasket(basket);
			          
			          status = new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
			
			}
			
			 else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_INSUFFICIENT,"Out Of Stock");
					return new BasketMessages(status, null);	
				}
			}
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND,"Sorry, the selected product unavailable in this kiosk");
				return new BasketMessages(status, null);	
			}
			
		}
		else
		{
			status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED,"Unauthorized User");
			return new BasketMessages(status, null);	
		}
		
		}
		catch(Exception e)
		{
			logger.error("addToBasket ", e);

		}
		
		return new BasketMessages(status, basket);
		
	}
	
	
	@SuppressWarnings("unused")
	public CountMessage addquantity(@RequestBody AddBasketInput AddBasketInputObj,final HttpServletRequest request, HttpServletResponse response)
	{
		ResponseStatus status=null;
		Product product=null;
		List<Basket> basketlt=null;
		Basket basket=null;
		User user=null;
		long basketcount=0;
		List<Basket> basketcheck=null;
		Rewards rewardObj=null;
		ProductKiosk productKiosk=null;
		float originalAmount=0;
		float rewardAmount=0;
		ProductKiosk productKioskObj=null;
		float discountedAmount=0;
		user=tokenUser.getUser(request);
		try {
		
			if(user!=null)
			{
					if(AddBasketInputObj.getQuantity()>0)
					{ 
						basketlt=basketService.getBasketlistByUserid(user.getUser_id());
						if(basketlt!=null && basketlt.size()>0) 
						{
						     productKioskObj=AddBasketInputObj.getProductkioskid()>0?AddProductKioskService.getProductKioskBypId(AddBasketInputObj.getProductkioskid()):null;
							

							if(productKioskObj != null)
							{
								product= productKioskObj.getId()>0 ? productKioskObj.getProduct():null;
								if( productKioskObj.getQuantity() >= AddBasketInputObj.getQuantity())
								{ 
									if(product!=null)
									{
									productKiosk=product!=null && product.getId()>0?AddProductKioskService.getProductAndKiosk(product.getId()):null;
									basket=productKioskObj.getId()>0?basketService.getbasketDetailsbypid(productKioskObj.getId(),user.getUser_id()):null;
									if(basket !=null) 
									{
										long quantity=basket.getQuantity();
										basket.setQuantity(AddBasketInputObj.getQuantity());
										basket.setPrice(product.getPrice()*AddBasketInputObj.getQuantity());
										basketService.updateBasket(basket);
										basketcheck=basketService.getbasketforkioskcheck(user.getUser_id());

										rewardObj=basketcheck.get(0).isRewardsUsed()==true?adminService.getRewardById(basketcheck.get(0).getReward().getId()):null;

										if(rewardObj!=null)
										{
											originalAmount=basketRepo.sumOfBaskets(user.getUser_id());
											rewardAmount=(float) rewardObj.getPromoValue();
                                            discountedAmount=(originalAmount-rewardAmount)<0?0:originalAmount-rewardAmount;                
											basketService.updateRewardsInfo(originalAmount, discountedAmount, rewardAmount, rewardObj, true, user.getUser_id());

										}
									}
									}
									else
									{
										status = new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED,"Product not found in your cart list");
										return new CountMessage(status, 0);
									}

								} 
								else
								{
									status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND,"Out Of Stock");
									return new CountMessage(status, 0);
								} 
								basketcount=AddBasketInputObj.getQuantity();
							}
							else
							{
								status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"ProductKiosk not found");
								return new CountMessage(status, 0);
							}

						}

						else 
						{
							status = new ResponseStatus(ResponseStatusCode.STATUS_CONFLICT,"No cart list found for this user");
							return new CountMessage(status, 0);
						}

					}

					else
					{
						status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"Quantity is required");
						return new CountMessage(status, 0);
					}
				
				
			}
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED,"Unauthorized User");
				return new CountMessage(status, 0);
			}
		}
		catch(Exception e) 
		{
			logger.error("addQuantity ", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new CountMessage(status,0);
		}
		status = new ResponseStatus(ResponseStatusCode.STATUS_OK,"success ");
		return new CountMessage(status,basketcount);
	}
	
	
	@SuppressWarnings("unused")
	public BasketCountMessage getcartlist(@RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletResponse response,HttpServletRequest request)
	{
		ResponseStatus status = null;
		Basket basket=null;
		List<Basket> basketList=null;
		List<Basket> basketCheck=null;
		BasketCount basketcountInput=null;
		ProductKiosk productKiosk=null;
		long basketcount = 0;
		float totalprice  = 0;
		float totalwithquantity=0;
		float tax =0;
		float total=0;
		User user=null;
		long count=0;
		int j=0;
		user = tokenUser.getUser(request);
		try {
			if(user != null) {

				basketCheck=basketService.getBasketInfo(user.getUser_id());

				if(basketCheck!=null)
				{

					for(int i=0;i<basketCheck.size();i++)
					{
						productKiosk=AddProductKioskService.getKioskByProductKioskId(basketCheck.get(i).getProductKiosk().getId());
						basket=new Basket();
						if(productKiosk.getQuantity()==0)
						{
							basket.setInstock(false);
						}

						else

						{
							basket.setInstock(true); 
						}

						basketList=basketService.getBasketlistByUseridwithpagination(user.getUser_id(),pagenumber,pagerecord);
						count=basketList.size();
					}
				}
				else 
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"USER CART IS EMPTY");
					return new BasketCountMessage(status,null,null);
				}

				if(basketList != null && basketList.size() >0) 
				{
					for(int i=0; i < basketList.size(); i++) 
					{
						totalwithquantity=basketList.get(i).getQuantity();
						totalprice = totalprice +( totalwithquantity*basketList.get(i).getProductKiosk().getProduct().getPrice());	
						System.out.println("totalwithquantity"+totalprice);
						tax=totalprice*13/100;
						total=totalprice+tax;
					
					}
					
					while(j<basketCheck.size())
					{
						System.out.println(basketCheck.get(j).getQuantity());
						basketcount=basketcount+basketCheck.get(j).getQuantity();
						System.out.println(basketcount);
						j++;
					}
					basketcountInput=new BasketCount();
					basketcountInput.setBasketList(basketList);
					basketcountInput.setBasketcount(basketcount);
					basketcountInput.setGrandTotal(String.valueOf(totalprice));
					basketcountInput.setTax(String.valueOf(tax));
					basketcountInput.setTotal(String.valueOf(total));
					status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");

				}

			}

			else 
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"USER NOT FOUND");
				return new BasketCountMessage(status,null,null);
			}
		}
		catch(Exception e) 
		{
			logger.error("deleteFromBasket ", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new BasketCountMessage(status,null,null);
		}


		return new BasketCountMessage(status,basketcountInput,basket);
	}


	
	public BasketCountMessage deleteFromBasket(@FormParam("bid") Long bid,final HttpServletResponse response,final HttpServletRequest request){
		ResponseStatus status = null;
		Basket Basket=null;
		List<Basket> basketList=null;
		float originalAmount=0;
		float rewardsPrice=0;
		float discountedPrice=0;
		List<Basket> basketCheck=null;
		Rewards rewardObj=null;
		List<Basket> basketRewardsCheck=null;
		User user=null;
		int j=0;
		response.setHeader("Cache-Control","no-cache");
		user = tokenUser.getUser(request);
		try {
			Basket=basketService.getBid(bid);

			if(Basket!=null && user!=null) 
			{
				basketCheck=basketService.getBasketInfo(user.getUser_id());

				if(basketCheck!=null)

				{

					basketRewardsCheck=basketService.getBasketByrewardsCheck(user.getUser_id());
					if(basketRewardsCheck!=null && !basketRewardsCheck.isEmpty())
					{
						basketService.delete(bid);
						status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "DELETED SUCCESSFULLY");
						basketList=basketService.getBasketlistByUserid(user.getUser_id());

						if(basketList!=null)
						{ 
							for(int i=0;i<basketList.size();i++)
							{
								originalAmount=originalAmount+basketList.get(i).getPrice();
								rewardObj=basketList.get(i).getReward();
							}

							if(rewardObj!=null)
							{
								rewardsPrice=(float) rewardObj.getPromoValue() ;
								discountedPrice=(float) (originalAmount-rewardsPrice)<0? 0:originalAmount-rewardsPrice;
								while(j<=basketList.size()-1)
								{
									basketList.get(j).setActualPrice(originalAmount);
									basketList.get(j).setRewardsPrice(rewardsPrice);
									basketList.get(j).setDiscountedPrice(discountedPrice);
									basketService.updateBasket(basketList.get(j));
									j++;

								}
							}
						}
						else
						{
							adminService.deleteRewards(user.getUser_id());
						}

					}
					else
					{
						basketService.delete(bid);
						status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "DELETED SUCCESSFULLY");
					}

				}
			} 
			else
			{
				status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"Basket not found");
				return new BasketCountMessage(status, null);
			}

		}
		catch(Exception e)
		{
			logger.error("deleteFromBasket ", e);
			System.out.println(e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return new BasketCountMessage(status, null);
	}
	
	
	public BasketCountByUserMessage getbasketcountbyuserid(final HttpServletResponse response,HttpServletRequest request)
	{
		ResponseStatus status = null;
		List<Basket> basketList=null;
		BasketCountByUser basketcountInput=null;
		long basketcount = 0;
		long userId=0;
		User user=null;
		user = tokenUser.getUser(request);
		try {

			if(user != null) 
			{
				userId=user.getUser_id();
				if(userId > 0) 
				{
					System.out.println(userId);
					basketList=basketService.getBasketlistByUserid(user.getUser_id());

					if(basketList != null && basketList.size()> 0) 
					{
						for(int i=0;i< basketList.size();i++) 
						{

							basketcount=basketcount+basketList.get(i).getQuantity();	
						}
					}
					basketcountInput=new BasketCountByUser();
					basketcountInput.setBasketcount(basketcount);
				}
				else 
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"USER NOT FOUND");
					return new BasketCountByUserMessage(status,null);
				}

			}
		}

		catch(Exception e)
		{
			logger.error("getbasketcountbyuserid ", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new BasketCountByUserMessage(status,null);
		}

		status = new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
		return new BasketCountByUserMessage(status,basketcountInput);
	}


	
	public RewardCalculation applyrewards(@RequestBody RewardsInput rewardsInputObj,final HttpServletRequest request, HttpServletResponse response)
	{
		ResponseStatus status=null;
		User user=null;
		Rewards rewardObj=null;
		List<Basket> basket=null;
		RewardsMaintain rewardsMaintain=null;
		float originalAmount=0;
		float discountedAmount=0;
		float rewardsAmount=0;
		long percentage=0;
		user = tokenUser.getUser(request);
		try
		{
			if(user!=null)
			{  
				basket=basketService.getBasketByRewards(rewardsInputObj.getBasketId());
				System.out.println("BASKET :"+basket);

				if(basket!=null)
				{
					rewardObj=(rewardsInputObj.getType()==1)?adminService.getRewardById(rewardsInputObj.getRewardId()):(rewardsInputObj.getType()==2)?adminService.getRewardByPromoCode(rewardsInputObj.getCouponCode()):null;
					System.out.println(rewardObj);
					if(rewardObj!=null)
					{	

						for(int i=0;i<basket.size();i++)
						{
							originalAmount=originalAmount+basket.get(i).getPrice();

							if(basket.get(i).getReward()==null && basket.get(i).isRewardsUsed()==false)
							{


								System.out.println("REWARD "+rewardObj);
								basket.get(i).setReward(rewardObj);
								basket.get(i).setRewardsUsed(true);
								basketService.updateBasket(basket.get(i));

							}
							else
							{
								status = new ResponseStatus(ResponseStatusCode.STATUS_AlREADY_EXIST,"You already applied this reward");
								return new RewardCalculation(status,0,0,0,0);
							}


						}

						for(int i=0;i<basket.size();i++)
						{
							rewardsAmount=(float)rewardObj.getPromoValue() ;
							percentage=(long) rewardObj.getPercentage();
							discountedAmount=(float)originalAmount-rewardsAmount;
							basket.get(i).setActualPrice(originalAmount);
							basket.get(i).setRewardsPrice(rewardsAmount);
							basket.get(i).setDiscountedPrice(discountedAmount>0?discountedAmount:0);
							basketService.updateBasket(basket.get(i));
						}

						rewardsMaintain =new RewardsMaintain();
						rewardsMaintain.setActive(true);
						rewardsMaintain.setReward(rewardObj);
						rewardsMaintain.setUser(user);

						adminService.registerRewardsInfoByUser(rewardsMaintain);



						status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
					}
					else{
						status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND,"Please Enter RewardId or Promocode");
						return new RewardCalculation(status,0,0,0,0);
					}	
				}
				else{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND,"Basket Not Found");
					return new RewardCalculation(status,0,0,0,0);
				}	
			}
			else{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND,"User Not Found");
				return new RewardCalculation(status,0,0,0,0);
			}	

		}

		catch (Exception e) {
			logger.error("applyrewards ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return new RewardCalculation(status,originalAmount,percentage,rewardsAmount,discountedAmount);                

	}
	
	
	public ResponseStatus removerewards(@RequestParam(value="rewardId") long rewardId,@RequestParam(value="bid") List<Long> bid,final HttpServletRequest request, HttpServletResponse response)
	{

		ResponseStatus status=null;
		User user=null;
		List<Basket> basket=null;
		RewardsMaintain rewardsMaintain=null;
		user = tokenUser.getUser(request);
		try
		{
			if(user!=null)
			{
				rewardsMaintain=adminService.getRewardsMaintainByUser(rewardId, user.getUser_id());
				System.out.println("Rewards Maintain "+rewardsMaintain);
				if(rewardsMaintain!=null)
				{
					adminService.removeRewards(rewardsMaintain.getReward().getId());
					basket=basketService.getBasketbyRewardPurchase(bid);
					if(basket!=null)
					{
						for(int i=0;i<basket.size();i++)
						{
							basket.get(i).setActualPrice(0);
							basket.get(i).setDiscountedPrice(0);
							basket.get(i).setRewardsPrice(0);
							basket.get(i).setReward(null);
							basket.get(i).setRewardsUsed(false);
							basketService.updateBasket(basket.get(i));
						}
						rewardsMaintain.setActive(false);
						rewardsMaintainrepo.save(rewardsMaintain);
						status = new ResponseStatus(ResponseStatusCode.STATUS_OK,"Successfully Removed This Reward");
					}

					else
					{
						status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND,"Basket Not Found");
					}

				}

				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND,"NO Rewards Added Against This User");
				}


			}

			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND,"User Not Found");

			}	

		}

		catch (Exception e)
		{
			logger.error("removerewards ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return status;
	}

}
