package pharmabox.helper;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import pharmabox.customdomain.ProductCount;
import pharmabox.dao.IAddProductKioskServiceDao;
import pharmabox.domain.Basket;
import pharmabox.domain.FavProduct;
import pharmabox.domain.Kiosk;
import pharmabox.domain.Product;
import pharmabox.domain.ProductKiosk;
import pharmabox.domain.ProductType;
import pharmabox.domain.RecentViewProducts;
import pharmabox.domain.User;
import pharmabox.repository.RecentViewRepository;
import pharmabox.response.FavouriteMessage;
import pharmabox.response.FavouriteMessages;
import pharmabox.response.ProductCountMessage;
import pharmabox.response.ProductMessage;
import pharmabox.response.ProductMessages;
import pharmabox.response.ProductTypeCount;
import pharmabox.response.ProductTypeMessage;
import pharmabox.response.RecentViewMessage;
import pharmabox.response.ResponseStatus;
import pharmabox.response.ResponseStatusCode;
import pharmabox.response.SearchProductCount;
import pharmabox.service.BasketService;
import pharmabox.service.IKioskService;
import pharmabox.service.IProductService;
import pharmabox.service.IUserService;
import pharmabox.utils.CommonUtils;
import pharmabox.utils.UserByToken;

@Service
public class ProductHelper {
	
	@Autowired
	private IProductService productService;
	
	@Autowired
	private RecentViewRepository recentViewRepo;


	@Autowired
	private IKioskService kioskService;

	@Autowired
	private IAddProductKioskServiceDao productKioskService;

	@Autowired
	private BasketService basketService;

	@Autowired
	UserByToken tokenUser;

	@Autowired
	private IUserService userService;

	CommonUtils commonUtils= CommonUtils.getInstance();


	private static final Logger logger = LogManager.getLogger(ProductHelper.class);


	@SuppressWarnings("unused")
	public ProductMessage filterByProductType(@RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,@RequestParam("productTypeId") long productTypeId,final HttpServletResponse response,HttpServletRequest request){
		ResponseStatus status = null;
		List<Product> product = null;
		Product prod=null;
		long Productsize = 0;
		User user=null;
		List<String> l=null;
		Basket basket=null;
		ProductKiosk productKiosk=null;
		Kiosk kiosk=null;
		long totalcount=0;
		ProductCount count=new ProductCount();
		response.setHeader("Cache-Control", "no-cache");
		user = tokenUser.getUser(request);

		if(productTypeId >0)
		{
			try {
				Productsize=productService.getProductcountbyproductTypeId(productTypeId);
				product = productService.getProductNames(productTypeId,pagenumber,pagerecord);
				if(product != null ) 
				{ 
					if(user != null) 
					{
						basket=basketService.getBasket(user.getUser_id());
						if(basket!=null)
						{
							productKiosk=productKioskService.getProductKioskBypId(basket.getProductKiosk().getId());
							kiosk=basket.getProductKiosk().getKiosk().getId()>0?kioskService.getKioskById(basket.getProductKiosk().getKiosk().getId()):null;
							if(kiosk!=null)
							{
								if(product!=null)
								{
								totalcount=productService.getAllProductListByKioskCount(kiosk.getId(),productTypeId,pagenumber,pagerecord);
							    product=productService.getAllProductListByKiosk(kiosk.getId(),productTypeId,pagenumber,pagerecord);
								
								l = productService.getProductFavouriteByUser(user.getUser_id());
								
								for(int i=0;i<product.size();i++)
								{
									if(l != null && l.contains(String.valueOf(product.get(i).getId())))
									{
										System.out.println("prdt fav");
										product.get(i).setProductFavourite(true);
									}
								}	
							}
							}
							else
							{
								status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Records");
								return new ProductMessage(status,null,null);
							}

							count.setProductList(product);
							count.setCount(totalcount);
							System.out.println("COUNT :"+count.getProductList().size());
							status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
						}

						else
						{
							l = productService.getProductFavouriteByUser(user.getUser_id());
							for(int i=0;i<product.size();i++)
							{
								prod = product.get(i);
								if(l != null && l.contains(String.valueOf(prod.getId())))
								{
									System.out.println("prdt fav");
									prod.setProductFavourite(true);
								}
								count.setProductList(product);
								count.setCount(Productsize);
							}
						}
					}	
				}
				else
				{
					status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No Records Found");	
					return new ProductMessage(status,null,null);
				}

				status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");	
			}
			catch(Exception e)
			{
            logger.error("filterByProductType ",e);			
    		 status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			}
		}

		return new ProductMessage(status,count);
	}


	@SuppressWarnings("unused")
	public ProductCountMessage getAllProductList1( @RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletResponse response,HttpServletRequest request)
	{
		ResponseStatus status = null;
		List<Product> product=null;
		Product prod=null;
		ProductCount count=new ProductCount();
		Basket basket=null;
		ProductKiosk productKiosk=null;
		Kiosk kiosk=null;
		List<Long> productObj=null;
		List<FavProduct> productfavourite=null;
		List<Product> productList=null;
		User user=null;
		List<Basket> basketList=null;
		long kioskid=0;
		response.setHeader("Cache-Control", "no-cache");
		List<String> l = null;
		user = tokenUser.getUser(request);
		try 
		{
			List<Product> totalproduct=productService.getProduct();
			product=  productService.getProductlist(pagenumber,pagerecord);
			logger.info(product);
			if(product != null)
			{
				if(user!=null)
				{
					basket=basketService.getBasket(user.getUser_id());

					if(basket!=null)
					{
						productKiosk=productKioskService.getProductKioskBypId(basket.getProductKiosk().getId());
						basketList=basketService.getBasketInfo(user.getUser_id());	

						if(productKiosk!=null)
						{
							kioskid=productKiosk.getKiosk().getId();
							kiosk=kioskService.getKioskById(kioskid); 
							productObj=productKioskService.getProductByKioskId(kioskid);
							if(kiosk!=null && productObj!=null)
							{	
								productList=productService.getAllProductListByPk(kioskid,pagenumber, pagerecord);

								l = productService.getProductFavouriteByUser(user.getUser_id());
                                if(productList!=null)
                                {
								for(int i=0;i<productList.size();i++)
								{
									if(l != null && l.contains(String.valueOf(productList.get(i).getId())))
									{
										productList.get(i).setProductFavourite(true);
									}
								}
                                }
								count.setProductList(productList);
								count.setCount(productObj.size());
								status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
							}
							else
							{
								status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND,"Kiosk Not Found");
								return new ProductCountMessage(status,null); 
							}

						}
					}
					else
					{
						l = productService.getProductFavouriteByUser(user.getUser_id());
						if(product!=null)
						{
						for(int i=0;i<product.size();i++)
						{
							prod = product.get(i);
							count.setProductList(product);
							count.setCount(totalproduct.size());
							if(l != null && l.contains(String.valueOf(prod.getId())))
							{
								prod.setProductFavourite(true);
							}
							System.out.println(productfavourite);
							status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
						}}
					}
				}
				else 
				{
					count.setProductList(product);
					count.setCount(totalproduct.size());
					status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
				}
			}
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No Record");
				return new ProductCountMessage(status, null);
			}
		}
		catch (Exception e) 
		{
            logger.error("getAllProductList ",e);			
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return new ProductCountMessage(status, count);
	}
	
	public FavouriteMessages getFavouriteProductId(@RequestParam("id") long id,@RequestParam("userId") long userId,final HttpServletResponse response,HttpServletRequest request){

		ResponseStatus status = null;
		User user=null;
		Product product=null;
		FavProduct fav=null;
		try
		{
			user=userService.getUserById(userId);  
			product = productService.getById(id);
			if(user != null && product !=null )
			{
				fav=productService.getByProductId(id,userId);
				if(fav != null)
				{
					if(fav.isActive())
					{
						fav.setActive(false);
					}
					else 
					{
						fav.setActive(true);
						fav.setCreatedOn(new Date());
					}
					fav.setUpdatedOn(new Date());
					productService.updateFavProduct(fav);
				}
				else 
				{
					fav = new FavProduct();
					fav.setActive(true);
					fav.setUser(user);
					fav.setProduct(product);
					fav.setCreatedOn(new Date());
					fav.setUpdatedOn(new Date());
					productService.addNewFavProduct(fav);
				}
				status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
			}
			else
			{
				status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"Data Required");
				return new FavouriteMessages(status,null);	
			}
		}
		catch(Exception e)
		{
            logger.error("getFavouriteProductId ",e);			
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new FavouriteMessages(status,null);	
		}
		return new FavouriteMessages(status,fav);
	}
	
	
	
	public ProductCountMessage getAllProductList( @RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletResponse response,HttpServletRequest request)
	{
		ResponseStatus status=null;
		User user=null;
		List<Product> product=null;
		FavProduct fav=null;
		Basket basket=null;
		List<String> l=null;
		long count=0;
		ProductCount productList=null;
		user = tokenUser.getUser(request);
	try
	{
		
		if(user!=null)
		{
			
			basket=user!=null?basketService.getBasket(user.getUser_id()):null;
			product=basket!=null?productService.getAllProductListByPk(basket.getProductKiosk().getKiosk().getId(),pagenumber, pagerecord):productService.getProductlist(pagenumber,pagerecord);
		    if(product!=null)
		    {
		    l = productService.getProductFavouriteByUser(user.getUser_id());
	
			for(int i=0;i<product.size();i++)
			{
				if(l != null && l.contains(String.valueOf(product.get(i).getId())))
				{
					product.get(i).setProductFavourite(true);
				}
			}
			count=basket!=null && basket.getProductKiosk().getKiosk().getId()>0?productService.getProductCountByBasket(basket.getProductKiosk().getKiosk().getId()):productService.getProductCountByBasket(0);
			productList=new ProductCount();
			
			productList.setProductList(product);
			productList.setCount(count);
			
			
			status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
		    }
		    else
		    {
		    	
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Record");
				return new ProductCountMessage(status,null);

		    }

		}
		else
		{
			product=productService.getProductlist(pagenumber,pagerecord);
			if(product==null)
			{

				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Record");
				return new ProductCountMessage(status,null);
			}
			count=product!=null?productService.getProductCountByBasket(0):0;
			productList=new ProductCount();
			productList.setProductList(product);
			productList.setCount(count);
			product=productService.getProductlist(pagenumber,pagerecord);
			status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");

		}		
	}
	
	catch(Exception e)
	{
        logger.error("getFavouriteProductId ",e);			
		status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		return new ProductCountMessage(status,null);	
	}
	return new ProductCountMessage(status,productList);
		
	}
	public FavouriteMessage getFavouriteListsByUserId(@RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletResponse response,HttpServletRequest request)
	{
		ResponseStatus status=null;
		List<FavProduct> favproduct=null;
		User user=null;
		long count=0;
		List<String> l=null;
		FavProduct fav=null;
		long userId=0;

		try 
		{
			user = tokenUser.getUser(request);
			if(user!=null)
			{
				userId=user.getUser_id();
				favproduct=productService.getFavListsById(userId,pagenumber,pagerecord);
				count=productService.getcountByUserIdAndActive(user.getUser_id());
				l = productService.getProductFavouriteByUser(user.getUser_id());
				if(favproduct != null && favproduct.size()>0 )
				{
					for(int i=0;i<favproduct.size();i++)
					{	
						fav = favproduct.get(i);
						if(l != null && l.contains(String.valueOf(fav.getProduct().getId())))
						{
							fav.getProduct().setProductFavourite(true);
						}
						status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
					}
					status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
				}
				else 
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"NO FAVOURITE ITEMS ADDED AGAINST THIS USER");

					return new FavouriteMessage(status,null,0);	
				}
			}
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"USER NOT FOUND");
				return new FavouriteMessage(status,null,0);
			}
		}
		catch(Exception e)
		{
		    logger.error("getFavouriteListsByUserId ",e);			
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new FavouriteMessage(status,null,0);
		}
		return new FavouriteMessage(status,favproduct,count);
	}

	public ProductMessages getproductbyproductid(@RequestParam("id") long id,final HttpServletResponse response,HttpServletRequest request)
	{
		ResponseStatus status=null;
		List<String> l=null;
		Product product=null;
		RecentViewProducts recentView=null;
		List<RecentViewProducts> recentViewList=null;
		User user=null;
		try {
			user = tokenUser.getUser(request);
			if(id>0 )
			{
				product=productService.getById(id);

				if(product != null)
				{
					if(user != null) 
					{
						l = productService.getProductFavouriteByUser(user.getUser_id());
						if(l != null && l.contains(String.valueOf(product.getId())))
						{
							product.setProductFavourite(true);
						}
						
						recentViewList=productService.getAlreadyViewedProduct(user.getUser_id(),product.getId() );
					//	lastRowOftable=productService.selectLastRowTable(user.getUser_id());
						
					  //=lastRowOftable!=null?lastRowOftable.getUser().getUser_id()==user.getUser_id() && lastRowOftable.getProduct().getId()!=product.getId():null;
						
						
						if(recentViewList!=null)
						{
					for(int i=0;i<recentViewList.size();i++)
							{
								recentViewList.get(i).setActive(false);
								recentViewRepo.save(recentViewList.get(i));
							}	
						}
						//check=lastRowOftable.getUser()==user && lastRowOftable.getProduct()==product?true:false;
					
						
						recentView=new RecentViewProducts();
						recentView.setActive(true);
						recentView.setCreated_on(new Date());
						recentView.setProduct(product);
						recentView.setUser(user);
						
						recentViewRepo.save(recentView);
						}
					
						
					
					
					status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
					return new ProductMessages(status,product);	
				}
				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"NO RECORD FOUND");
					return new ProductMessages(status,null);	

				}
			}
			else 
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"Data required");
				return new ProductMessages(status,null);	

			}
		}
		catch(Exception e)
		{
		    logger.error("getFavouriteListsByUserId ",e);			
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new ProductMessages(status,null);	
		}
	}
	public ProductTypeMessage getAllProductTypeList( @RequestParam("pagenumber") int pagenumber,@RequestParam("pagerecord") int pagerecord, final HttpServletResponse response,HttpServletRequest request)
	{
		ResponseStatus status=null;
		ProductTypeCount count=null;
		List<ProductType> producttype=null;
		try {
			List<ProductType>  totalProductType=productService.getAllProductType();
			producttype=  productService.getProductTypeList(pagenumber,pagerecord);
			if(producttype != null && !producttype.isEmpty())
			{
				count=new ProductTypeCount();
				count.setProductTypeList(producttype);
				count.setCount(totalProductType.size());
				status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
			}
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No Record");
				return new ProductTypeMessage(status, count);
			}
		}
		catch(Exception e)
		{
		    logger.error("getAllProductTypeList ",e);			
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new ProductTypeMessage(status,count);	
		}
		return new ProductTypeMessage(status,count);	
	}



	

	
	public SearchProductCount searchProduct(@FormParam("search_value") String search_value,@FormParam("pagenumber") int pagenumber,@FormParam("pagerecord") int pagerecord,final HttpServletRequest request,final HttpServletResponse response)
	{
		ResponseStatus status=null;
		User user=null;
		List<Product> productObj=null;
		List<FavProduct> favproduct=null;
		long kioskid=0;
		Kiosk kiosk=null;
		List<Product> productList=null;
		ProductKiosk productKiosk=null;
		Basket basket=null;
		long count=0;
		List<String> l=null;
		user = tokenUser.getUser(request);
		try
		{   productObj=productService.getSearchProductDetails(search_value);

		if(user!=null)
		{
			favproduct=productService.getFavProductListByProductId(productObj,user.getUser_id());
			basket=basketService.getBasket(user.getUser_id());
		   if(productObj!=null)
		   {
			   count=productObj.size();
			if(favproduct!=null && basket==null)
			{	
				for(int i=0;i<favproduct.size();i++)
				{
					for(int j=0;j<productObj.size();j++)
					{
						if(favproduct.get(i).getProduct().getId() ==  productObj.get(j).getId())
						{
							productObj.get(j).setProductFavourite(true);
							System.out.println(productObj.get(j).getId());
							break;
				
						}


					}
				}
			}
		   }
		   else
		   {
			   status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND,"NO RECORD FOUND");
				return new SearchProductCount(status,null,0);  
		   }

			if(basket!=null)
			{
				productKiosk=productKioskService.getProductKioskBypId(basket.getProductKiosk().getId());

				if(productKiosk!=null)
				{
					kioskid=productKiosk.getKiosk().getId();
					kiosk=kioskService.getKioskById(kioskid); 
					if(kiosk!=null)
					{
						productList=productService.getSearchProductListByKiosk(kioskid,search_value);

						if(productList!=null) 
						{
							count=productList.size();
							if(favproduct!=null)
							{


								productList=productService.getProductListByKiosk(kioskid,search_value,pagenumber,pagerecord);
								l = productService.getProductFavouriteByUser(user.getUser_id());
								for(int i=0;i<productList.size();i++)
								{
									if(l != null && l.contains(String.valueOf(productList.get(i).getId())))
									{
										productList.get(i).setProductFavourite(true);
									}
								}


								//status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
							}
							productObj=productList;

						}

					}
						
						else
						{ 
							status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND,"NO RECORD FOUND");
							return new SearchProductCount(status,null,0);
						}


				}

			}
		}
		else
		{
			if(productObj!=null)
			{
				count=productObj.size();
				productObj=productService.getAllSearchProductDetails(search_value,pagenumber,pagerecord);
				//status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");

			}
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"Product Not Found");
				return new SearchProductCount(status,null,0);	
			}
		}

		}
		catch(Exception e)
		{
		    logger.error("searchProduct ",e);			
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		
		status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
		return new SearchProductCount(status,productObj,count);	
	}
	
	
	public RecentViewMessage recentViewedProduct(@RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletRequest request,final HttpServletResponse response)
	{
		ResponseStatus status=null;
		User user=null;
		List<RecentViewProducts> rvProduct=null;
		long count=0;
		List<String> l=null;
		user = tokenUser.getUser(request);
		try
		{
			if(user!=null)
			{
	
				Date date=productService.getIntervelDate();
				System.out.println("DATE CHECK "+date);
				rvProduct=date!=null?productService.getAllRecentViewProductsByUser(user.getUser_id(),date,pagenumber, pagerecord):null;
				System.out.println(rvProduct);
				l = productService.getProductFavouriteByUser(user.getUser_id());
				
				if(rvProduct!=null  )
				{
					for(int i=0;i<rvProduct.size();i++)
					{
						System.out.println("P "+l);
						if(l != null && l.contains(String.valueOf(rvProduct.get(i).getProduct().getId())))
						{

							System.out.println("prdt fav");
							rvProduct.get(i).getProduct().setProductFavourite(true);
						}
					}	




					count=productService.getRecentViewCount(user.getUser_id(),date);
					status = new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");

				}
				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND,"No Records");
					return new RecentViewMessage(status,null,0);	
				}
			}
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORDFOUND,"User Not Found");
				return new RecentViewMessage(status,null,0);	
			}
		}
		catch(Exception e)
		{
		    logger.error("recentViewedProduct ",e);			
			status=new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"InternalError");
		}
				
		return new RecentViewMessage(status,rvProduct,count);
		
	}


}
